#pragma once

#ifndef TSF_RACES_H_INCLUDED
#define TSF_RACES_H_INCLUDED

#include "tsf_classes.h"
//rc_ter, rc_mer, rc_var, rc_val, rc_ras, rc_fal, rc_nom

void define_races()
{
rc_ter={
    "Terepellan",
    "The most dauntless of all the mortal races. Few can match a Terepellan's skill\nwith blade and magic, though many choose to take up crafting or mercantilism.\n",
    0, 0, 1, 0, 0, 0, 0, 0};
    races[0]=rc_ter;

rc_mer={
    "Merissi",
    "A semi-reptilian race of desert-dwellers. Merissi are known widely\nfor their deadly poisons and fatal political games.\n",
    0, 0, 0, 0, 1, 0, 0, 0};
    races[1]=rc_mer;

rc_var={
    "San'Devar",
    "A pious and industrious race from the verdant plains of Nezaph, the San'Devar revere honor and hierarchy.\nTheir cathedrals and castles are known far and wide for their beauty and grandeur.\n",
    0, 0, 1, 0, 0, 0, 0, 0};
    races[3]=rc_var;

rc_val={
    "San'Deval",
    "A strict and honorable race of assassins from a forested island in the north;\nlegend tells of their deadly precision and unmatched stealth.\n",
    0, 0, 0, 1, 0, 0, 0, 0};
    races[4]=rc_val;

rc_ras={
    "Raszyra",
    "A bestial race of wolfish humanoids with a propensity for fire.\nTheir origin and homeland have been lost in time.\n",
    0, 0, 1, 0, 0, 0, 0, 0};
    races[5]=rc_ras;

rc_fal={
    "Fal'mei",
    "A joyful and peace-loving race, the Fal'mei are forever seeking a brighter existence through art,\nmusic, community and magic. Fal'mei hair, skin and eyes are every color of the earth,\nmales typically shades of blue, green or brown while females are more floral colors.\n",
    0, 0, 0, 0, 0, 1, 0, 0};
    races[6]=rc_fal;

rc_nom={
    "Nomi",
    "An ancient race of monks and sages. The Nomi are largely peaceful, but possess deep and mysterious power.\n",
    0, 0, 0, 0, 1, 0, 0, 0};
    races[7]=rc_nom;

races[8]={
    "Elven",
    "An ancient race of monks and sages. The Nomi are largely peaceful, but possess deep and mysterious power.\n",
    0, 0, 0, 0, 1, 0, 0, 0};
    races[7]=rc_nom;

}

#endif // TSF_RACES_H_INCLUDED
