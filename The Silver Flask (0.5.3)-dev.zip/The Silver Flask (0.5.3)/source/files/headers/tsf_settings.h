#ifndef TSF_SETTINGS_H_INCLUDED
#define TSF_SETTINGS_H_INCLUDED

#include <iostream>
#include <vector>
#include <type_traits>

using namespace std;

//static interface processes
const static HANDLE hConsole=GetStdHandle(STD_OUTPUT_HANDLE);

//Filesystem handle
 namespace fs = std::filesystem;

//Console text colors
const static int COL_WHITE = 15;
const static int COL_GREY = 7;
const static int COL_BLUE = 3;
const static int COL_RED = 4;
const static int COL_GREEN = 2;
const static int COL_CYAN = 11;
const static int COL_PURPLE = 5;
const static int COL_ORANGE = 6;
const static int COL_YELLOW = 14;
const static int COL_BKONWH = 240;
//Solid color blocks
const static int COL_BLOCK_WHITE = 255;
const static int COL_BLOCK_BLUE = 17;
const static int COL_BLOCK_TEAL = 51;
const static int COL_BLOCK_GREEN = 34;
const static int COL_BLOCK_LIME= 170;
const static int COL_BLOCK_PURPLE = 85;
const static int COL_BLOCK_ORANGE = 102;
const static int COL_BLOCK_PINK = 221;
const static int COL_BLOCK_GREY = 136;
const static int COL_BLOCK_YELLOW = 238;
const static int COL_BLOCK_RED = 68;

//Color map for ease of access
vector<pair<string, int>> console_colors = {
        {"black", 0}, {"blue", 1}, {"green", 2}, {"teal", 3},
        {"red", 4}, {"purple", 5}, {"orange", 6}, {"white", 7},
        {"gray", 8}, {"lightblue", 9}, {"lime", 10}, {"cyan", 11},
        {"pink", 12}, {"magenta", 13}, {"yellow", 14}, {"brightwhite", 15}
};

string diff_lvls[11] = {"Sandbox", "Easiest", "Easier", "Easy", "Moderate", "Normal", "Difficult", "Hard", "Harder", "Hardest", "Extreme"};
float diff_scales[11];

fstream debug_log;

void debugMsg(string data_t, int data_n)
{
    cout<<"Debug: "<<data_t<<": "<<data_n<<"\n";
}

int scale_rup(int val, float scale) { return static_cast<int>( ceil(scale * val) ); }

int scale_rdown(int val, float scale) { return static_cast<int>( floor(scale * val) ); }

string strCase(string s_str, string s_case)
{
    //Function to convert the first character of
    //a string to uppercase or lowercase

        string s = s_str;

        //Convert the string to char* array
        const char* str = s_str.c_str();

        //Get size of array
        int c = s.length();

        //Decide whether first character is upper or lower
        if(s_case=="u"||s_case=="upper") s = toupper(str[0]);
        else s = tolower(str[0]);

        //Return char* to string by appending each character
        for(int x = 1; x < c; x++) {s += str[x];}

        return s;
}

void prln(string contents) { cout<<"\n"<<contents<<"\n"; }

void setConCap(string new_cap) { SetConsoleTitle( new_cap.c_str() ); }

struct settings
{
    string console_title;
    bool sound, display_type, survival;
    int pcol_1, pcol_2, mtcol; //Player icon colors, main text color
    string psym_1, psym_2; //Symbols to represent the character on each of their two map squares
    string s_dsp_type; //"graphic" = ASCII graphics; "text" = descriptive
    bool is_playing; //
    string status_display; //"graphic" = ASCII graphics; "text" = descriptive
    string combat_display; //"graphic" = ASCII graphics; "text" = descriptive
    int combat_wait_time; //Number of seconds (~0.7 sec) between player and computer turns
    string diff_desc; //Difficulty level descriptor (e.g. 'medium', 'hard', etc.
    float diff_scale; //Difficulty level scale factor
    int diff_lvl;


    void initialize_difficulties(){ diff_scales[0] = 0.5f; for(int i = 1; i < 11; i++){ diff_scales[i] = 0.5f + (i * 0.1f); } }

    void set_diff_defaults() { if ( diff_desc == "" ) diff_desc = "Normal"; if( diff_scale == 0.0f ) diff_scale = 1.0f; }

} game_settings;

//Set a snippet of text to a certain color
void colSet (int num, string str)
{
    SetConsoleTextAttribute(hConsole, num);
    cout<<str;
    SetConsoleTextAttribute(hConsole, game_settings.mtcol);
}

//Color set function to use as a string
string s_colSet(int num, string str)
{
    SetConsoleTextAttribute(hConsole, num);
    cout<<str;
    SetConsoleTextAttribute(hConsole, game_settings.mtcol);
    return "";
}

bool roll20(int num)
{
	bool win;
	int rnd=rand()%20+1;
	if(num>=rnd) win=true;
	else win=false;
	return win;
}

void status_bar(int nmax, int ncur, int color, string borderL, string borderR, string full, string empt)
{
    float bar_scale=nmax/16;
    if(nmax>16){nmax/=bar_scale; ncur/=bar_scale;}
    int diff=nmax-ncur;

    colSet(7, borderL);
    for(int x=0;x<16;x++) { if(x<(16-diff)) {colSet(color, full);} else {colSet(7, empt);} }
    colSet(7, borderR);
    cout<<"\n\n";
}

void c_status_bar(int nmax, int ncur, int color, int scale, string borderL, string borderR, string full, string empt)
{
    //Status bar with the scale adjusted for display format
    //Originally named "c_" for centigrade

    float bar_scale=nmax/48;
    if(nmax>48){nmax/=bar_scale; ncur/=bar_scale;}
    int diff=nmax-ncur;

    colSet(7, borderL);
    for(int x=0;x < 48;x++)
    {
        if(x<(48-diff)) {colSet(color, full);} else {colSet(7, empt);}
    }
    colSet(7, borderR);
    cout<<"\n\n";
}

void user_status_bar()
{
    string borderL, borderR, full, empt;
    int ncur, nmax, color, scale;

    cout << "\nEnter the details of your status bar:\n";
    cout << "Maximum value: ";
    cin >> nmax;
    cout << "Current value: ";
    cin >> ncur;
    cout << "Bar color: ";
    cin >> color;
    cout << "Bar scale: ";
    cin >> scale;
    cout << "Right border: ";
    cin >> borderR;
    cout << "Left border: ";
    cin >> borderL;
    cout << "Appearance when full: ";
    cin >> full;
    cout << "Appearance when empty: ";
    cin >> empt;
    cout << "Creating custom status bar...\n\n\n";

    c_status_bar(nmax, ncur, color, scale, borderL, borderR, full, empt);
}

void lbr() { cout << "\n"; }

bool rollfor(int targ, int sides)
{
	bool win;
	int rnd=rand()%sides+1;
	if(targ>=rnd)
		win=true;
	else
		win=false;
	return win;
}

int rollfrom(int start, int range) { return rand() % range + start; }

int roll(int sides)
{
	int result=rand()%sides+1;
	return result;
}

int rollfz(int sides)
{
    int result = rand()%sides;
    return result;
}

bool flip() { return rollfor(1, 2); }

int rollcap(int start, int range, int cap) { int res = rand() % range + start; if ( res > cap ) return cap; else return res; }

void clear_cin() {cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');}

int check_int()
{
    //Checks if player input is an integer;
    //prevents a crash in the event a string is entered

    //NOTE: Does not allow '0' as input

    int inp;
    cin>>inp;
    while(!inp) //Fails if input is zero
    {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout<<"\nInput error; please enter a number:\n";
        cin>>inp;
    }
    return inp;
}

// Function to check if a string is a number
//(GPT-generated)
bool isNumber(const string& s) {
    for (char const &ch : s) {
        if ( isdigit(ch) == 0 ) return false;
    }
    return true;
}

bool isRange(int floor, int ceil, int arg) { if (arg >= floor && arg <= ceil) return true; else return false; }

string aoran(string str, bool upper)
{
    //prints 'a' or 'an' depending on the following word
    string a_an;
    //Check if a/an is meant to be uppercase
    if(upper) a_an="A";
    else a_an="a";
    //Vowels for comparison
    char cVowels[10]={'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'};
    bool is_vowel=false;
    //Get first character of string
    char fc=tolower(str.c_str()[0]);
    //Check against vowel list
    for(int x=0;x<10;x++)
    {
        if(fc==cVowels[x]) {is_vowel=true; break;}
    }
    //Add an 'n' if there's a vowel
    if(is_vowel) a_an+="n";
    //Add a space after
    a_an+= " "; /*add + string */
    return a_an;
}

string aoranf(string str, bool upper)
{
    //prints 'a' or 'an' *AND* the following word
    string a_an;
    //Check if a/an is meant to be uppercase
    if(upper) a_an="A";
    else a_an="a";
    //Vowels for comparison
    char cVowels[10]={'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'};
    bool is_vowel=false;
    //Get first character of string
    char fc=tolower(str.c_str()[0]);
    //Check against vowel list
    for(int x=0;x<10;x++)
        if(fc==cVowels[x]) {is_vowel=true; break;}
    //Add an 'n' if there's a vowel
    if(is_vowel) a_an+="n";
    //Add a space after
    a_an+= " " + str;
    return a_an;
}

string truncateSpace(const string fname) {
    size_t space = fname.find(' ');
    return (space != string::npos) ? fname.substr(0, space) : fname;
}

string replace_spaces(const string& str) {
    string result = str;
    for (char& c : result) { if (c == ' ') c = '_'; }
    return result;
}

string replace_underscores(const string& str) {
    string result = str;
    for (char& c : result) { if (c == '_') c = ' '; }
    return result;
}

string replace_chars(const string& str, const char& cha, const char& ch2) {
    string result = str;
    for (char& c : result) { if (c == cha) c = ch2; }
    return result;
}

bool inpAffirm(string input)
{
    if(input == "y" || input =="Y" || input =="yes" || input == "Yes" || input == "1")
        return true;
    else return false;
}

bool inpDeny(string input)
{
    if(input == "n" || input == "N" || input == "no" || input == "No" || input == "2")
        return true;
    else return false;
}

int pctOf(int n_min, int n_max)
{
    float f_min = n_min;
    float f_max = n_max;
    float f_result=100*(f_min/f_max);
    int n_result=static_cast<int>(f_result);
    return n_result;
}

int isint(char a[])
{
    int len=strlen(a);
    int minus=0;
    int dsum=0;
    for(int i=0;i<len;i++)
    {
        if(isdigit(a[i])!=0)
            dsum++;
        else if(a[i]=='-')
            minus++;
    }
    if(dsum+minus==len)
        return 1;
    else
        return 0;
}

int isfloat(char a[])
{
    int len=strlen(a);
    int dsum=0;
    int dot=0;
    int minus=0;
    for(int i=0;i<len;i++)
    {
        if(isdigit(a[i])!=0)
        {
            dsum++;
        }
        else if(a[i]=='.')
        {
            dot++;
        }
        else if(a[i]=='-')
        {
            minus++;
        }
    }
    if(dsum+dot+minus==len)
        return 1;
    else
        return 0;
}

void gameMsg(string message){ prln("  -> " + message + " <-"); }

void sleepFor(int seconds) { cout << "\n"; for (int i = 0; i < seconds; ++i) { Sleep(1000); cout << "...\n";} }

template <typename Filestream>
void f_checkO(Filestream& f, const fs::path p){ if (!f.is_open()) cout << "File error: could not open " << p << ".\n"; }
template <typename Filestream>
void f_checkC(Filestream& f, const fs::path p){ if (f.is_open()) cout << "File error: could not close " << p << ".\n"; }

struct map_data
{
    string world, fairy_loc, sick_potion_needed;
    bool lost_in_party, sick_nearby, weak_nearby, needful_nearby;
    int needful_item_id;
    bool ferry, bridge;
    int plot_1, plot_2;
    int inn_cost;
    bool milk_ready;
    bool wool_ready;
    bool lost_village;
    bool dwarven_city;

    //Fairy Missive
    int fairy_loc_x, fairy_loc_y, fairy_missive;

    //The Lost
    int lostx, losty;

    int block_colors[16]={15, 17, 34, 51, 68, 85, 102, 119, 136, 153, 170, 187, 204, 221, 238, 255};
    void displayColors()
    {
        int ct=0;
        //Start a column of 4 color options
        for(int x=0;x<4;x++)
        {
            //Print a row of 4 color options
            for(int y=0; y<4;y++)
            {
                //Print color number and sample
                cout<<"("<<ct<<"): "; colSet(block_colors[ct], "  ");
                //Indent before next
                cout << "\t";
                //Move to next color
                ct++;
            }
            //Move to next line
            cout<<"\n";
        }
    }

} m_data;

void initializeSettings()
{
//Format
game_settings.console_title = "The Silver Flask";

setConCap(game_settings.console_title);

//mini-quests
m_data.lost_in_party=0;
m_data.lostx=0;
m_data.losty=0;
m_data.weak_nearby=0;
m_data.needful_nearby=0;
m_data.needful_item_id=0;
m_data.sick_nearby=0;
m_data.sick_potion_needed="null";

//map
m_data.world = "main";
m_data.inn_cost = 10;
m_data.ferry=0;
m_data.bridge=0;
m_data.fairy_loc="null";
m_data.lost_village = false;

//options
game_settings.survival = false;
game_settings.display_type=0; //map or text on movement, text=0, map=1
game_settings.s_dsp_type = "text";
game_settings.sound=1; //sound: 1=on, 0=off
game_settings.pcol_1=255;//player icon colors
game_settings.pcol_2=255;
game_settings.mtcol=7;//main text color; default is white
game_settings.is_playing = 0; //Switched on when game begins
game_settings.status_display = "graphic"; //Switches between visual descriptions and status bars for HP/MP/XP
game_settings.combat_display = "numeric"; //Damage in combat is either displayed in numbers or described
game_settings.combat_wait_time = 3; //Number of seconds (0.7 sec) to wait before computer turn
}

#endif // TSF_SETTINGS_H_INCLUDED
