#pragma once

#ifndef TSF_PARTY_H_INCLUDED_
#define TSF_PARTY_H_INCLUDED_

#include "tsf_classes.h"

void define_party()
{
    //name, race, class, classup, status, AI, desc,
    // relation, atk, def, hp, hpmax, mp, mpmax, str, dex, intl, lck, xp, xpnxt, lvl, sup, dup, iup, lup, hpot, mpot, apot;
	empty1={"empty", "null", "null", "null", "null", "null",
	"null\n",
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	empty1.iab=0;
	empty1.idle[0]="null";
	empty1.idle[1]="null";
	empty1.idle[2]="null";
	empty1.idle[3]="null";
	empty1.idle[4]="null";
	empty1.info[0]="null";
	empty1.info[1]="null";
	empty1.info[2]="null";
	empty1.info[3]="null";
	empty1.info[4]="null";
	empty1.chat[0]="null";
	empty1.chat[1]="null";
	empty1.chat[2]="null";
	empty1.chat[3]="null";
	empty1.chat[4]="null";
	empty1.weap=eq[0];
	empty1.arm=eq[0];
	empty1.acc=eq[0];
	empty1.inv=eq[0];

	luci={"Luci", "Pixie", "Sorceress", "null", "OK", "cunning",
	"This diminutive creature looks none the worse for her interminable\nstay in the silver flask. She constantly hovers at your shoulder,\noffering garrulous quips; you catch a glimpse of pointed teeth when\nshe laughs.\n",
	0, 1, 1, 20, 20, 20, 20, 0, 3, 3, 0, 0, 50, 1, 0, 0, 0, 0, 1, 1, 1};
	luci.color=13;
	luci.iab = 3; //Shock, right?
	luci.gift=getItemID("molten", "core"); //Is there any point to raising relationship level?
	luci.accept= "'Wow, where did you find this? It's...pulsing.'\n";
	luci.greet[0]= "'Hey! Shouldn't we be getting somewhere?'\n";
	luci.greet[1]= " She flutters up and lands on your shoulder.\n'What's next?'\n";
	luci.greet[2]= "'I'm so glad you're here.'\n";
	luci.idle[0]= " hovering curiously ";
	luci.idle[1]= " is chasing a small animal in circles nearby.";
	luci.idle[2]=" checks her nails fastidiously; she glances up at you impatiently.";
	luci.idle[3]=" is transmuting the plantlife nearby.";
	luci.idle[4]=" is pulling faces and tittering at a nearby tree.";
	luci.info[0]=" .\n";
	luci.info[1]=" .\n";
	luci.info[2]=" .\n";
	luci.info[3]=" .\n";
	luci.info[4]=" .\n";
	luci.chat[0]="'Gods above and below, I was in that flask for *so* long!\n...how long? I don't know, is Samavarius still trying to kill that dragon?'\n";
	luci.chat[1]="'You know,' muses the pixie, 'I'll bet that a lot of bigger enemies just crumble if you set 'em on fire.'\n";
	luci.chat[2]="Luci drapes herself dramatically over a boulder as you stop to rest.\n'This world used to be a lot better, you know, when it was just us beasts of the land.'\nShe makes a sour face. 'Before all the Elves, and Dwarves, and...'\nShe glances over at you. 'Well, it was different.'\n";
	luci.chat[3]="Luci is uncharacteristically quiet as you approach, staring into the distance.\nShe looks up, startled, her usual grin returning.\n'Sorry,' she says. 'I was just thinking about the old days.\nAn old friend. I almost miss her...'\nShe trails off, and her expression darkens.\n'Damn Fae...they better hope I don't get my hands on them.'\n";
	luci.chat[4]="She ignores you completely.\n";

	frost={"Frost", "Human", "Mage", "Wizard", "OK", "cunning",
	"This ancient, gruff, wind-bitten wizard is anything but\na doddering old man; one look at the fire in his eyes is enough to\nterrify any bandit, despite his prodigious beard and shaggy brows.\n",
	0, 1, 1, 20, 20, 30, 30, 1, 1, 3, 1, 0, 50, 1, 0, 0, 0, 0, 1, 1, 1};
	frost.color=11;
	frost.iab=1;
	frost.gift=47;
	frost.accept= "The old wizard peers intently at the gem. 'Yes,' he mutters with\ngrudging admiration, 'This is just what I've been looking for.'\n";
	frost.greet[0]= "Frost fixes you with a piercing glare. 'Don't bother me now, young'n.\nI'm occupied with forces you cannot comprehend!'\n";
	frost.greet[1]= "The old wizard harrumphs bad-temperedly. 'I suppose you need something again.'\n";
	frost.greet[2]= "'Sure, sure,' he says gruffly. 'My arcane meditations can wait.'";
	frost.idle[0]=" is squinting up at the sky ";
	frost.idle[1]=" removes a small scrying orb from his belt and stares at it intently.";
	frost.idle[2]=" swiftly forms a low block of ice and sits down, shaking a pebble from his sandal.";
	frost.idle[3]=" calls out from a short distance away, 'We should make haste; the clouds are moving swiftly.";
	frost.idle[4]=" scribbles something onto a roll of parchment, his brow furrowed.";
	frost.info[0]=" Frost looks up, snow collecting in his beard. 'This time of year is\nalways when my powers are strongest,' he murmurs, almost to himself.\n";
	frost.info[1]=" The grizzled old arcanist holds up a gemstone between his thumb and\nforefinger. 'These are integral to the enchanting process, you know. And as far as\nI know, there's only one place to buy them: an old elf's workshop, in the east.";
	frost.info[2]=" Frost scowls. 'The blasted Arcanum make their roost near here, curse\nthem. They hoard their magical supplies, and keep the suppliers a secret, except to\nmages that join their little Guild.' He spits in the dirt. 'The worst kind of magi.'\n";
	frost.info[3]=" Frost halts behind you, shoes crunching in the snow. His expression\nsuddenly serious, he calls out to you. 'Wait, adventurer. Beyond, in yon cave, is\nmy greatest failure.' He strokes his beard with a pained expression. 'If ye intend\nto explore further, be ready, and be wary; I alone was not enough to bring the \ndamned construct down.'\n";
	frost.info[4]=" ";
	frost.chat[0]=" He looks at you sideways before returning to his pipe. 'Sorry, young'n, we've got nothing to discuss.";
	frost.chat[1]=" ";
	frost.chat[2]=" ";
	frost.chat[3]=" ";
	frost.chat[4]=" ";

	aldo={"Aldo", "Dwarven", "Bard", "Courtesan", "OK", "cunning",
	"Aldo cuts a rather peculiar figure. While every scrap of his voluminous\nclothing is clearly from different styles, from different eras even, the\nwhole ensemble really flatters the squat bard's figure. Rounding out his\ndelightful presentation is Aldo's ever-present, ruddy-cheeked smile, and,\nof course, his ever-present lute.\n",
	1, 1, 1, 30, 30, 20, 20, 1, 1, 2, 2, 0, 50, 1, 0, 0, 0, 0, 1, 0, 0};
	aldo.color=14;
	aldo.iab=6;
	aldo.gift=43;
	aldo.accept= "The incorrigible bard's eyes light up as you hand him the roast.\n'Ah,' he says, before tearing into it like a starving animal, 'I hope ye'll\nforgive my lack of refinement, master traveller.'\n";
	aldo.greet[1]= "He forestalls you with a quick trill from his flute. 'Need ye aught?'\n";
	aldo.greet[2]= "Aldo greets your approach with a double handful of flower petals, momentarily blinding you.\nBefore you can recover, he's launched fully into a song and dance routine, gesticulating and twirling wildly.\nAt last, he grinds to a halt, and looks up, panting, with a broad wink. 'Well,' he gasps, 'c'n I help ye at all?'";
	aldo.greet[0]= "";
	aldo.idle[0]=" has already lit a campfire and is roasting some small fowl";
	aldo.idle[1]=" strolls away, plucking the strings of his lute and crooning some old ballad";
	aldo.idle[2]=" is arguing with a rock";
	aldo.idle[3]=" is juggling a trio of stones";
	aldo.idle[4]=" has seemingly gotten into a staring contest with a newt";
	aldo.info[0]=" \n";
	aldo.info[1]=" \n";
	aldo.info[2]=" \n";
	aldo.info[3]=" \n";
	aldo.info[4]=" ";
	aldo.chat[0]=" ";
	aldo.chat[1]=" ";
	aldo.chat[2]=" ";
	aldo.chat[3]=" ";
	aldo.chat[4]=" ";


	grognak={"Grognak", "Human", "Warrior", "Barbarian", "OK", "aggressive",
	"The muscular chieftan's dark skin is crisscrossed with ragged scars, souvenirs of a hundred battles in the wild jungles of his homeland.\n",
	1, 2, 1, 25, 25, 10, 10, 3, 1, 0, 0, 0, 50, 1, 3, 1, 0, 1, 1, 0, 0};
	grognak.color=4;
	grognak.iab=14;
	grognak.greet[0]="The burly warrior grunts in acknowledgment.\n";
	grognak.idle[0]=" crouching at the ready ";
	grognak.idle[1]=" adjusts his loincloth.";
	grognak.idle[2]=" bares his teeth in a wide yawn.";
	grognak.idle[3]=" examines the intricately patterned tattoos covering his arms.";
	grognak.idle[4]=" picks his teeth with a shard of bone.";
	grognak.info[0]=" 'This is a dangerous place; we should be ready for a fight.";
	grognak.info[1]=" 'Yon beast is a true challenge!', flexing his muscles in anticipation.";
	grognak.info[2]=" 'We may rest easy; no enemy will trouble us here.'";
	grognak.info[3]=" 'Be wary! A powerful foe lies ahead.'";
	grognak.info[4]=" ";
	grognak.chat[0]=" ";
	grognak.chat[1]=" ";
	grognak.chat[2]=" ";
	grognak.chat[3]=" ";
	grognak.chat[4]=" ";

	luz={"Luz", "Elven", "Huntress", "Assassin", "OK", "aggressive",
	"The willowy-limbed Elven huntress is clad in a belted green tunic,\nbrown leggings, and calf-length leather boots.\nTwo straight locks of auburn hair escape her\ndark green head kerchief, hanging over\nher pointed ears. She notices your\nscrutiny and makes a face.\n'What are you looking at?', she says.\n",
	0, 1, 1, 20, 20, 15, 15, 1, 1, 1, 1, 0, 50, 1, 1, 3, 1, 1, 1, 0, 1};
	luz.color=2;
	luz.weap=eq[0];
	luz.arm=eq[1];
	luz.acc=eq[0];
	luz.iab=9;
	luz.gift=103;
	luz.accept="'These are...these are my favorite! It's beautiful...how did you know?'\n\n";
	luz.greet[0]="She grimaces. 'Now what?'\n";
	luz.greet[1]="'Yes? What is it?'\n";
	luz.greet[2]="Luz looks up with a grin. 'Something on your mind?'\n";
	luz.idle[0]=" standing with her arms crossed, waiting impatiently ";
	luz.idle[1]=" kneels to inspect some flora, then stands again with a bored look.";
	luz.idle[2]=" clears her throat loudly. 'Sometime today, dreamer!'";
	luz.idle[3]=" brushes a speck of dirt off the hem of her tunic.";
	luz.idle[4]=" holds out her hand, looking upwards. A bright yellow songbird flutters down to land in her palm.\nThe two share a trilling chorus. The bird flies away and Luz gives you a cheeky grin.";
	luz.info[0]=" 'There should be a medicinal herb growing somewhere\n around here. If you see\none, try not to trample it, okay?'";
	luz.info[1]=" 'The flowers here are so beautiful! They're my favorite.\nThe elders in my village sometimes use them for\nreplenishing the spirit.'";
	luz.info[2]=" 'Those scraggly red plants that grow here, Torchweed,\nthey taste like the hindquarters of a Buhorn, but\n they're a powerful restorative.'";
	luz.info[3]=" 'I used to come here all the time when I was little! We'd catch\nthe fireflies with a net, then keep them in bottles\nor flasks. It was so much fun...'";
	luz.info[4]=" 'Dreamer, wait!'\nLuz holds out her hand, looking serious.\n\n'This place is sacred...'\n\n'Somewhere in this forest, my people's guardian spirit, the ancient oak,\nlies dormant, slumbering in wait for the next chosen guardian.\n\n...so tread lightly, outlander.\nThat is all.'";
	luz.chat[0]="She scowls. 'I have nothing I want to talk to you about.'\n";
	luz.chat[1]="Luz regards you seriously. 'Look, maybe you're not so bad.\nBut that doesn't mean I have to like this assignment.\nLet's just get this over with so I can go home.\n";
	luz.chat[2]="\nThe russet-haired Elf is staring into the distance.\nShe doesn't look up as you set beside her.\n\n'You know,' she murmurs, 'I miss my village less and less.\nI feel kind of guilty about that.'\n\nShe heaves a sigh. 'Wonder if they miss me at all?'\n\n";
	luz.chat[3]="\nLuz grabs your hand excitedly as you approach.\n'Good! I was waiting to talk to you...I've decided!'\nShe chuckles and shakes her head at your confusion.\n\n'To be an adventurer! You know, just travel.\nFight monsters.\nSave townsfolk.\n\nWith you.'\n\nShe smiles and looks off over the horizon, shading her eyes.\n'They can...they can wait a little longer. I'm sure we'll make it home someday.'\n\n";
	luz.chat[4]="She's practicing her archery as you approach.\n\nSquinting one eye and peering down the shaft of an arrow,\nshe lets fly, piercing a distant leaf. Lowering the bow, she turns to you, smiling.\n\nYou tell her what's on your mind, and the two of you converse for a while.\nSatisfied, you take your leave, and she gives you a\nreassuring pat before lining up another shot.\n";
}

#endif
