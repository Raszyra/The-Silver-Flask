#ifndef TSF_CLASSES_H_INCLUDED
#define TSF_CLASSES_H_INCLUDED

#include "tsf_functions.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

//define data types; several are nested so the order is important


struct sign {
    string name, text;

    void read()
    {
        cout<<"\nYou lean forward to read the "<<name<<" sign.\n";
        cout<<"\n '"<<text<<"'\n\n";
    }

} red, green, blue, yellow;

struct weather
{
    string name;
    string desc;
    int color;
    string elem;

} cweath[6];

struct season
{
    int id;
    string name;
    int color;
    weather weath;
    weather wopt[3];
    string elem1, elem2;

} nulls, curs, seasons[4];

struct skill
{
    string name;
    int lvl, item_id, mat1, mat2;
    string s_mat1, s_mat2;

    void show_details()
    {
        cout << "[" << lvl << "] --- | " << name;
        cout << " \t(Item ID: " << item_id << ")";
        cout << "\tMaterials needed: " << s_mat1; if ( mat2 ) cout << ", " << s_mat2;

        cout << "\n";
    }


};

struct special
{
	string name, clas, elem;
	int dmg, maxd, cost, id, req;
	bool unlock, avail;
	string desc;

	void showInfo(){
	    cout<<name<< "\n   Class: " << clas << "\n   Element: "<<elem<<"\n   Damage: "<<dmg<<"-"<<maxd<<"\n   MP cost: "<<cost<<"\n";
        if(desc!="") cout<<desc<<"\n";}

} splist[100], null_spell;

struct race
{
    string name;
    string desc;
    int ab, db, stb, dxb, inb, lcb, hpb, mpb;
} rc_ter, rc_mer, rc_var, rc_val, rc_ras, rc_fal, rc_nom, races[15];

struct equipment
{
	string name, mat, type, ench, desc;
	int matb, enchb, atkb, defb, strb, dxb, intb, lckb, wt, price;
	bool held, worn;
	int id;
	string inscrip;
	string subt;
	string act_desc[3];

	string showName()
	{
	    //Returns a single concatenated string, checking for material and enchantment
	    string apn=name;
	    if (mat != "none") {apn = mat + " " + apn;}
	    if (ench != "none") {apn = apn + " (" + ench + ")";}
	    return apn;
	}

	bool istypematch(string s_type) { if ( s_type == type ) return true; else return false; }

	void showData(string s_type)
	{
	    prln(showName());
	    prln(desc);

	    cout << "It feels like it weighs " << wt << " pounds.\n";
	    cout << "It's probably worth about " << price << " gold.\n";

	    bool is_elemental;
	    if (ench == "water" || ench == "fire" || ench == "wind" || ench == "lightning" || ench == "earth") is_elemental = true;

	    if ( is_elemental ) prln("There is an aura of arcane "+ ench + " about it.");
        if (ench != "none" && type == "container") prln("It contains an amount of " + ench + ".");
        if (ench != "none" && type == "pet") prln("It contains a live " + ench + ".");

	    if (s_type == "assess")
        {
            if(type=="weapon"||type=="armor"||type=="accessory")
            {
                //Formatting and spacing here is important
                cout<<"Element: "<<ench<<"   Ench. Bonus: "<<enchb<<"\nAtk: "<<atkb<<"   Def: "<<defb<<"\nStr: "<<strb<<"   Dex: "<<dxb<<"   Int: "<<intb<<"   Lck: "<<lckb<<"\n";
            }
            else if(type=="food")
            {
                cout<<"It would probably heal about "<<enchb<<" HP";
                if(atkb>0) cout<<" and "<<atkb<<" MP";
                cout<<".\n";
                if(ench=="whole") cout<<"There are 2 servings here.\n";
                if(ench=="half") cout<<"There is 1 serving left.\n";
            }
        }
	}

	void setPrice()
	{
	    if(matb!=0) price*=matb;
	}

	void setMaterialBonus()
	{
	    if(type=="weapon")
			atkb+=(matb);
		defb+=matb;
		wt+=matb;
	}

	void setType()
	{
	    if(name=="katana"||name=="shortsword"||name=="longsword"||name=="sword of angel's mercy"||name=="horsebreaker sword"||name=="blade"||name=="dagger"||name=="Grimault"||name=="Rime Echo"){subt="sword";}
        if(name=="rapier"||name=="Rime Echo"||name=="trefoil"||name=="stilletto"){subt="sword";}
        if(name=="staff"||name=="spear"||name=="trident"){subt="staff";}
        if(name=="mace of blessed bashing" || name == "club"){subt="mace";}
        if(name=="longbow"||name=="shortbow"||name=="crossbow"||name=="feathersong"){subt="bow";}
        if(name=="kiteshield"||name=="kite shield"||name=="small shield"){subt="shield";}
        if(name=="chainmail"||name=="tunic"||name=="leather armor"||name=="hood"){subt="light_armor";}
        if(name=="plate armor"){subt="heavy_armor";}
        if(name=="empty"||name=="knuckles"||name=="cestus"||name=="fist"||name=="studded glove"){subt="unarmed";}
	}

	void setActDesc()
	{
	    if(subt=="sword") {act_desc[0]="make a two-handed horizontal slash"; act_desc[1]="change your grip and thrust"; act_desc[2]="raise your blade over head and chop";}
        else if(subt=="staff") {act_desc[0]="extend your reach and swing"; act_desc[1]="make several jabs"; act_desc[2]="aim low and sweep";}
        else if(subt=="bow") {act_desc[0]="fire"; act_desc[1]="loose an arrow from"; act_desc[2]="take aim and fire";}
        else if(subt=="mace") {act_desc[0]="swing"; act_desc[1]="swing"; act_desc[2]="swing";}
        else if(subt=="unarmed") {act_desc[0]="reach back and swing hard"; act_desc[1]="swiftly jab"; act_desc[2]="step forward and lunge";}
	}

	void showAction(string context)
	{
	    int act=rand()%3;

	    if(context=="attack")
        {
            string s_name = name;
            if(name == "empty") name = "fist";
            cout<<"\nYou "<<act_desc[act]<<" at the enemy with your "<<name<<"!\n";
            name = s_name;
        }
        else
            cout<<"\nYou "<<act_desc[act]<<" with your "<<name<<".\n";
	}

	void saveToFile(string pname, string loc, int item_id)
	{
	    ofstream f_item;
	    string fname = pname + loc + "item" + to_string(item_id) + ".txt";

	    f_item.open(fname);

	    if(!f_item.is_open()) {cout<<"\nFile error! Could not locate "<<fname<<"\n"; return;}

	    f_item<<mat<<"\n";
        f_item<<type<<"\n";
        f_item<<ench<<"\n";
        f_item<<atkb<<"\n";
        f_item<<defb<<"\n";
        f_item<<strb<<"\n";
        f_item<<dxb<<"\n";
        f_item<<intb<<"\n";
        f_item<<lckb<<"\n";
        f_item<<matb<<"\n";
        f_item<<enchb<<"\n";
        f_item<<wt<<"\n";
        f_item<<price<<"\n";
        f_item<<id<<"\n";

        f_item.close();
        if(f_item.is_open()) {cout<<"\nFile error! Could not close "<<fname<<"\n";}
	}

	void loadFromFile(string pname, string loc, int item_id)
	{
	    ifstream f_item;
	    string fname = pname + loc + "item" + to_string(item_id) + ".txt";

	    f_item.open(fname);

	    if(!f_item.is_open()) {cout<<"\nFile error! Could not locate "<<fname<<"\n"; return;}

	    f_item >> mat;
        f_item >> type;
        f_item >> ench;
        f_item >> atkb;
        f_item >> defb;
        f_item >> strb;
        f_item >> dxb;
        f_item >> intb;
        f_item >> lckb;
        f_item >> matb;
        f_item >> enchb;
        f_item >> wt;
        f_item >> price;
        f_item >> id;

        f_item.close();
        if(f_item.is_open()) {cout<<"\nFile error! Could not close "<<fname<<"\n";}
	}

	void create_book(bool force_type_change, string s_type)
	{
	    //Catch to see if the item has already been generated
	    if ( (name == "book" || name == "scroll" || name == "recipe") && ench != "none" )
            return;
	    //Flag to change item (into a book, recipe or scroll)
	    if (force_type_change) { name = s_type; }

	    if ( name == "book" ){
            //Set material type if not skill/spell
            if (mat != "skill" && mat != "spell") {
                string type[2] = {"skill", "spell"};
                mat = type[ rand()%2 ];
            }
            //Set target skill (if none chosen)
            if( mat == "skill" && (ench == "none" || ench == "") )
            {
                int sknum = rand()%10;
                string skname[10] =
                {
                    "woodcutting",
                    "firemaking",
                    "mining",
                    "fishing",
                    "cooking",
                    "woodworking",
                    "smithing",
                    "sewing",
                    "enchanting",
                    "hunting"
                };
                ench = skname[sknum];
                matb = sknum;
            }
            if(mat == "spell" && (ench == "none" || ench == "") )
            {
                int spnum = rand()%68;
                ench = splist[spnum].name;
                matb = spnum;
            }
            price = 300;
	    }
	    else if ( name == "scroll" ) {
            if (force_type_change) mat = "paper";
            int spnum = rand()%70;
            ench = splist[spnum].name;
            matb = spnum;

            string ench_color = "null";
            //Choose a ribbon color based on spell type
            for (int spell = 0; spell < 70; spell++)
            {
                if (splist[spell].elem == "water") {ench_color = "blue"; break;}
                else if (splist[spell].elem == "earth") {ench_color = "green"; break;}
                else if (splist[spell].elem == "wind") {ench_color = "white"; break;}
                else if (splist[spell].elem == "fire") {ench_color = "red"; break;}
                else if (splist[spell].elem == "lightning") {ench_color = "purple"; break;}
                else if (splist[spell].elem == "ice") {ench_color = "teal"; break;}
                else if (splist[spell].elem == "holy") {ench_color = "golden"; break;}
                else if (splist[spell].elem == "dark") {ench_color = "black"; break;}
                else {ench_color = "grey"; break;}
            }
            desc = "A crisp roll of parchment, tied neatly with a " + ench_color + " ribbon.\n";
            price = 100;
        }
        else if ( name == "recipe" && (ench == "" || ench == "none") ) {
            string rec_type[2] = {"food", "potion"};
            string rec_food[4] = {"bread", "pie", "cake", "stew"};
            string rec_pot[14] = {"red dye", "blue dye", "yellow dye", "orange dye", "purple dye", "green dye", "strength potion", "dexterity potion", "intellect potion", "luck potion", "health potion", "mana potion", "antidote potion"};
            string desc_food[4] = {
                        " -flour\n -water\n\nTake the ingredients to an oven and 'bake' them.\n",
                        " -flour\n -water\n -red berry/green berry\n\nTake the ingredients to an oven and 'bake' them.\n",
                        " -flour\n -water\n -egg\n\nTake the ingredients to an oven and 'bake' them.\n",
                        " -raw food item #1\n -raw food item #2\n -iron pot (water)\n\nItems 1 and 2 can be any raw food,\nlike vegetables, meat, or fish.\nYou can cook stew at a campfire or an oven.\n"
                    };
            string desc_pot[14] = {
                        //Dyes
                        " -any red flower\n -water\n",
                        " -any blue flower\n -water\n",
                        " -any yellow flower\n -water\n",
                        " -red or yellow dye\n -yellow or red flower\n",
                        " -red or blue dye\n -blue or red flower\n   -or-\n -any purple flower\n -water",
                        " -blue or yellow dye\n -yellow or blue flower\n",
                        //Potions
                        " -torchweed\n -molten core\n",
                        " -red berry\n -molten core\n -water\n", //Str
                        " -green berry\n -feather\n -water\n", //Dex
                        " -lobelia\n -snowflower\n -water\n", //Int
                        " -flour\n -dandelion\n -water\n", //Luck
                        " -medicinal herb\n -torchweed\n -water\n", //hpot
                        " -medicinal herb\n -snowflower\n -water\n", //mpot
                        " -medicinal herb\n -green berry\n -water\n" //apot
                    };

            mat = rec_type[ rand()%2 ];
            if (mat == "food")
            {
                int fd = rand()%4;
                ench = rec_food[fd];
                desc = desc_food[fd];
            }
            if(mat == "potion")
            {
                int pot = rand()%14;
                ench = rec_pot[pot];
                desc = desc_pot[pot];
            }
            price = 25;
        }
        else cout << "Error creating book: type does not match\n";
	}

} eq[300];

struct recipe
{
    vector <equipment> ingredients;
    equipment result;

    equipment combine()
    {
        return result;
    }
} recipes[20];

struct quest
{
	string name;
	int lvl, end, xpr, gpr, itr, id;
	bool start, comp;
	int req[10];
	string desc[10];

	void setProcQuest()
	{
	    equipment* temp = new equipment;
	    end=2;
	    int itreq=rand()%100;
	    req[1]=itreq;
	    temp=&eq[itreq];
	    name = temp->name;
	    desc[1]="  -Find a "+temp->mat+" "+temp->name;
	    name=name+"\n";
	    //delete &temp;
	}
} qlog[30], pal_q[3], as_q[3], arc_q[3], tem_q[3], bas_q[10], main_q[26];

struct ai_core
{
    //A series of attributes determining a character's
    //likelihood to make certain actions or use certain
    //items or elements.
    string name, attitude, skill;
    int stat_pref, stat_choice[4];
    string wpref, apref, cpref, elem_pref, item_pref;

    void initialize(string ai)
    {
        if (ai=="aggressive")
        {
            name="aggressive";
            attitude=name;
            wpref="sword";
            cpref="shield";
            stat_pref=1;
            stat_choice[0]=10;
            stat_choice[1]=5;
            stat_choice[2]=1;
            stat_choice[3]=2;
        }
        if (ai=="flexible")
        {
            name="flexible";
            attitude=name;
            wpref="bow";
            cpref="cloak";
            stat_pref=2;
            stat_choice[0]=5;
            stat_choice[1]=5;
            stat_choice[2]=5;
            stat_choice[3]=5;
        }
        if (ai=="cunning")
        {
            name="cunning";
            attitude=name;
            wpref="staff";
            apref="robe";
            cpref="amulet";
            stat_pref=3;
            stat_choice[0]=1;
            stat_choice[1]=5;
            stat_choice[2]=10;
            stat_choice[3]=2;
        }
        if (name=="carefree")
        {
            name="carefree";
            attitude=name;
            stat_pref=4;
            stat_choice[0]=1;
            stat_choice[1]=10;
            stat_choice[2]=1;
            stat_choice[3]=10;
        }
    }
};

struct enem
{
	string name, type;
	int hp, mp, atk, def, lvl, str, dex, intl, lck, xpdr, gpdr;
	bool alive;
	string idle, elem, weak;
	special ab;
	int id;
	string status;
	int itdr[3];
	int kills;
	int hpmax, mpmax;
    string agg_lvl;
    bool agg_lock;

    void showInfo()
    {
        cout<<"\nLvl. "<<lvl<<" "<<name<<":\n";
        cout<<"Status: "<<status<<"\n";
        cout<<"HP: "<<hp<<"   MP: "<<mp<<"\n";
        cout<<"Element: "<<elem<<"   Weakness: "<<weak<<"\n";
        cout<<"Atk: "<<atk<<"    Def: "<<def<<"\n";
        cout<<"Str: "<<str<<"   Dex: "<<dex<<"   Int: "<<intl<<"   Lck: "<<lck<<"\n";
        cout<<"Ability: "<<ab.name<<"\n";
    }

	string statIsHighest()
	{
	    if ( str > dex
            && str > intl
            && str > lck) return "str";
        else if ( dex > str
            && dex > intl
            && dex > lck) return "dex";
        else if ( intl > str
            && intl > dex
            && intl > lck) return "intl";
        else if ( lck > str
            && lck > intl
            && lck > dex) return "lck";
        else return "none";
	}

    bool chooseAttack(string p_arm_ench)
    {
        bool attack = true;
        //Hard switches - circumstances where the enemy must use their ability
        if ( (hp < hpmax/2) && ab.elem == "heal") {attack = false;}
        if ( elem == p_arm_ench ) {attack = false;}
        if ( ab.name == "flush" && status != "ok" ) {attack = false;}
        //If still determined to attack, flip a coin
        if ( attack && flip() ) attack = false;
        //Hard off-switches
        if (mp < ab.cost) {attack = true;}
        return attack;
    }

	void setLevel(int plvl)
	{
        if (plvl < 5) lvl = roll(plvl + 1);
        else if (plvl < 10) lvl = roll(plvl * 2);
        else lvl = roll(plvl + 10);

        //Increase enemy stats by level:

        //S/D/I/L
        int stat_choice[4] = {0, 0, 0, 0}; //Randomly generated chances
        int stat_likely[4] = {8, 8, 8, 8}; //Static chance ranges
        int stat_chosen = 0; //Decides which stat to increase
        int is_higher_than = 0; //Counts the number of lower rolls
        //If one stat is higher than the rest, doubles chances to add to that stat
        if (statIsHighest() == "str") stat_likely[0] = 16;
        else if (statIsHighest() == "dex") stat_likely[1] = 16;
        else if (statIsHighest() == "intl") stat_likely[2] = 16;
        else if (statIsHighest() == "lck") stat_likely[3] = 16;

        //For each level, decide whether to and where to add a stat point
        for (int i = 0; i < lvl; i++)
        {
            //Chance to skip stat point
            if ( !rollfor(70, 100) ) lvl--;
            //Roll one set of stats to compare to one another
            int stats[4] = {0,0,0,0};
            int stat_index = 0;
            for (int n = 0; n < 4; n++) {stats[n] = rand()% stat_likely[n];}
            for (int n = 0; n < 4; n++) {
                stat_chosen = stats[n];
                for (int x = 0; x < 4; x++){
                    //Cycle through stat rolls, choosing the highest with each comparison
                    if (stats[x] > stat_chosen) { stat_chosen = stats[x]; stat_index = x; }
                }
            }
            //After highest stat is chosen by comparison with the other three,
            //increase the selected stat.
            switch (stat_index+1)
            {
                case 1: str ++; break;
                case 2: dex ++; break;
                case 3: intl ++; break;
                case 4: lck ++; break;
                default: dex ++;
            }
        }
        //HP/MP
        hp += roll( (5 * lvl) ) + str;
        hpmax = hp;
        mp += roll( (5 * lvl) ) + intl;
        mpmax = mp;

        //Difficulty scaling
        hp = scale_rup(hp, game_settings.diff_scale);
        hpmax = scale_rup(hpmax, game_settings.diff_scale);
        mp = scale_rup(mp, game_settings.diff_scale);
        mpmax = scale_rup(mpmax, game_settings.diff_scale);
        str = scale_rup(str, game_settings.diff_scale);
        dex = scale_rup(dex, game_settings.diff_scale);
        intl = scale_rup(intl, game_settings.diff_scale);
        lck = scale_rup(lck, game_settings.diff_scale);

	}//End of setLevel

	bool checkStatsAreHigher(bool meets, int n_str, int n_dex, int n_intl, int n_lck)
	{
	    if (str > n_str
            || dex > n_dex
            || intl > n_intl
            || lck > n_lck)
            {return true; }
        else {return false; }
	}

	void showHealth()
    {
        int hpt = pctOf(hp, hpmax);

        if(type != "text")
        {
            cout << "\nEnemy HP: " << hp << "/" << hpmax << " (" << hpt << "%)\n";
            c_status_bar(hpmax, hp, COL_ORANGE, 100, "<[", "]>", "/", "-");
            return;
        }

        string health[7]={"in perfect health", "lightly injured", "a little battered", "wounded", "bleeding profusely", "severely injured", "near death"};

        //Describe severity of wounds by percentage of health missing
        cout<<"\nThe " << name << " is ";
        switch(hpt)
        {
            case 1 ... 10: {cout<<health[6];} break;
            case 11 ... 25: {cout<<health[5];} break;
            case 26 ... 50: {cout<<health[4];} break;
            case 51 ... 75: {cout<<health[3];} break;
            case 76 ... 90: {cout<<health[2];} break;
            case 91 ... 99: {cout<<health[1];} break;
            case 100: {cout<<health[0];} break;
            default: cout<<"unreadable";
        }
        //Display status, such as poisoned or paralyzed
        if(status!="null"&&status!="OK"&&status!="ok"&&status!="none") cout << " and " << status;
        //Add a line break
        cout << ".\n";
    }

    void showMana()
    {
        int mpt = pctOf(mp, mpmax);

        if(type != "text")
        {
            cout << "\nEnemy MP: " << mp << "/" << mpmax << " (" << mpt << "%)\n";
            c_status_bar(mpmax, mp, COL_CYAN, 100, "<[", "]>", "/", "-");
            return;
        }

        string mana[7]={"full of energy", "starting to wane", "showing some mental strain", "breathing heavily", "struggling to focus", "nearly exhausted", "utterly exhausted"};

        //Describe severity of exhaustion by percentage of mana missing
        cout<<"\nThe " << name << " is ";
        switch(mpt)
        {
            case 1 ... 10: {cout<<mana[6];} break;
            case 11 ... 25: {cout<<mana[5];} break;
            case 26 ... 50: {cout<<mana[4];} break;
            case 51 ... 75: {cout<<mana[3];} break;
            case 76 ... 90: {cout<<mana[2];} break;
            case 91 ... 99: {cout<<mana[1];} break;
            case 100: {cout<<mana[0];} break;
            default: cout<<"unreadable";
        }
        cout <<".\n";
    }

    bool setAggression(int plvl, int phpct, bool stats_higher)
    {
        //Decides whether the enemy is going to attack the player
        //Aggressive AI, higher stats or pc health low = attack
        //Low health = no attack
        if (!agg_lock){
        if (agg_lvl == "aggressive" || stats_higher || phpct < 11)
            if ( (pctOf(hp, hpmax) < 25) && agg_lvl != "aggressive" ) {return false;}
            else {return true;}
        else {return false;}
        }
        else { }
    }

}elist[50], null_enem;

struct npc
{
    //Static, quest-giving side characters
	string name, idle, appear, greet, def, bye, qcomps;
	int id;
	bool questcond;
	string qline[10], info[10], dopt[10];
	quest q;

	void showIdle()
	{
	    cout<<name<<" is "<<idle<<" nearby.\n";
	}

	void appendQ()
	{
	    q.name=name+"'s "+q.name;
	    q.desc[1]=q.desc[1]+" for "+name+"\n";
	}

	void create(string type)
	{
	    string names[5];
	    if (type == "new")
        {
            string names_m[5] = {"Loric", "Arfael", "Gjard", "Ames" "Dennis" };
            string names_f[5] = { "Elise", "Neridia", "Aleshi", "Bera", "Malen" };

            name = names_m [ rand()%5 ];

            q.setProcQuest();
            appendQ();

            idle = "leafing through a book";//idle
            appear = name + " is a placid-looking individual, wearing a comfortable yet sensible ensemble in unassuming earth tones.\nHe's studiously reading a complex-looking tome, glancing up every once in a while to survey the area.\n";//description
            greet = name + " smiles and waves as you approach. 'Hey there!' he says enthusiastically.\n";//greeting
            def = "He shakes his head, looking nonplussed. 'Sorry, what was that?'\n";//wrong command
            bye = "'I'll see you later, then!'\n";//leaving
            qcomps = "'Thanks so much! I couldn't have done it without you!'\n";//quest completed
        }
	}

} nlist[30], pal_npc[3], as_npc[3], tem_npc[3], arc_npc[3], cast_npc[5], mq_npc[12], comp_npc[4];

struct character
{
    //Potential party members, capable of combat and other actions

    //Appearance, status, AI
	string name, race, clas, cnxt, status, ai, desc;
	//Stats
	int rel, atk, def, hp, hpmax, mp, mpmax, str, dex, intl, lck, xp, xpnxt, lvl;
	//Level up stats
	int sup, dup, iup, lup;
	//Potions
	int hpot, mpot, apot;
	//Console color appearance
	int color;

	//Abilities
	int iab;

	//Relationship growth material
	int gift;

	//Dialogue
	string greet[3];
	string idle[5], chat[5], info[5];
	string accept;

	//Inventory
	equipment weap, arm, acc, inv;
	string wpref, apref, cpref;

	//AI controls item preferences
	ai_core persona;

	//ID number for associated NPC ("comp_npc[]")
	int npc_id;

	void initializeAI()
	{
	    persona.initialize(ai);

        if(name=="Luz")
        {
            wpref="bow";
            npc_id = 0;
        }
        if(name=="Grognak")
        {
            wpref="sword";
            npc_id = 1;
        }
        if(name=="Frost")
        {
            wpref="staff";
            npc_id = 2;
        }
        if(name=="Aldo")
        {
            wpref="none";
            npc_id = 3;
        }
	}

	void initializeInv()
	{
	    weap=eq[0];
	    arm=eq[0];
	    acc=eq[0];
	    inv=eq[0];
	}

	int checkHealth()
	{
	    //Returns character's health as a percentage
        float temphp=hp;
        float temphpmax=hpmax;
        float hplvl=100*(temphp/temphpmax);
        int hpt=static_cast<int>(hplvl);

        switch(hpt)
        {
            case 1 ... 10: {hpt=6;} break;
            case 11 ... 25: {hpt=5;} break;
            case 26 ... 50: {hpt=4;} break;
            case 51 ... 75: {hpt=3;} break;
            case 76 ... 90: {hpt=2;} break;
            case 91 ... 99: {hpt=1;} break;
            case 100: {hpt=0;} break;
            default: hpt=0; break;
        }
	  return hpt;
	}

	void showHealth()
	{
	    int hpt=checkHealth();
	    string health[7]={"in perfect health", "lightly bruised", "a little battered", "wounded", "bleeding profusely", "severely injured", "near death"};

	    if( game_settings.status_display != "text" )
        {
            cout << "\n\t" << hp <<"/" << hpmax << " (" << pctOf(hp, hpmax) << "%)\n";
            status_bar(hp, hpmax, 4, "<[", "]>", "(0)", "---");
            return;
        }
        //Describe severity of wounds by percentage of health missing
        //100 percent, 90, 75, 50, 25, 10
        cout<<name<<" is "<<health[hpt];

        //Display status, such as poisoned or paralyzed
        if(status!="null"&&status!="OK"&&status!="ok"&&status!="none")cout<<", and "<<status;

        cout<<".\n\n";
	}

	void showAppearance()
	{
	    cout<<"\nYou study your companion.\n\n";
	    cout<<"\n"<<desc<<"\n";
	    cout<<name<<" is \n";
	    if(weap.name!="empty") {cout<<"-wielding "<<aoran(weap.mat, false)<<weap.showName()<<"\n";}
	    if(arm.name!="empty") {cout<<"-wearing "<<aoran(arm.mat, false)<<arm.showName()<<"\n";}
	    if(acc.name!="empty") {cout<<"-wearing "<<aoran(acc.mat, false)<<acc.showName()<<"\n";}
	    cout<<"\n";
	}

	void healStep(bool loc_fire)
	{
	    if(hp<hpmax) {hp++; if(loc_fire) hp++;}
	    if(mp<mpmax) {mp++; if(loc_fire) mp++;}
	}

	void drinkPot(string pot)
	{
	    int gain=rand()%20+10;

	    if(pot=="health"||pot=="hp")
        {
            if(hpot>0)
            {
                cout<<"\n"<<name<<" drinks a health potion.\n";
                cout<<name<<" has regained "<<gain<<" health.\n\n";
                hp+=gain;
                hpot--;
            }
            else cout<<name<<" has run out of health potions!\n\n";
        }
        if(pot=="mana"||pot=="mp")
        {
            if(mpot>0)
            {
                cout<<"\n"<<name<<" drinks a mana potion.\n";
                cout<<name<<" has regained "<<gain<<" mana.\n";
                mp+=gain;
                mpot--;
            }
            else cout<<name<<" has run out of mana potions!\n\n";
        }
	}

	void consume()
	{
	    hp+=inv.matb;
	    mp+=inv.enchb;
	    cout<<"\n"<<name<<" eats the "<<inv.name<<" from their bag.\n";
	    inv=eq[0];
	}

	void equip(equipment item)
	{
	    if(item.type=="weapon") {weap=item;}
        if(item.type=="accessory") {acc=item;}
        if(item.type=="armor") {arm=item;}

        atk+=item.atkb;
        def+=item.defb;
        str+=item.strb;
        dex+=item.dxb;
        intl+=item.intb;
        lck+=item.lckb;

        cout<<name<<" equips the "<<item.name<<".\n\n";
	}

	void unequip(equipment item)
	{
	    if(item.type=="weapon") {weap=eq[0];}
        if(item.type=="accessory") {acc=eq[0];}
        if(item.type=="armor") {arm=eq[0];}

        atk-=item.atkb;
        def-=item.defb;
        str-=item.strb;
        dex-=item.dxb;
        intl-=item.intb;
        lck-=item.lckb;

        cout<<name<<" unequips the "<<item.name<<".\n\n";
	}

	void lvlup()
	{
		if(xp>=xpnxt)
		{
		    cout<<"\n"<<name<<" has gained a level!\n\n";

		    //Set next XP level, raise HP/MP
			xp-=xpnxt; xpnxt*=1.2; lvl++;
			hpmax+=str+1; hp=hpmax;
			mpmax+=intl+1; mp=mpmax;

			//Decide which stat to raise by persona preference
			//Character AI has a static likelihood to choose each of
			//the four main stats; however, the choice is ultimately random.
			int stup=1;
			int chance[4]={0, 0, 0, 0};
			int x;
			int is_higher=0;
			for(x=0; x<4;x++)
            {
                chance[x]=rand()%persona.stat_choice[x];
                for(int y=0;y<4;y++)
                {
                    if(chance[x]>chance[y]) {is_higher++;}
                    if(is_higher>2) {stup=x+1; cout<<"\nDebug: stat chosen - "<<stup<<"\n";}
                }
                is_higher=0;
                cout<<"\n";
            }

			switch(stup)
			{case 1: {str++; cout<<name<<" has gotten a little stronger.\n\n";} break;
			 case 2: {dex++; cout<<name<<" has gotten a little faster.\n\n";}break;
			 case 3: {intl++; cout<<name<<" has gotten a little smarter.\n\n";}break;
			 case 4: {lck++; cout<<name<<" has gotten a little luckier.\n\n";}break;
			}

            //Level-based upgrades
            //Upgrade ability every five levels
            //Upgrade class at level 15, raise stats accordingly
			switch(lvl)
			{case 5: iab=9; break;
			 case 10: iab=9; break;
			 case 15:{
			 	clas=cnxt;
			 	str+=sup; dex+=dup;
			 	intl+=iup; lck+=lup;}
			 break;}
		}
	}

	void idles()
	{
	    //Display idle text
		if(name!="empty")
		{int x=rand()%4+1;
		cout << "\n" << name << idle[x] << endl;}
	}

	void infos(int trig)
	{
	    //Display information. Triggers are arbitrary.
		cout<<"\n"<<name<<" speaks up, saying,\n\n"<<info[trig]<<endl;
	}

	void stats()
	{
		if(name!="empty")
		{
            cout<<"\nYou inspect your traveling companion.\n\n";
            cout<<name<<", level "<<lvl<<" "<<race<<" "<<clas<<endl;
            cout<<"HP: "<<hp<<"/"<<hpmax<<"    MP: "<<mp<<"/"<<mpmax<<"    Status: "<<status<<endl;
            cout<<"XP: "<<xp<<"/"<<xpnxt<<"\n\n";
            cout<<"Atk: "<<atk<<"    Def: "<<def<<endl;
            cout<<"Str: "<<str<<endl;
            cout<<"Dex: "<<dex<<endl;
            cout<<"Int: "<<intl<<endl;
            cout<<"Lck: "<<lck<<"\n\n";
            cout<<"Weapon: "<<weap.showName()<<"\n";
            cout<<"Armor: "<<arm.showName()<<"\n";
            cout<<"Accessory: "<<acc.showName()<<"\n";
            cout<<"Inventory: "<<inv.showName()<<"\n";
            cout<<"\n";
        }
		else cout<<"You're not traveling with anyone!\n";
	}

	//Decide whether to use a spell or an attack
	int chooseAttack(string e_weak, int e_def)
	{
	    int pts=0;

	    //If enemy defense is greater than attack
	    if(e_def>atk) {cout<<"Debug: pts +1 (edef>atk)\n"; pts++;}
	    //If enemy defense is greater than attack and strength combined
	    if(e_def>atk+str) {cout<<"Debug: pts +2 (edef>atk+str)\n"; pts+=2;}
	    //If half spell max damage is greater than basic max damage
	    if(splist[iab].maxd/2>=atk+str) {cout<<"Debug: pts +2 (spell damage>2*atk+str)\n"; pts+=2;}
	    //If the spell type is the enemy's weakness
	    if(splist[iab].elem==e_weak) {cout<<"Debug: pts +2 (spell element = enemy weakness)\n"; pts+=2;}
	    //If intellect is higher than strength, and the spell deals magic damage
	    if(intl>str&&splist[iab].elem!="sword") {cout<<"Debug: pts +2 (spell type=sword & str>int)\n"; pts++;}
	    //Choices based on AI
	    if(ai=="cunning") {cout<<"Debug: pts +1 (AI = cunning)\n"; pts++;}
	    if(ai=="aggressive") {cout<<"Debug: pts -1 (AI = agressive)\n"; pts--;}
	    //If the player is out of mana
	    if(mp<splist[iab].cost) {cout<<"Debug: pts = 0 (mana is empty)\n"; pts=0;}

	    cout<<"Debug: attack points: "<<pts<<"\n";

	    //Essentially, if two or more cases are true, return true
	    if(pts>=3) return 0;
	    else return 1;
	}

	//Choose one action outside of combat, besides idling
	void chooseAction()
	{
	    //Check experience, level up
	    lvlup();
	    //If health is less than 50% drink a health potion
	    if(checkHealth()>3) {if (hpot>0) drinkPot("health"); else if(inv.type=="food") consume();}
	    //If mana is less than 50% drink a mana potion
	    else if(mp<mpmax/2&&hpot>0) drinkPot("mana");
	    //Check if favored gear is equipped, or if none is worn
	    else if(inv.type=="weapon") if((inv.subt==wpref&&weap.subt!=wpref)||(inv.subt==wpref&&inv.atkb>weap.atkb)||(inv.atkb>weap.atkb&&weap.subt!=wpref))
        {
            cout<<"\n"<<name<<" looks at the weapon in their bag, and after deliberating a moment,\ndecides to keep it handy, giving it a few test swings.\n\n";
            equipment temp;
            //Set temporary item to inventory item
            temp=inv;
            //Move weapon to inventory
            inv=weap;
            //Remove stats
            if(weap.name!="empty") unequip(weap);
            //Set weapon to temporary item
            weap=temp;
            //Add new item stats
            equip(weap);
        }
        else if(inv.type=="armor") if((inv.subt==apref&&arm.subt!=apref)||arm.name=="empty")
        {
            cout<<"\n"<<name<<" looks at the armor in their bag, and\nafter deliberating a moment, decides to put it on.\n";
            equipment temp;
            temp=inv;
            inv=arm;
            if(arm.name!="empty") unequip(arm);
            arm=temp;
            equip(arm);
        }
        else if((inv.type=="accessory"&&inv.subt==cpref&&arm.subt!=cpref)||acc.name=="empty")
        {
            cout<<"\n"<<name<<" looks at the accessory in their bag, and\nafter deliberating a moment, decides to put it on.\n";
            equipment temp;
            temp=inv;
            inv=acc;
            if(acc.name!="empty") unequip(acc);
            acc=temp;
            equip(acc);
        }
        else
            if ( roll(6) ) idles();
            else return;
	}//End of chooseAction()

	//End of character struct
} empty1, grognak, luz, frost, aldo, luci;

struct side_char
{
    //Essentially cosmetic characters
    string c_type, dest, age, adj, mf, n, pos, pos_up, pers, pers_up, obj, obj_up, idle[6];
    int x, y;

    string showName(string type)
    {
        string name="";
        if(type=="full") name=adj+" "+age+" "+n;
        else if(type=="adjn") name=adj+" "+n;
        else if(type=="agen") name=age+" "+n;
        else if(type=="adjmf") name=adj+" "+mf;
        else if(type=="agemf") name=age+" "+mf;
        else name = n;

        return name;
    }

    void initialize(bool preload)
    {
        int type_age=roll(2)-1;
        int type_adj=roll(7)-1;
        int type_mf=roll(2)-1;
        int type_n=roll(7)-1;

        string s_age[2] = {"old", "young"};
        string s_adj[7] = {"serious", "carefree", "adventurous", "businesslike", "warlike", "somber", "prim"};
        string s_n[7] = {"minstrel", "merchant", "artificer", "pilgrim", "hunter", "noble", "magician"};
        string s_mf[2] = {"man", "woman"};

        if(!preload)
        {
            age=s_age[type_age];
            adj=s_adj[type_adj];
            mf=s_mf[type_mf];
            n=s_n[type_n];
        }

        if (mf=="man")
        {
            pos="his"; pos_up="His";
            pers="he"; pers_up="He";
            obj="him"; obj_up="Him";
        }
        if (mf=="woman")
        {
            pos="her"; pos_up="Her";
            pers="she"; pers_up="She";
            obj="her"; obj_up="Her";
        }

        idle[0] = "smoking a pipe";
                    if(adj=="prim") idle[0] = "writing a letter";
                    if(adj=="carefree") idle[0] = "picking flowers";
        idle[1] = "scanning the horizon";
                    if(n=="artificer") idle[1] = "tinkering with some device";
        idle[2] = "examining some trail markings";
                    if(adj=="prim") idle[2] = "sketching the scenery";
                    if(n=="magician") idle[2] = "staring intensely into a glass orb";
        idle[3] = "reading a book";
                    if(n=="merchant") idle[3] = "writing down sales in a ledger";
                    if(adj=="carefree") idle[3] = "climbing a tree";
                    if(adj=="warlike") idle[3] = "swinging " + pos + " sword";
        idle[4] = "resting on a seat";
                    if(adj=="adventurous") idle[4] = "writing a journal entry";
        idle[5] = "mending a cloak";
                    if(n=="noble") idle[4] = "brushing some dirt from "+pos+" cloak";
                    if(n=="magician") idle[4] = "muttering an incantation";

        if(n == "noble") n += mf;
    }

    void create(string sadj, string sage, string sn, string smf)
    {
        adj = sadj;
        age = sage;
        mf = smf;
        n = sn;

        initialize(1);
    }

    void showIdle(string inc, string s_name)
    {
        int n_name=0;
        //List of name concatenation types
        string s_nType[7]={"full", "adjn", "agen", "adjmf", "agemf", "mf", "n"};
        //Choose a random idling text
        int n_idle=roll(6)-1;
        //If no name specified, choose random
        //Excludes full name by default
        if(s_name=="null") n_name=roll(6);
        else s_nType[n_name] = s_name;
        //Decide how much sentence structure to add
        if(inc=="y"||inc=="full")cout<<"The ";
        //Display name for character
        cout<<showName(s_nType[n_name]);
        //Additional detail
        if(inc=="full")
            cout<<" you're traveling with";
        cout<<" is ";
        //Print idle text
        cout<<idle[n_idle]<<" nearby.\n";
    }

    void showAppearance()
    {
        if(c_type=="lost")
            cout<<"This "<<adj<<" "<<age<<" "<<mf<<" is a "<<n<<"\n"<<" journeying to "<<dest<<".\n";
    }

    void talk()
    {
        //"minstrel", "merchant", "artificer", "pilgrim", "hunter", "noble"
        /*Add NPCs from Tutorial Island*/
        cout<<"\n";
        //Output a unique comment for each character type
        if(n == "merchant") cout << "'Nearly there, now, aren't we?'\n";
        if(n == "wizard") cout << "'Nearly there, now, aren't we?'\n";
        if(n == "minstrel") cout << "The minstrel launches into a jubilant ballad. Before you know it,\nyou're singing along, clapping your hands to the beat.\n";
        if(n == "artificer") cout << pers_up << " looks up from affixing a crystal into some small machine.\n'Yes? What is it?'\n";
        if(n == "pilgrim") cout << "'We should visit the Temple of Light on our way.'\n";
        if(n == "hunter") cout << "'Keep an eye out for dangerous animals.\nI don't see any, but you never know.'\n";
        if(n == "nobleman"||n == "noblewoman") cout << "'I can't believe I'm traveling like this!\n...no servants, no horses or carriage...\nI'tll be a wonder if I survive at all...'\n";
    }

}lost, sick, needful, weak;

struct shop
{
    string name, desc, greeting, error, purchase, leave;
    int wares_max, id;
    string ext_desc;
    vector <int> wares_id;
    vector <equipment> wares;

    void showInfo()
    {
         cout << "\n";
        colSet(240, name);
        cout << "\n\n" << desc << "\n";
    }

    void buyMenu(int gp)
    {
        cout << "\n" << greeting;
        cout << "\nGold: " << gp << "\n";
        cout << "\n\n  Item\t\t\t|  Price\n";
        cout << "+-----------------------+-------------+\n";
        for(int x = 1; x < wares_max; x++)
        {
            cout << "[" << x << "] --- ";
            cout << wares[x].showName(); if(wares[x].mat == "none") cout << "\t";
            cout << "\t| "<< wares[x].price << "gp\n";//output wares menu
        }
        cout << "[" << exit << "] Exit\n";
    }

} shops[12];

struct static_object
{
    string name, desc;
    int cap;
    string adj;
    vector<equipment> contents;

    void display_contents()
    {
        cout<<"The "<<name<<" contains: \n";
        if(contents.size()>0){
        for(int x=0; x<contents.size(); x++)
        {
            if(contents[x].name!="null")
                cout<<"("<<x<<"): "<<contents[x].mat<<" "<<contents[x].name<<"\n";
        }}
        else cout<<"Absolutely nothing!\n";
    }
} null_object, chest, table, chair, planter, bed, anvil, oven, obelisk, static_object_list[10];

struct terrain_object
{
    string name, desc;
    int id;
} tobj[20];

struct decoration
{
    string name, desc, loc;
};

struct building
{
    string name, ext_desc, int_desc;
    int wreq, ireq, sreq;
    vector<static_object> objects;
    vector<decoration> deco;
    npc loc_npc;
    bool complete;

    void display_exterior()
    {
        cout<<ext_desc;

        for(int x=0;x<deco.size();x++)
            if(deco[x].name!="null"&&deco[x].loc=="outside") cout<<"There is a "<<deco[x].name<<" outside it.\n";
    }

    void displayObjects()
    {
        if(objects.size()>0)
        for(int x=0;x<objects.size();x++)
            {
                cout<<"-"<<objects[x].name<<"\n";
            }
    }

    void display_interior()
    {
        cout<<"\n"<<name;
        cout<<"\n\n";
        cout<<int_desc;

        for(int x=0;x<deco.size();x++)
            if(deco[x].name!="null") cout<<"There is a "<<deco[x].desc<<" "<<deco[x].name<<" on the "<<deco[x].loc<<".\n";

        for(int x=0;x<objects.size();x++)
            if(objects[x].name!="null") {cout<<"There is a "<<objects[x].adj<<" "<<objects[x].name<<" here.\n";}

        if(loc_npc.name!="null")
            cout<<loc_npc.name<<" is "<<loc_npc.idle<<" nearby.\n";

        cout<<"\n";
    }

    int build(int wd, int ir, int st)
    {
        int inp=0;
        int material_used=0;

        if(!complete)
        {
            loc_npc=nlist[0];
            cout<<"This building is not yet complete.\n";
            cout<<"Materials needed:\n";
            cout<<"Wood: "<<wreq<<"; Iron: "<<ireq<<"; Stone: "<<sreq<<"\n\n";
            cout<<"Add which materials to the building site?\n";
            cout<<"(1) Wood\n(2) Iron\n(3) Stone\n";
            inp=check_int();
            switch(inp)
            {
                case 1:
                {
                    if(wd>0)
                    {
                        cout<<"You take your tools in hand and add a piece of wood to the the framing.\n";
                        wreq--;
                        material_used=1;
                    }
                    else cout<<"You don't have any wood!\n";
                }
                break;
                case 2:
                {
                    if(ir>0)
                    {
                        cout<<"You take your tools in hand and add a piece of iron to the the framing.\n";
                        ireq--;
                        material_used=2;
                    }
                    else cout<<"You don't have any iron!\n";
                }
                break;
                case 3:
                {
                    if(st>0)
                    {
                        cout<<"You take your tools in hand and add a piece of stone to the foundation.\n";
                        sreq--;
                        material_used=3;
                    }
                    else cout<<"You don't have any stone!\n";
                }
                break;
            }
        }
        else
            cout<<"\nThis building is complete! No more construction needed.\n";

        if(wreq==0&&ireq==0&&sreq==0&&!complete)
        {
            cout<<"\nYou lay the last stone and hammer in the last nail.\nIt's done! You've finally finished building the "<<name<<"!\n";
            complete=true;
        }

        //send back which material was used to remove from player inventory
        //no materials used is default 0
        return material_used;
    }//end of build function

}null_bldg, house;

struct envinpc
{
	string name;
	int dex, hp, drop, id, lvl;
	string idle, desc;
	bool is_alive;

} anim[30];

struct flora
{
    string name, idle, desc;
    int item, id;
} plant[30];

struct area
{
    //variables defined by area index
	string name;
	string desc;
	int echance;
	bool water, wood, mine, smithy, armory, toolshop, potshop, north, south, east, west;
	int x, y, id;
	string key;
	int map_color1, map_color2;
	bool is_outside;
	string world;

	//static but defined outside declaration
	npc npcs[3];
	int enemies[3];
    shop loc_shop;
    building loc_bldg;

    //Dynamic objects
    vector<shop> local_shops;
    vector<enem> local_enemies;
    vector<npc> local_NPCs;

	//dynamic variables
	bool sheep, crops, plantd, fire, herbs;
	int visits, lastvisitday, chest;

    enem foe;

	//items/static objects
	equipment loot;
	vector<terrain_object> terr_obj;
	terrain_object loc_tobj;
	vector<static_object> obj;
	static_object loc_obj;

	//Signs
	vector<sign> signs;

	//environment, plants and animals
    envinpc loc_fauna;
	flora loc_flora;
	vector<envinpc> fauna_types;
	vector<flora> flora_types;

	void setProcNPC()
	{
	    if(npcs[2].name=="null"||npcs[2].name=="none")
	    {
	        npcs[2]=cast_npc[rand()%2+1];
	        npcs[2]=cast_npc[2];
            npcs[2].q.setProcQuest();
            npcs[2].appendQ();
	    }
        else return;
	}

	void readSign()
	{
	    string inp;
	    if(signs.size()==0) {cout<<"There aren't any signs to read here!\n"; return;}
	    if(signs.size()>1)
        {
            cout<<"Which sign did you want to read? There's a\n";
            for(int ct=0; ct<signs.size();ct++)
            {
                cout<<"-"<<signs[ct].name<<" sign\n";
            }
            cin>>inp;
            for(int ct=0; ct<signs.size();ct++) if(inp==signs[ct].name) signs[ct].read();
        }
        else signs[0].read();
	}

	void setIsOutside()
	{
	    if(name=="Main Hall"||name=="Throne Room"||name=="Ballroom"||name=="Dungeon"||name=="Grand Hall"||name=="Glacial Palace"||name=="Arcanum"||name=="Serpents' Den"||name=="Temple of Light"||name=="Elven Workshop"||name=="Dark Cave"||name=="Night Maze")
        {
            is_outside=false;
        }
        else {is_outside=true;}
	}

	void load_flora()
	{
	    if( flora_types.size() > 0){
            int ftype = rand() % ( flora_types.size() ) + 1;
            if(roll20(3)) loc_flora = flora_types[ftype];
            else loc_flora=plant[0];}
        else loc_flora=plant[0];
    }

	void load_fauna()
	{
	    if( fauna_types.size() > 0 ){
            int ftype = rand()% ( fauna_types.size() ) + 1;
            if( roll20(2) ) loc_fauna = fauna_types[ftype];
            else loc_fauna = anim[0];}
        else loc_fauna = anim[0];
	}

	void display_env()
	{
	    for (int ct=0;ct<3;ct++)
        {
            if(npcs[ct].name!="null"&&npcs[ct].name!="")
                {colSet(9, npcs[ct].name); cout<<" is "<<npcs[ct].idle<<" nearby.\n";}
        }
        if(signs.size()>0)
        {
            for(int ct=0;ct<signs.size();ct++)
            {
                cout<<"There is a "<<signs[ct].name<<" sign here.\n";
            }
        }
        if(local_shops.size() > 0)
        {
            for(int ct = 0; ct < local_shops.size(); ct++)
            {
                cout<<"You see a "; colSet(14, "shop"); cout<<"; there's "<<local_shops[ct].ext_desc<<" nearby.\n";
            }
        }
	    if(loc_bldg.name!="null"&&loc_bldg.name!="")
            cout<<"There is a "<<loc_bldg.name<<" nearby.\n";
	    if(loc_shop.name!="null")
            {cout<<"You see a "; colSet(14, "shop"); cout<<"; there's "<<loc_shop.ext_desc<<" nearby.\n";}
	    if(loc_fauna.name!="null")
            cout<<"There is a "<<loc_fauna.name<<" "<<loc_fauna.idle<<" nearby.\n";
        if(loc_flora.name!="null")
            cout<<"There is a "<<loc_flora.name<<" "<<loc_flora.idle<<" nearby.\n";
	}
}loc[11][11], extra[20];

area area_search(string name)
{
    for (int x = 0; x < 11; x++)
        for (int y = 0; y < 11; y++)
    {
        if (loc[x][y].name == name) return loc[x][y];
    }
}

struct point_2d
{
    int x, y;
};

int getAreaID(string name)
{
    for (int y = 0; y < 11; y++)
        for (int x = 0; x < 11; x++)
    {
        if(loc[x][y].name == name)
            return loc[x][y].id;
    }
}

struct custom_c
	{
	    string key, c[3];
	    string full_c;
	} command_1;

struct custom_c2
	{
	    string key;
	    string command;
	} c_custom2;

struct body_part{
    string n, con, det;
    int hp;

    void showCon()
    {
        if(con!=""&&con!="null")cout<<"Your "<<n<<" is "<<con<<".\n";
    }
    void showDet()
    {
        cout<<"There is a "<<det<<" on your "<<n<<"\n";
    }
    void setCon(string new_con)
    {
        con=new_con;
    }
    void setDet(string new_det)
    {
        if(det!="null")
            det=new_det;
        else
        {
            string inp;
            cout<<"There is already a "<<det<<" there. Replace it?\n";
            cin>>inp;
            if(inp=="y"||inp=="yes")
            {
                det=new_det;
            }
        }
    }
};

struct player_body{
    body_part head, r_arm, l_arm, l_leg, r_leg, heart, mind;
    int ht, wt, age, rid;
    race p_race;
    string sex, build, eyec, hairc, skinc, tat;
    string desc;
    string status;

    void constructBody(int rida, string sexa, int hta, int wta, int agea, string builda, string eyeca, string hairca, string skinca, string tata)
    {
        status="healthy";
        head={"head", "undamaged", "null"};
        r_arm={"right arm", "undamaged", "null"};
        l_arm={"left arm", "undamaged", "null"};
        r_leg={"right leg", "undamaged", "null"};
        l_leg={"left leg", "undamaged", "null"};
        sex=sexa; wt=wta; tat=tata;
        ht=hta; age=agea; build=builda;
        eyec=eyeca; hairc=hairca; skinc=skinca;
        rid=rida; p_race=races[rid];
        desc=p_race.desc;
    }

    void showCon()
    {
        head.showCon();
        r_arm.showCon();
        l_arm.showCon();
        r_leg.showCon();
        l_leg.showCon();
    }

    void showDesc()
    {
        cout<<"You are a "<<p_race.name<<" "<<sex<<",\nstanding "<<ht<<"cm tall and weighing "<<wt<<" pounds.\n";
        cout<<desc;
        cout<<"You are "<<age<<" years old.\n";
        if(tat!="none"&&tat!="null") cout<<"There is a "<<tat<<" tattoo on the back of your hand.\n";
        if(head.det!="null")head.showDet();
        if(r_arm.det!="null")r_arm.showDet();
        if(l_arm.det!="null")l_arm.showDet();
        if(r_leg.det!="null")r_leg.showDet();
        if(l_leg.det!="null")l_leg.showDet();
    }
};

struct player
{
    //character appearance
	string name, sex, race;
	int height, wt, age;
	string build, eyec, hairc, skinc, tat, clas, guild_class, status;
    player_body body;

    //Character Background
    string voice, att, story, trade;

	//input
	string inp;
	vector<custom_c> custom_commands;
	vector<custom_c2> custom_commands2;

	//character stats
	int hp, hpmax;
	int mp, mpmax;
	int atk, def;
	int str, dex, intl, lck, lvl, xp, xpnxt, gp;

	//Survival
	int hunger, hung_max, thirst, thirst_max;

	//inventory
	equipment weap, arm, acc, inv[11];
	int carrywt, carrywtmax, hpot, mpot, apot;

	//skills
	int craft_tot, surv_tot, ac_tot;
	int bait, frod, flvl;
	int mlvl, smlvl, clvl, wclvl, fmlvl, cklvl, hlvl, swlvl, enchlvl, muslvl, litlvl, frglvl;
	int skills[12];
	string s_skills[12] = {"woodcutting", "firemaking", "mining", "fishing", "cooking", "woodworking", "smithing", "sewing", "enchanting", "hunting"};

	//tools
	bool ham, chis, axe, tbox, need, shears, pick, quill, sheath;
	equipment sheathed;
	bool quiv;
	int arrows;

	//#other
	area area; //current location
	special casting; //active spell, mostly for combat
	character comp; //companion slot, default is empty companion struct
	int karma;
	string karma_lvl; //karmic titles
	int fairy_missive; //side quest. has an associated inventory tag.

	void get_skill_totals()
	{
	    surv_tot = fmlvl + cklvl + hlvl + frglvl + mlvl + wclvl + flvl;
	    craft_tot = enchlvl + clvl + smlvl + swlvl;
	}

	string getInps()
	{
	    string input;
	    cout << ">";
	    cin >> input;
	    return input;
	    cout << "~+--------------------+~\n";
	}

	int getInpn()
	{
	    int input;
	    cout << ">";
	    cin >> input;
	    while(!input)
        {
            prln("Input error; Please enter a number:");
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); //GPT
            cout << ">";
            cin >> input;
        }
        cout << "~+--------------------+~\n";
	    return input;
	}

	string getInpLn()
	{
	    string inp = "";
	    cout << ">";
	    cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        getline(cin, inp);
        cout << "~+--------------------+~\n";
        return inp;
	}

	void healthBar()
	{
	    //Percentage display
	    int hpct = pctOf(hp, hpmax);
	    if(hpct < 0) hpct = 0;
	    cout<<"   HP: "<<hp<<"/"<<hpmax<<"  ("<<hpct<<"%)\n";
	    //Status bar (scales to n:50)
        c_status_bar(hpmax, hp, COL_RED, 100, "{[", "]}", "/", "-");
	}

	void manaBar()
	{
	    int mpct = pctOf(mp, mpmax);
	    if(mpct < 0) mpct = 0;
	    cout<<"   MP: "<<mp<<"/"<<mpmax<<"  ("<<mpct<<"%)\n";
        c_status_bar(mpmax, mp, COL_BLUE, 100, "{[", "]}", "/", "-");
	}

	void xpBar()
	{
	    int xpct = pctOf(xp, xpnxt);
	    if(xpct < 0) xpct = 0;
	    cout<<"   XP: "<<xp<<"/"<<xpnxt<<"  ("<<xpct<<"%)\n";
        c_status_bar(xpnxt, xp, COL_YELLOW, 100, "{[", "]}", "/", "-");
	}

	void showHunger() { if (game_settings.survival) cout << "Hunger: " << hunger << "%"; }
	void showThirst() { if (game_settings.survival) cout << "Thirst: " << thirst << "%"; }

	void hungerBar()
	{
	    cout << "            "; showHunger(); cout << "\n";
        c_status_bar(hunger, 100, COL_ORANGE, 100, "{[", "]}", "/", "-");
	}

	void thirstBar()
	{
	    cout << "            "; showThirst(); cout << "\n";
        c_status_bar(thirst, 100, COL_BLUE, 100, "{[", "]}", "/", "-");
	}

	void setHunger(int change)
	{
	    hunger += change;

	    if (hunger > 100) hunger = 100;
	    if (hunger < 0) hunger = 0;
	}

	void setThirst(int change)
	{
	    thirst += change;

	    if (thirst > 100) thirst = 100;
	    if (thirst < 0) thirst = 0;
	}

	void showSurvival()
	{
	    if (game_settings.survival) {
            showHunger();
            cout << "     ";
            showThirst();
            cout << "\n";
        }
	}

	void statscrn()
    {
        cout<<"\n             "<<name<<", Level "<<lvl<<" "<<race<<" "<<clas<<"\n";
        cout<<"                    Status: "<<status<<"\n";
        healthBar();
        manaBar();
        xpBar();
        showSurvival();
        cout<<"\nAtk: "<<atk<<"   Def: "<<def<<"\n";
        cout<<"\nStrength: "<<str<<"\n";
        cout<<"Dexterity: "<<dex<<"\n";
        cout<<"Intellect: "<<intl<<"\n";
        cout<<"Luck: "<<lck<<"\n\n";
    }

    void showEquipment()
    {
        if(weap.name!="empty") cout << "In your dominant hand, you hold " << aoranf(weap.showName(), 0) << ".\n";
        if(arm.name!="empty") cout << "You are wearing " << arm.showName() << ".\n";
        if(acc.name!="empty") cout << "You are also equipped with " << aoranf(acc.showName(), 0) << ".\n";
    }

    void showChar()
    {
        cout<<"\n"<<name<<":\n";
        cout<<"\nYou are "<<aoranf(race, 0) << " ";
        if(sex!="none"){cout<<sex<<" ";}
        if(build!="none"){ cout << "with " << aoranf( build, false ) << " build, \n"; }
        if(hairc!="none"){cout<<hairc<<" hair, ";}
        if(skinc!="none"){cout<<skinc<<" skin, ";}
        if(eyec!="none"){cout<<"and "; if(clas == "Avatar") cout << "glowing "; cout <<eyec<<" eyes.\n";}
        cout<<"You stand "<<height<<"cm tall and weigh "<<wt<<" pounds.\n";
        if(tat!="none"){cout<<"\nThere is a "<<tat<<" tattoo on the back of your hand.\n";}
        cout<<"\nYou are "<<age<<" years old, and have chosen to follow the path of the "<<clas<<".\n\n";
        showEquipment();
        cout<<"\nBased on your actions, you are generally "<<karma_lvl<<".\n";
    }

    void showStory()
    {
        cout << story << "\n";
    }

    void showSkills()
{
    get_skill_totals();

	cout << "Survival:  [" << surv_tot << " / 140 total]\n\n";

	cout<<"  Woodcutting \t-------- "<<wclvl<<"\n";
	cout<<"  Firemaking \t-------- "<<fmlvl<<"\n";
	cout<<"  Hunting \t-------- "<<hlvl<<"\n";
	cout<<"  Foraging \t-------- "<<frglvl<<"\n";
	cout<<"  Fishing \t-------- "<<flvl<<"\n";
	cout<<"  Cooking \t-------- "<<cklvl<<"\n";
	cout<<"  Mining \t-------- "<<mlvl<<"\n\n";

	cout<<"Crafting  [" << craft_tot <<" / 140 total] \n\n";

	cout<<"  Smithing \t-------- "<<smlvl<<"\n";
	cout<<"  Woodworking \t--------  "<<clvl<<"\n";
	cout<<"  Enchanting \t-------- "<<enchlvl<<"\n";
	cout<<"  Sewing \t-------- "<<swlvl<<"\n\n";

	cout<<"Academic [" << litlvl + muslvl << " / 40 total] \n\n";
	cout<<"  Literacy \t-------- "<<litlvl<<"\n";
	cout<<"  Music \t-------- "<<muslvl<<"\n";
}

    void showCon() { cout<<"\nYou are "<<status<<".\n"; }

    void showHealth()
    {
        const int hpt = pctOf(hp, hpmax);

        if( game_settings.status_display != "text" )
        {
            healthBar();
            return;
        }

        string health[7]={"in perfect health", "lightly bruised", "a little battered", "wounded", "bleeding profusely", "severely injured", "near death"};

        //Describe severity of wounds by percentage of health missing
        cout<<"You are ";
        switch(hpt)
        {
        case 1 ... 10: {cout<<health[6];} break;
        case 11 ... 25: {cout<<health[5];} break;
        case 26 ... 50: {cout<<health[4];} break;
        case 51 ... 75: {cout<<health[3];} break;
        case 76 ... 90: {cout<<health[2];} break;
        case 91 ... 99: {cout<<health[1];} break;
        case 100: {cout<<health[0];} break;
        default: cout<<"unable to tell what condition you're in";
        }

        cout<<".\n";

        //Display status, such as poisoned or paralyzed
        if(status!="null"&&status!="OK"&&status!="ok"&&status!="none") showCon();

        body.showCon();
    }

    void showMana()
    {
        const string mp_desc[6] = {"full of energy", "somewhat drained", "feeling strained", "feeling weak", "losing focus", "utterly exhuasted"};
        const int mp_pct = pctOf(mp, mpmax);

        if( game_settings.status_display != "text" )
        {
            manaBar();
            return;
        }

        cout<<"\nYou are ";
        switch(mp_pct)
        {
            case 1 ... 10: {cout<<mp_desc[6];} break;
            case 11 ... 25: {cout<<mp_desc[5];} break;
            case 26 ... 50: {cout<<mp_desc[4];} break;
            case 51 ... 75: {cout<<mp_desc[3];} break;
            case 76 ... 90: {cout<<mp_desc[2];} break;
            case 91 ... 99: {cout<<mp_desc[1];} break;
            case 100: {cout<<mp_desc[0];} break;
            default: {cout<<"unable to tell what condition you're in";} break;
        }
        cout<<".\n";
    }

    void loadSkillPtrs()
    {
        skills[0] = wclvl;
        skills[1] = fmlvl;
        skills[2] = mlvl;
        skills[3] = flvl;
        skills[4] = cklvl;
        skills[5] = clvl;
        skills[6] = smlvl;
        skills[7] = swlvl;
        skills[8] = enchlvl;
        skills[9] = hlvl;
        skills[10] = frglvl;
        skills[11] = muslvl;
    }

    void getCustomCommand()
    {
        custom_c temp;

        for(int num=1;num<4; num++)
        {
            cout<<"Enter command #"<<num<<": \n";
            cin>>temp.c[num-1];
            temp.full_c+=temp.c[num-1]+" ";
        }
        cout<<"Enter keyword command to use for these three commands:\n";
        cin>>temp.key;
        cout<<temp.full_c<<"\n";

        custom_commands.push_back(temp);
    }

    void getCustomCommand2()
    {
        custom_c2 temp;

        cout << "\nEnter the keyword or character to use for this command:\n";
        temp.key = getInps();
        cout << "\nEnter the command to be executed:\n";
        temp.command = getInps();

        custom_commands2.push_back(temp);
    }

    void showCustomCommands2()
    {
        for( int n=0; n < custom_commands2.size(); n++ )
        {
            cout << "Keyword: " << custom_commands2[n].key<< "\n";
            cout << "Command: ";
            cout << custom_commands2[n].command << " " << "\n\n";
        }
    }

    void showCustomCommands()
    {
        for(int n=0;n<custom_commands.size();n++)
        {
            cout<<"Keyword: "<<custom_commands[n].key<<"\n";
            cout<<"Commands: ";
            for(int n2=0;n2<2;n2++)
            {
                cout<<custom_commands[n].c[n2]<<" ";
            }
            cout<<"\n\n";
        }
    }

    void showInv()
    {
        int n_items = 0;

        cout<<"\n\nYou are holding:\n";
        for(int x=1;x<11;x++)
        {
           if(inv[x].name != "empty")
            {
                cout<<"["<<x<<"]   -";
                if(inv[x].mat != "none" ) cout<<aoran(inv[x].mat, true);
                else cout<<aoran(inv[x].name, true);
                cout<<inv[x].showName()<<"\n";
                n_items++;
           }
        }
        cout << "Inventory space: " << n_items << "/" << "10\n";
        cout<<"\n\n";
    }

    void showInvType(string type)
    {
        int n_items = 0;

        cout<<"\n\nYou are holding:\n";
        for(int x=1;x<11;x++)
        {
           if(inv[x].type == type)
            {
                cout<<"["<<x<<"]   -";
                if(inv[x].mat != "none" ) cout<<aoran(inv[x].mat, true);
                else cout<<aoran(inv[x].name, true);
                cout<<inv[x].showName()<<"\n";
                n_items++;
           }
        }
        cout << "You have " << n_items << " " << type << "s in total.\n";
        cout<<"\n\n";
    }

    int invCount(string mat, string name)
    {
        int n = 0;
        for (int i = 0; i < 10; i++)
            if (inv[i].mat == mat && inv[i].name == name)
                n++;
        return n;
    }

    void saveInventory()
    {
        for (int i = 0; i < 10; i++)
        {
            inv[i].saveToFile(name, "_inv" + to_string(i), inv[i].id);
            prln("Saved " + inv[i].name + " to file");
        }
    }

    void loadInventory()
    {
        for (int i = 0; i < 10; i++)
        {
            inv[i].loadFromFile(name, "_inv" + to_string(i), inv[i].id);
            prln("Loaded " + inv[i].name + " from file");
        }
    }

    bool checkStatsAreHigher(int str2, int dex2, int intl2, int lck2)
    {
        if (str > str2
            || dex > dex2
            || intl > intl2
            || lck > lck2) {return true;
            cout << "\Debug: Check stats are higher\n";}
        else return false;
    }

    int searchInvTypeFrom(string type, int start_slot)
    {
        for (int i = start_slot; i < 11; i++) if ( i < 11 && inv[i].type == type ) return i;
            else return 0;
    }

    int searchInvFrom(string name, string mat, int start_slot){
        for (int i = start_slot; i < 11; i++) if ( i < 11 && inv[i].name == name && inv[i].mat == mat ) return i;
            else return 0;
    }

    int searchInvName(string name){
        for (int i = 1; i < 11; i++) {cout << "Debug: " << name << " - check against - " << inv[i].name << "\n"; if ( i < 11 && inv[i].name == name )  { return i; } }
            return 0;
    }

    void setAttributes()
    {
        int step = 0;
        int pct_comp = 0;
        string att[8] = { "tone of voice", "attitude", "hair color", "eye color", "skin color", "build", "height", "weight" };
        string att_T[8] = { "voice", "att", "hairc", "eyec", "skinc", "build", "height", "weight" };
        cout << "\nSet Your Character's Attributes:\n";
        cout << "\n -> Use one word for each of the following:\n\n";

        for (int i = 0; i < 6; i++)
        {
            cout << "\nWhat is your " << att[i] << "?\n";
            inp = getInps();
            set(att_T[i], 0, inp);
        }
    }

    void unequip(int num, string target)
{
	int x = searchInvName("empty");
	string item;
	string name, mat;
	//Find an empty inventory slot or drop the item
    if ( !x ) target = "drop";

	if(num==1)
	{
	    //Save item name for reference
	    mat=weap.mat;
	    name=weap.name;
		//copy weapon to inv
		if (target == "inv")
            { inv[x] = weap; }
        else if (target == "drop")
            { area.loot = weap; }
        else if (target == "destroy")
            { /*Do nothing; item is lost*/ }
		//remove stat changes
		atk-=weap.atkb;
		def-=weap.defb;
		str-=weap.strb;
		dex-=weap.dxb;
		intl-=weap.intb;
		lck-=weap.lckb;
		//set weapon to none
		weap=eq[0];
		//weapon moved to inv not worn
		inv[x].worn=false;
	}
	else if(num==2)
	{
	    mat=arm.mat;
	    name=arm.name;
		if (target == "inv")
            {inv[x] = arm;}
        else if (target == "drop")
            {area.loot = arm;}
        else if (target == "destroy")
            { /*Do nothing; item is lost*/ }
		atk-=arm.atkb;
		def-=arm.defb;
		str-=arm.strb;
		dex-=arm.dxb;
		intl-=arm.intb;
		lck-=arm.lckb;
		arm=eq[0];
		inv[x].worn=false;
	}
	else if(num==3)
	{
	    mat=acc.mat;
	    name=acc.name;
		if (target == "inv")
            {inv[x] = acc;}
        else if (target == "drop")
            {area.loot = acc;}
        else if (target == "destroy")
            { /*Do nothing; item is lost*/ }
		atk-=acc.atkb;
		def-=acc.defb;
		str-=acc.strb;
		dex-=acc.dxb;
		intl-=acc.intb;
		lck-=acc.lckb;
        //Removing the cloth obi also removes sheath slot
        if(acc.name=="obi") sheath=false;
		acc=eq[0];
		inv[x].worn=false;
	}
	//Display the action
	item=mat+" "+name;
	if(name!="empty") cout<<"\nYou remove the "<<item<<".\n";
}

    void equip(int num, bool frominv, bool showmessage)
    {
	int x = 0;
	string item;

	if(frominv==false)
	{
        if( eq[ num ].type == "armor" )
        {
            //move existing armor to inv
            unequip(2, "inv");
            //set armor from eq. list
            arm=eq[num];
            arm.worn=true;
        }
        else if(eq[num].type=="weapon")
        {
            unequip(1, "inv");
            weap=eq[num];
            weap.worn=true;
        }
        else if(eq[num].type=="accessory")
        {
            unequip(3, "inv");
            acc=eq[num];
            acc.worn=true;
        }
        inv[x].worn=false;
	}
	else
	{
	    if(inv[num].wt > str) {prln("You can barely lift that, let alone wield it!"); return;}
        item = inv[num].showName();
        if(inv[num].type=="armor")
        {
            unequip(2, "inv");
            arm=inv[num];
            arm.worn=true;
            inv[num]=eq[0];

            atk+=arm.atkb;
            def+=arm.defb;
            str+=arm.strb;
            dex+=arm.dxb;
            intl+=arm.intb;
            lck+=arm.lckb;
        }
        else if(inv[num].type=="weapon")
        {
            unequip(1, "inv");
            weap=inv[num];
            weap.worn=true;
            inv[num]=eq[0];

            atk+=weap.atkb;
            def+=weap.defb;
            str+=weap.strb;
            dex+=weap.dxb;
            intl+=weap.intb;
            lck+=weap.lckb;
        }
        else if(inv[num].type=="accessory")
        {
            unequip(3, "inv");
            acc=inv[num];
            acc.worn=true;
            if(acc.name=="obi") sheath=true;
            inv[num]=eq[0];

            atk+=acc.atkb;
            def+=acc.defb;
            str+=acc.strb;
            dex+=acc.dxb;
            intl+=acc.intb;
            lck+=acc.lckb;
        }
        else {cout<<"\nYou can't wear that!\n"; return;}
	}
        if (showmessage) cout<<"\nYou equip the "<<item<<".\n";
    }

    void createNew( string sname, string ssex, string srace, string sbuild, string seyec, string shairc, string sskinc, string stat, string sclas,
        int sheight, int swt, int sage, int shpmax, int smpmax, int satk, int sdef, int sstr, int sdex, int sintl, int slck, int n_item1, int n_item2, int n_spell)
        {
            //This function allows you to create a new player object, determining all stats,
            // worn equipment, two inventory items, and a single starting spell
            name = sname;
            sex = ssex;
            race = srace;
            build = sbuild;
            eyec = seyec;
            hairc = shairc;
            skinc = sskinc;
            tat = stat;
            clas = sclas;
            height = sheight;
            wt = swt;
            age = sage;
            hpmax = shpmax;
            mpmax = smpmax;
            atk = satk;
            def = sdef;
            str = sstr;
            dex = sdex;
            intl = sintl;
            lck = slck;

            status = "OK";
            lvl = 1;
            xp = 0;
            xpnxt = 10;
            hp = hpmax;
            mp = mpmax;
            hunger = 0;
            thirst = 0;

            gp = 0;

            for (int i = 0; i < 10; i++) { inv[i] = eq[0]; }

            inv[1] = eq[ n_item1 ];
            inv[2] = eq[ n_item2 ];
            splist[ n_spell ].unlock = true;
        }

    void set(string stat, int val, string text)
	{
	    if ( stat == "name" ) name = text;
	    else if ( stat == "hairc" ) hairc = text;
	    else if ( stat == "eyec" ) eyec = text;
	    else if ( stat == "skinc" ) skinc = text;
	    else if ( stat == "sex" ) sex = text;
	    else if ( stat == "race" ) race = text;
	    else if ( stat == "voice" ) voice = text;
	    else if ( stat == "att" ) att = text;
	    else if ( stat == "story" ) story = getInpLn();
	    else cout << "\nThat's not a value you can change!\n";
	}

} pc;

struct song
{
    string name;
    string score;
    string desc;
    int id;
    bool learned;
} songs[10];

int day, timen, year;

struct menu
{
    string intro, prompt;
    int options_limit;
    vector<string> options;
    int input;

    void display()
    {
        cout<<intro;
        cout<<prompt;
        for(int x=1; x<options_limit;x++){cout<<" ["<<x<<"] \t|\t"<<options[x]<<"\n";}
        cout<<" ["<<options_limit<<"] \t|\tBack\n";
    }
};

struct trophy
{
    string name, mat, desc;
    int id, pts;
    bool unlock;
} trophy_list[101];

/*Functions pertaining to classes*/

int getItemID(string mat, string name)
{
    int id;
	for(id=0;id<300;id++)
	{
		if(eq[id].mat==mat&&eq[id].name==name)
        break;
	}
	return id;
}

int getEnemID(string name)
{
	for(int id=0; id<40;id++)
		if(elist[id].name==name)
			return id;
}

#endif // TSF_CLASSES_H_INCLUDED
