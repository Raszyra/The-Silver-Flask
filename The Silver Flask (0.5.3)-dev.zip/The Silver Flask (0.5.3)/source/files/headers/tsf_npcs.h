#pragma once

#ifndef TSF_NPCS_H_INCLUDED
#define TSF_NPCS_H_INCLUDED

#include "tsf_quests.h"

using namespace std;

/*TSF NPC list*/

/*
<=====================>
|  IMPORTANT NOTE:   |
<=====================>

-----> The LAST STEP in each quest is the recursive one!!
-----> Subtract ONE because "info" starts at 0!!
-----> So for EXAMPLE:

        qlog[x]={"example quest", 0, 5, 10, 10, x}

        The LAST STEP in this example is nlist[x].info[4]

*/

void define_npcs()
//name, idle, app, greet, ql, qgp, qxp
{
	nlist[0].name="null";

	nlist[1]={
		"Arana",
		"sweeping her porch",
		"Once your erstwhile caretaker, the years have been\nkind to Arana; her pleasant face bears but few lines, and\nno grey can be seen in her dark hair. She wears\na simple blue cotton dress, and pauses to wave\nas she sees you.\n",
	"'Well, hello there!' she sets her broom aside and smiles.\n'What can I do for you?'\n",
	"'Oh, you're such a scamp! Be off with you!'\n",
	"'Well, it was lovely to see you again.\nGood luck in your adventures!'\n",
	"'Thanks so much for your help!'\n",
	1};
	nlist[1].q=qlog[0];
	nlist[1].dopt[0]="(1) I'm looking for a quest.\n(2) You look locely today.\n(3) leave\n";
	nlist[1].info[0]="She blushes and tries to scowl. 'Oh, you charmer!'\n";
	nlist[1].qline[1]="'Oh, a quest, hmm?' a smile plays at the corners\nof her mouth. 'Well, I could certainly use a brave, bold\nyoung adventurer to bring me some firewood, I suppose.'\n";
	nlist[1].dopt[1]="(1) Can do!\n(2) I don't feel like it.\n(3) leave\n";
	nlist[1].info[1]="'Then what are you bothering me for? Be off with you!'\n";
	nlist[1].qline[2]="'Well, what are you waiting for?\nGo get an axe and chop some wood in the forest.\nChop chop!'\n";
	nlist[1].dopt[2]="(1) Ok, I'm going!\n(2) I don't feel like it.\n(3) leave\n";
	nlist[1].info[2]="'Then what are you bothering me for? Be off with you!'\n";
	nlist[1].qline[3]="'Do you have any wood for me?'\n";
	nlist[1].dopt[3]="(1) Here's that firewood\n(2) I don't have the wood yet.\n(3) leave\n";
	nlist[1].info[3]="'Then you'll have to get some! Did you buy an axe yet?'\n";
	nlist[1].dopt[4]="(1) No problem!\n(2) I have more wood, if you have more coin...\n(3) leave\n";
	nlist[1].info[4]="She chuckles and shakes her head.\n'You're quite the merchant, aren't you?'\n";

	nlist[2]={
	"Farmer",
	"puffing on a corncob pipe",
	"The old man has surely seen better days, but for\nall his years his spirit hasn't dimmed a bit.\nFace weathered, clothes patchy, a notch in the brim\nof his hat, Ebert seems oblivious to both\nmisfortune and his many years, laughing heartily,\npuffing on his pipe, and hauling hay bales \nthat must weigh twice what he does.\n",
	"'Howdy, stranger! What's ya need?'\n",
	"'Gar, if'n I didn't know better, I'd say yer havin' a go at me...'\n",
	"'Well, stop on by anytime, stranger!\n'",
	"'Y'done me a great service, stranger! Yer welcome\nto all the crops and wool you can carry.\nCome back anytime, y'hear?'\n",
	2};
	nlist[2].q=qlog[1];
	nlist[2].dopt[0]="(1) I'm looking for a quest.\n(2) You look lovely today.\n(3) leave\n";
	nlist[2].qline[1]="'Oh, y'are, eh? Well, I always need help around\nthe farm here. Why don't you start by shearin'\nmy sheep, over in the north pasture?'\n";
	nlist[2].dopt[1]="(1) Can do!\n(2) I don't feel like it.\n(3) leave\n";
	nlist[2].qline[2]="'I'll just wait right 'ere til ye get\nback with that wool.'\n";
	nlist[2].dopt[2]="(1) I have some wool for you.\n(2) I don't feel like it.\n(3) leave\n";
	nlist[2].qline[3]="'Great Sam Hill! What'd ya do, shear\nthe whole flock?! Why, that's amazing!\nThanks a bundle!'\n";
	nlist[2].dopt[3]="(1) No problem. What's next?\n(2) I stole this wool, actually.\n(3) leave\n";
	nlist[2].qline[4]="'Awright, now, I been needin' to plant some\ncrops in the western field, but dern\nwolves out there make it impossible!\nGo'n kill me one, I'd be mighty grateful.'\n";
	nlist[2].dopt[4]="(1) Can do!\n(2) That sounds really scary actually...\n(3) leave\n";
	nlist[2].qline[5]="'Now the wolves've all runnoft scared senseless,\nit's plant'n time. Here's some seed,\ngo and sow it on that western plot.'\n";
	nlist[2].dopt[5]="(1) Ok, I'll do that.\n(2) Sow it yourself!\n(3) leave\n";
	nlist[2].qline[6]="'You sowed that field yet?'\n";
	nlist[2].dopt[6]="(1) Yep! All planted.\n(2) Sow it yourself!\n(3) leave\n";
	nlist[2].dopt[7]="(1) Been a pleasure, Farmer!\n(2) That was a lame quest.\n(3) leave\n";

	nlist[3]={
		"Sera",
		"tending to a patient",
		"The hermit healer Sera appears distressed. Dark circles\nunder her pale green eyes contrast sharply\nwith wan skin, premature worry lines creasing\nher brow as she leans over a comatose patient. Her\ncoppery hair is tied tightly back, loose strands\nplastered to her forehead by a sheen of sweat. She\ndoes not notice your approach, wholly consumed\nby the task at hand.\n",
	"She glances up with a harried look.\n'Yes, what is it?'\n",
	"She looks at you blankly for a moment, then\nreturns to her patient.\n",
	"She gives you a tired nod as you take your leave.\n",
	"'Gods bless you, stranger. Please visit me anytime\nyou need an antidote.'\n",
	3};
	nlist[3].q=qlog[2];
	nlist[3].dopt[0]="(1) Can I help at all?\n(2) What are you doing?\n(3) leave\n";
	nlist[3].info[0]="She indicates the man on the cot, his skin\ndeathly white, chest heaving.\n'He's been poisoned, bitten by a viper.'\n";
	nlist[3].qline[1]="'This man will die without a particular\nherb from the forest to the west. However,\nI am unable to leave his side...\nWill you find one and pick it for me?'\n";
	nlist[3].dopt[1]="(1) Can do!\n(2) I don't feel like it.\n(3) leave\n";
	nlist[3].info[1]="She scowls fiercely. 'Then leave me alone!\nI'm extremely busy!'\n";
	nlist[3].qline[2]="'Do you have the herb yet? Please hurry!'\n";
	nlist[3].dopt[2]="(1) Here it is!\n(2) How do I get the herb again?\n(3) leave\n";
	nlist[3].info[2]="'Just go west to the forest and 'forage' or\n'look around' until you find a medicinal herb, then\n'pick' it and bring it back here.'\n";
	nlist[3].dopt[3]="(1) Anytime, good luck!\n(2) How's the patient?\n(3) leave\n";
	nlist[3].info[3]="Sera smiles weakly. 'He'll be alright, thanks to you.'\n";

	nlist[4]={
		"Fortuno",
		"dancing a jig",
		"The tall, dark-haired Fortuno is adorned in\na garishly contrasting brightly colored jester's\noutfit. Bells atop his floppy pointed\nhat jangle merrily as he capers, dancing\na deceptively complicated jig with a look of serious concentration.\n",
	"Fortuno halts abruptly mid-caper, poised stiffly\non one foot. 'Greetings, fellow traveler! What can\nour humble troupe do for you?'\n",
	"Fortuno gives you a wink and twirls deftly.\n",
	"He tumbles forward, rolling to his feet an inch\nfrom you to shake your hand vigorously.\n'lovely to see you! Do come visit sometime!'\n",
	"'Many thanks! Many thanks! Don't be a stranger!'\n",
	4};
	nlist[4].q=qlog[3];
	nlist[4].dopt[0]="(1) Why are your troupers in their underwear?\n(2) Can you teach me to dance?\n(3) leave\n";
	nlist[4].info[0]="He leans in close with conspiratory wink.\n'Tell you what: you help us out, I'll\nshow you how to duck and weave like\na wild ferret!'\n";
	nlist[4].qline[1]="He closes his eyes and staggers back in\na dramatic, mournful gesture. 'Alas! Bandits\nhappened upon us, and stole the very\nclothes from our backs!'\n";
	nlist[4].dopt[1]="(1) That's awful!\n(2) I thought you were just exhibitionists.\n(3) leave\n";
	nlist[4].info[1]="Fortuno laughs uproariously.\n'Of a different sort, my friend!'\n";
	nlist[4].qline[2]="'Absolutely! But if someone could bring\nus three cloth tunics, that'd keep\nthe cold at bay until we can restock!'\n";
	nlist[4].dopt[2]="(1) Here's a tunic!\n(2) What am I supposed to do about that?\n(3) leave\n";
	nlist[4].info[2]="'Well, you could buy a Needle & Thread,\nfind some wool, and 'sew' a tunic. \nYup, you could do that. Up to you.'\n";
	nlist[4].qline[3]="Great, thank you!\n Two more to go.\n";
	nlist[4].dopt[3]="(1) Here's another tunic!\n(2) How do I make a tunic, again?\n(3) leave\n";
	nlist[4].info[3]=nlist[4].info[2];
	nlist[4].qline[4]="Great, thank you!\n One more to go.\n";
	nlist[4].dopt[4]="(1) Here's the last tunic!\n(2) How do I make a tunic, again?\n(3) leave\n";
	nlist[4].info[4]=nlist[4].info[2];
	nlist[4].dopt[5]="(1) Glad I could help!\n(2) How's the performance coming?\n(3) leave\n";
	nlist[4].info[5]="'Excellent, excellent! Only, ticket sales are down somewhat now that everyone is fully clothed...'\n";

	nlist[5]={
		"Aria",
		"singing sonorously",
		"The troupe's prized soloist, Aria stands alone at\nher campfire, gloved hands clasped before\nher, eyes closed, as she exercises her\nmelodious voice. She is wearing an elegant\nred silk dress. Elaborately curled golden\nhair frames her delicate face.\n",
	"Her song trails away and she opens her eyes.\n'Hello, stranger. What can I do for you?'\n",
	"She shakes her head, blonde curls bouncing\nas she looks at you quizzically.\n",
	"'Well, it was nice talking to you. Come back to see me sometime!'\n",
	"'Oh, you fixed my flute! Thank you so much!'\n",
	5};
	nlist[5].q=qlog[4];
	nlist[5].dopt[0]="(1) Do you need help with anything?\n(2) That was a lovely song.\n(3) leave\n";
	nlist[5].info[0]="She smiles prettily and bats long eyelashes at you.\n'Thank you, I'm glad you think so!\n";
	nlist[5].qline[1]="'Well, a gang of nasty bandits damaged\nmy precious flute in their attack...if you're\nany good at carving, could you repair it\nfor me? Pretty please?'\n";
	nlist[5].dopt[1]="(1) Sure, I'll take a look.\n(2) I'm no good at carving...\n(3) leave\n";
	nlist[5].info[1]="Aria pouts at you. 'Are you sure?\nAll you have to do is buy a chisel and\n'carve' some wood to practice!'\n";
	nlist[5].qline[2]="'My lovely flute! It's fixed! Oh, thank you!'\n";
	nlist[5].dopt[2]="(1) Happy to help!\n(2) Will you sing a song for me?\n(3) leave\n";
	nlist[5].info[2]="Aria nods and closes her eyes.\nShe is quiet a moment, then begins to sing in\na high, clear soprano, slowly pronouncing\neach word.\n\n'When dawn's light fades,\nWhen the sun, blood red,\nIs finished with his day,\nGood folk sound abed,\nWhen at last, ends the fray,\nAnd all your strength has fled,\nThink of me, smiling gay,\nAnd in loce rest your head.'\n\n";

	nlist[6]={
		"Ferryman",
		"working on his boat",
		"The aging ferryman, glancing up occasionally to peer at the sky, is busily patching holes,\nadjusting the tiller, and making sure the craft is ready for its next trip.\n",
		"The old man looks up at you, lifting the brim of his hat. 'G'day to ye, stranger.'\n",
		"He looks at you oddly. 'You're gonna have to run that past me again, stranger.'\n",
		"The ferryman nods, returning to his boat. 'Mmh.'\n",
		"'Thanks again for the bucket. Let me know if you ever need to cross the river.'\n",
		6};
    nlist[6].q=qlog[7];
    nlist[6].dopt[0]="(1) Can you take me across the river?\n(2) How's the water today?.\n(3) leave\n";
	nlist[6].info[0]="He frowns. 'It's a little high, stranger.'\n";
	nlist[6].qline[1]="'Well, I'd love to, but y'see,' he kicks the side of the boat,\n'she's really seen better days. Truth is, we won't make it across without my bailing bucket.\n";
	nlist[6].dopt[1]="(1) I have a bucket for you.\n(2) Where can I get a bucket?\n(3) leave\n";
	nlist[6].info[1]="He taps his chin, thinking. 'Well, those damned goblins took mine.\nYou could probably buy one somewhere, I suppose.'\n";
	nlist[6].qline[2]="'Well I'll be! Thanks a bundle, now we can get across just fine.'\n";
	nlist[6].dopt[2]="(1) Happy to help!\n(2) How's the river today?\n(3) leave\n";
	nlist[6].info[2]="The old ferryman grins. 'Swift and sure, stranger! Just the way it should be.'\n";

	nlist[7]={
		"D'tuum",
		"swinging his pick at a rock",
		"The brawny dwarf is busily hammering away at\na nearby ore vein, stopping every few\nminutes to mop his brow. He hasn't seemed\nto notice you. There is a large pile of\nstone blocks behind him.",
		"As he sees you approach, the Dwarven miner\nsets aside his pick and raises a hand. 'Ho there!\nWhat brings ye to the mines, friend?'\n",
		"The dwarf digs a pebble out of his ear with a thick finger. 'Eh?'\n",
		"'A'right, then. Be seeing you.'\n",
		"D'tuum claps you heavily on the shoulder.\n'Anybody c'n mine like that, is a true friend o' mine!' he says,\nguffawing heartily at his own joke.\n",
		7};
		nlist[7].q=qlog[6];//Yours, Mine, & Hours
		nlist[7].dopt[0]="(1) I'm looking for work, actually.\n(2) How's the mining business treating you?\n(3) Leave\n";
		nlist[7].info[0]="The burly dwarf shrugs, grinning wryly.\n'Ach, there's not much business to be had!\n...Otherways, not bad, friend, not bad.'\n";
		nlist[7].qline[1]="'Then today's a lucky day for us both!\n...Listen, I'm 's good a miner as the next Dwarf.\nOn me family's pick and spade, I am. But two\nbodies're better where one's not enough, as they say.\nDo ye follow me, friend?'\n";
		nlist[7].dopt[1]="(1) I think so...\n(2) You need me to hide a body?\n(3) Leave\n";
		nlist[7].info[1]="D'Tuum roars with laughter, his heavy frame shaking.\n'A sense of humor, too! I think\nwe're gonna get along jes' fine.'\n";
		nlist[7].qline[2]="'Aye, me haul is not quite the trove me\nforeman was expecting.'\nHe indicates the pile of grey stones behind him.\n'But if I happen, by a wee bit of luck, to find\nall the stones I'm seekin', well, you'll find\nsome coin, I'll find some favor, everybody\nwalks away 'appy, ye ken?'\n";
		nlist[7].dopt[2]="(1) Sounds like a plan. What's first?\n(2) Help you cheat? I don't think so. Do your own job.'\n(3) Leave\n";
		nlist[7].info[2]="He shrugs, picking up his tools.\n'That's fair, friend, that's fair. Stop on by if\ny' change yer mind.'\n";
		nlist[7].qline[3]="'First, I'll need a lump of basic iron.\nJust come talk to me when you've got it, got it?'\n";
		nlist[7].dopt[3]="(1) Here's some iron. What's next?\n(2) How do I get a lump of iron?\n(3) Leave\n";
		nlist[7].info[3]="'S'easy. Go buy yerself a pickaxe, come\nback 'ere, and 'mine' until you get it.'\n";
		nlist[7].qline[4]="'Great! Now I'll need some coal.'\n";
		nlist[7].dopt[4]="(1) Here's some coal. What's next?\n(2) How many more do you need?\n(3) Leave\n";
		nlist[7].info[4]="'With the iron out of the way, we'll need 5 more ores.'\n";
		nlist[7].qline[5]="'Great! Now I'll need some silver.'\n";
		nlist[7].dopt[5]="(1) Here's some silver. What's next?\n(2) How many more do you need?\n(3) Leave\n";
		nlist[7].info[5]="'With the coal out of the way, we'll need 4 more ores.'\n";
		nlist[7].qline[6]="'Great! Now I'll need some gold.'\n";
		nlist[7].dopt[6]="(1) Here's some gold. What's next?\n(2) How many more do you need?\n(3) Leave\n";
		nlist[7].info[6]="'With the silver out of the way, we'll need 3 more ores.'\n";
		nlist[7].qline[7]="'Good work! Next I'll need some crystal.'\n";
		nlist[7].dopt[7]="(1) Here's some crystal. What's next?\n(2) How many more do you need?\n(3) Leave\n";
		nlist[7].info[7]="'With the gold out of the way, we'll need 2 more ores.'\n";
		nlist[7].qline[8]="'Almost done! Last I'll need is a rough diamond.'\n";
		nlist[7].dopt[8]="(1) Here's some diamond.\n(2) How many more do you need?\n(3) Leave\n";
		nlist[7].info[8]="'We've got everything but diamond.\nIf I'm bein' truthful, only master miners can\nget that. But between the two of us,\nI'm sure we can find some.\n";
		nlist[7].dopt[9]="(1) Glad I could help, friend! Good luck to you.\n(2) How's the mining business treating you?\n(3) Leave\n";
		nlist[7].info[9]="The dwarf grins hugely. 'Never better, friend!\nGot me a nice promotion, the ores are flowing,\nand it's all thanks to you!'\n";

		nlist[8]={
			"Mason",
			"leaning on his hammer",
			"The burly dwarven builder is sat dejectedly on a boulder,\nlooking northward with a nonplussed expression.\n",
			"Mason greets you with a wry grin, wiping sweat from his forehead.\n",
			"The dwarf cocks an ear. 'Eh?'",
			"The stonemason nods affably and returns to leaning on his hammer.\n",
			"The mason grins, nodding toward the finished bridge. 'Sturdy as a dream! All thanks to yeh.'\n",
            8};
		nlist[8].q=qlog[5];
		nlist[8].dopt[0]="(1) Why are you standing out here?\n(2) What's across the river?\n(3) Leave\n";
		nlist[8].info[0]="'Sure, and there's a big old city there, thus the need for a bridge here.'\n";
		nlist[8].qline[1]="The old dwarf sighs. 'Well, if ye must know,' he says, gripping his hammer,\n'we were building this bridge, my crew and I;\nWe'd just gotten started when bandits attacked. We fought them off, we did,\nbut the boys'd had enough. Said no amount would be enough to risk it, and ran off, tails 'atween legs.'\n";
		nlist[8].dopt[1]="(1) Do you need help finishing the bridge?\n(2) Tell me more about the city.\n(3) Leave\n";
		nlist[8].info[1]="'Well, it's a big place. You got your four main districts, one at each gate;\n Then there's the mages' Arcanum, and the Temple of Light, and the Paladins' Grand Hall.\nLots of shops, and of course the library. Just steer clear of the back alleys and you'll be fine.'\n";
        nlist[8].qline[2]="'I can't get materials and build at the same time;\nif you bring me 5 stone blocks, I should be able to finish up.'\n";
        nlist[8].dopt[2]="(1) I can get you the stone.\n(2) Can you tell me about the city districts?\n(3) Leave\n";
		nlist[8].info[2]="'Hmm. The northern gate is the Craftsmen's district, where you can buy or craft equipment;\nthe west gate is right up against the river, so there's the docks.\nThe south gate, just across the bridge, is the market district.\nAnd lastly, the east, that's mostly houses. A few shady shops. Place gives me the creeps.'\n";
		string mason_qline;
		int blocks_needed;
		for(int x=3;x<8;x++)
		{
		    blocks_needed=8-x;
		    mason_qline="'Thank ye kindly! Now we need "+to_string(blocks_needed)+" more stone blocks.'\n";
		    nlist[8].qline[x]=mason_qline;
		    nlist[8].dopt[x]="(1) Here's another stone block.\n(2) Can you tell me more about the City?\n(3) Leave\n";
		};
		nlist[8].info[3]="'The Grand Hall is west of the North Gate. Huge old building, all draped in red and white.\nThe Paladins make their home there, living, eating, sleeping and training together.\nDamned decent types, really. Pretty welcoming to visitors. Knights and swordsmen come from all around to join,\nseeking a righteous path, or glory, or gold, or gear.' The dwarf chuckles.\n";
        nlist[8].info[4]="'If you go south from the main square, you'll find yourself between two of the most important places in the city:\nto the east, the Temple of Light, where one may find spiritual consult, and in the west, the looming Arcanum;\nthe mages don't mind if you visit, but they're not exactly welcoming.\n";
		nlist[8].info[5]="'Somewhere in the city, there's a gang of thugs calling themselves the 'Assassin's Guild'.\n";
		nlist[8].info[6]="'The city doesn't actually have a name, did ye know? It's officially just\n'The City.' That's how it started, I guess, and that's how it stayed.'\n";
		nlist[8].info[7]="'Well, what's to tell?' He scratches his beard. 'The blacksmith, in the northern district,\nis said to be the best around. A good personal friend. He's been sick lately, though.'\n";
		nlist[8].info[8]="'Well, what's to tell?' He scratches his beard.\n'There's an old witch lives near the east gate. Sells potions. She seems rude, but she's a decent sort.'\n";
		nlist[8].qline[8]="'There, the bridge is finished!' Mason gestures proudly to the broad, sturdy stone bridge.\n'Now folks from the Village can get across easily, and back again.'\n";
		nlist[8].dopt[8]="(1) So the bridge is safe to use now?\n(2) Can you tell me more about the City?\n(3) Leave\n";
		nlist[8].info[8]="'Well, what's to tell?' He scratches his beard.\n'There's a bakery in the market district, makes the best pies.'\n";

        nlist[9]={
		"Shaman",
		"muttering and dancing ",
		"Clad in a robe hewn of old sailcloth, festooned with feathers, charms, and skulls,\nthe goblin Shaman is an imposing figure for one so small.\nHe glances at you sideways, tossing a handful of powder into the flames;\nthe gathered goblins look on with wonder as a burst of crimson flame shoots out of the firepit.\nWhether all his methods are such trickery or not, he commands total respect,\neven fear, among the goblin tribes.\n",
		"As you begin to speak, the Shaman grabs the hem of your shirt.\n'Not here!' he hisses, tugging you behind a nearby hut.\n",
		"A puzzled expression crosses his face, then he shakes his head.\n'We don't have time for this!'\n",
		"The frazzled goblin has already returned to his post before the fire.\n",
		"The Shaman waves at you dismissively. 'Yeah, yeah, good job. What do you want, a trophy?'\n",
		9};
		nlist[9].q=qlog[8];
		nlist[9].dopt[0]="(1) What...\n(2) Who are you?\n(3) Leave\n";
		nlist[9].info[0]="'Look, that doesn't matter. I'm in real trouble here.'\n";
		nlist[9].qline[1]="'Keep your voice down!' He looks around frantically.\n'Listen, I got a real problem on my hands. And I think you're the only one who can help me now.\n";
		nlist[9].dopt[1]="(1) Okay, keep talking...\n(2) Why me?\n(3) Leave\n";
		nlist[9].info[1]="'Because nobody else can know, okay?' He looks around again.\n";
		nlist[9].qline[2]="The Shaman hangs his ugly head. 'I'm in too deep...it started easily enough,\nyou know, a trick here and there...before you know it, the whole clan is eating\nout of the palm of my hand. It's the life. All the food and loot I could want.\nBut now there's a real problem. And if I can't do something soon, there'll be blood to pay!\nMy blood!' He gulps nervously at the thought.\n";
		nlist[9].dopt[2]="(1) So what's the problem?\n(2) Why not just come clean now, and tackle it together?\n(3) Leave\n";
		nlist[9].info[2]="His eyes go wide. 'Are you nuts?! That's a pack of goblins! You know what they're like. If they don't literally tear me apart, the Chief would eat me. One bite. Gone.'\n";
		nlist[9].qline[3]="'It's the vampsects.' Catching your confusion, he explains. 'Giant insects. Bloodsuckers. Vampsects.\nAnyway, a vampsect broodmother set up a nest northwest of here.\nThe swarm grew, and then goblins started to go missing in the night.\nAnd of course, let's all turn to the great and powerful shaman to take care of it!\nOh, gods...'\n";
		nlist[9].dopt[3]="(1) I took care of the lair.\n(2) Any tips on handling vampsects?\n(3) Leave\n";
		nlist[9].info[3]="'Yeah. They don't like fire. They really don't like fire.'\n";
		nlist[9].dopt[4]="(1) Right.\n(2) So how's the charade going?\n(3) Leave\n";
		nlist[9].info[4]="He gives you a snaggle-toothed grin.\n'Amazing. Perfect. I told 'em I called down a lightning bolt and cleared out the whole nest.\nThey bought it. I'm back on top, baby!' He does a little jig.\n";

		nlist[10]={
			"Gareth",
			"poring over charts at a table",
			"The Knight Commander stands a few inches taller than\nthe paladins gathered around him, though his most\nvital years are well behind him. His weathered face\nis pinched in concentration as he surveys the order's movements.\n",
			"Gareth breaks off his scrutiny of the map to look at you intently. 'Yes?'\n",
			"The weathered commander shakes his head. 'I speak not that tongue, traveler.'\n",
			"The Commander gives you a half-salute and turns back to his council.\n",
			"Gareth clasps a mailed fist against his breastplate, nodding in salute.\n",
            10};
		nlist[10].q=qlog[10];
		nlist[10].dopt[0]="(1) Can I become a Paladin?\n(2) What is it that you do here?\n(3) Leave\n";
		nlist[10].info[0]="The veteran Commander smiles, not unkindly.\n'Where once I took the field, my high-blooded years are far behind me now;\nmy role now is to guide, and advise, the younger and stronger knights.'\n";
		nlist[10].qline[1]="The grizzled knight considers for a moment.\n'Prove your mettle, and your ambition; slay ten of our enemies, the Dark Knights, and return to me.'\n";
		nlist[10].dopt[1]="(1) It's done.\n(2) Where should I find these Dark Knights?\n(3) Leave\n";
		nlist[10].info[1]="'The Dark Order occupies the castle to the northeast.'\n";
		nlist[10].qline[2]="The greying general clasps your hand warmly. 'Excellent. Please, follow me.'\nHe leads you to a plinth at the front of the Grand Hall,\nand after a few minutes the Guild is assembled before you, waiting in silence.\n\n'Squire, you have defended and upheld this order,\nand we who go before you have decided to invite you into our ranks.'\nGareth pauses for a grave moment.\n'Now, repeat these words, our litany:'\n\n'So shall I be,'\n";
		nlist[10].dopt[2]="(1) So shall I be...\n(2) ...\n(3) Leave\n";
		nlist[10].info[2]="'The guild awaits you, Squire.'\n";
		nlist[10].qline[3]="\n'A light in the darkness,'\n";
		nlist[10].dopt[3]="(1) A light in the darkness...\n(2) ...\n(3) Leave\n";
		nlist[10].info[3]="'The guild awaits you, Squire.'\n";
		nlist[10].qline[4]="\n'A shield against tyranny,'\n";
		nlist[10].dopt[4]="(1) A shield against tyranny...\n(2) ...\n(3) Leave\n";
		nlist[10].info[4]="'The guild awaits you, Squire.'\n";
		nlist[10].qline[5]="\n'Protector of the weak,'\n";
		nlist[10].dopt[5]="(1) Protector of the weak...\n(2) ...\n(3) Leave\n";
		nlist[10].info[5]="'The guild awaits you, Squire.'\n";
		nlist[10].qline[6]="\n'for I am proof, and pride,\nof evil's flight before the rising sun'\n";
		nlist[10].dopt[6]="(1) For I am proof, and pride, of evil's flight before the rising sun.\n(2) ...\n(3) Leave\n";
		nlist[10].info[6]="'The guild awaits you, Squire.'\n";
		nlist[10].qline[7]="The rest of the guild erupts with applause, and Gareth grips your forearm.\n'Welcome to the Guild, Paladin. We are proud to have you.\nHere, with this crest, you may now purchase equipment from Emiria's stock. Now go and do us proud!'\n";
		nlist[10].dopt[7]="(1) I'm glad to be here, Commander.\n(2) What can you tell me about the Guild?\n(3) Leave\n";
		nlist[10].info[7]="'..'\n";

		nlist[11]={
			"Emiria",
			"standing beside several equipment racks",
			"Emiria, Paladin Armskeeper, cuts an immaculate figure,\nprimly marking sales in a leatherbound ledger.\nHer back is straight, her crimson hair perfectly smooth\nand tightly bound, her heavy Paladin\narmor so highly polished that its gold trim\nis blinding even in torchlight. Her dark\neyes are serious and piercing, making you\nfeel disheveled and uncomfortable.\n",
			"She looks up from her books, regarding you curiously.\n",
			"Emiria stares at you, uncomprehending.\n",
			"She nods stiffly and returns to her bookkeeping.\n",
			"Emiria regards you with a rare smile. 'The guild is truly in your debt, Paladin.'\n",
		11};
		nlist[11].q=qlog[11];
		nlist[11].dopt[0]="(1) Er, hello...I'm looking for a quest.\n(2) Can I buy some Paladin gear?\n(3) Leave\n";
		nlist[11].info[0]="The austere Paladin points an armored finger at a sign on her desk.\nThe sign reads, 'Equipment sales to guild members only!'\n";
		nlist[11].qline[1]="Emiria shakes her head. 'Quests are only performed by ranking guild members. Are you a Paladin?'\n";
		nlist[11].dopt[1]="(1) I'm a Paladin.\n(2) Okay, how do I join?\n(3) Leave\n";
		nlist[11].info[1]="'Talk to our Knight Commander, Gareth. He should\nbe in the hall somewhere.'\n";
		nlist[11].qline[2]="She inspects the proffered crest. 'Very well.'\n\nEmiria shuffles through a few pages before selecting one and handing it to you.\n'You're well familiar with the threat of the dark knights' enclave.\nWe believe this,' she taps the page, 'to be the source of their power.'\n\n(The page in question depicts an ebony goblet covered in arcane designs.)\n";
		nlist[11].dopt[2]="(1) Where is this chalice, then?\n(2) What is it, exactly?\n(3) Leave\n";
		nlist[11].info[2]="'They call it 'the Cursed Chalice'...legend has it,\ntheir Dark General shared a drink of sacrificial blood\nwith some demonic power, granting his legions their strength.\n";
		nlist[11].qline[3]="Emiria fishes out another page, a detailed drawing of the castle interior.\n'You'll find it in the castle treasury. That's the easy part.'\n";
		nlist[11].dopt[3]="(1) And the hard part...?\n(2) It's never that simple, is it?\n(3) Leave\n";
		nlist[11].info[3]="She quirks an eyebrow.\n";
		nlist[11].qline[4]="'You'll have to kill the Dark General to get into the treasury.\nReturn here with the Chalice when you're done.\n";
		nlist[11].dopt[4]="(1) I have the Chalice. \n(2) What can you tell me about this Dark General?\n(3) Leave\n";
		nlist[11].info[4]="'Not much is known of his origin, but the nature\nof his power should make him weak to holy magic.\nOtherwise, any method of armor piercing should help.\n";
		nlist[11].qline[5]="Emiria nods. 'Well done. That was a worthy foe...Gareth instructed me that, should you return alive, this was to be yours.'\n\nSo saying, the Paladin armskeeper retrieves cloth bundle from the chest behind her.\nYou catch your breath in awe as she unwraps the most beautiful sword you've ever seen.\n\n'This,' she says, flourishing the blade, 'is the Sword of Angel's Mercy.\nWe Paladins have guarded this blade for centuries, waiting for a worthy wielder.'\nShe hands you the sword.\n";
		nlist[11].dopt[5]="(1) Anything else I can do for the Guild?\n(2)How are you, Emiria?\n(3) Leave\n";
		nlist[11].info[5]="'Fine, thanks,' she says flatly.\n";

	nlist[12]={
		"Valencia",
		"leaning moodily against a wall",
		"Valencia's reputation precedes her. Her name has become legend among thieves and murderers,\ninspiring fear throughout the underworld. She's just leaning against a wall, but you get the feeling that\nunder her bored demeanor she's watching keenly, ready for anything.\n",
		"She looks up as you approach, fixing you with a flinty stare.\n",
		"Valencia quirks an eyebrow. 'What was that?'\n",
		"Her gaze drifts to somewhere over your shoulder. You decide it's time to go.\n",
		"Valencia grins humorlessly. 'Business is better than ever,\nnow that the Paladins have got the message and backed off.'\n",
		12};
		nlist[12].q=qlog[12];
		nlist[12].dopt[0]="(1) How do I become an Assassin?\n(2) Who are you?\n(3) Leave\n";
		nlist[12].info[0]="She throws her head back and laughs suddenly, startling you. 'Who am I?' she scoffs. 'Who am I?' She draws a long knife with a flourish, weaving a deadly pattern in the air. Before you can blink the knife point is at your throat. 'I'm your worst nightmare. I'm a shadow on the wall. I own the Assassins' Guild. I own this town.'\n";
		//Valencia gives the player a vial of poison, eq[288]
		nlist[12].qline[1]= "Valencia gives you a second look, appraising you shrewdly.\n'Okay, stranger. I'll give you a chance.' She holds out a hand and Hakon tosses her a vial of liquid.\n'The Paladins have been making things hard on us lately. It's time to show them what we're made of.\nTake out their Knight Commander, Gareth; I don't care how you do it, but this poison is probably your best bet.\nDo that, and then we'll talk.'\n";
		nlist[12].dopt[1]="(1) It's done. Gareth is dead.\n(2) How should I do it?\n(3) Leave\n";
		nlist[12].info[1]="'Just slip into the Grand Hall and 'poison' Gareth. That should do the trick.'\n";
		//Valencia gives the player a slayer coin to hand off to Hakon
		nlist[12].qline[2]= "Valencia nods. 'Good. Here's your payment...and as promised,\nyou can count yourself a member. If you need any gear, talk to Hakon.'\n";
		nlist[12].dopt[2]="(1) Glad to be of service.\n(2) What's next?\n(3) Leave\n";
		nlist[12].info[2]="If you're looking for more work, talk to Hakon. He handles our day to day.\n";

		nlist[13]={
		"Hakon",
		"drinking at the makeshift bar",
		"The mercenary-turned-assassin is a bit of an enigma, even to his confederates.\nHe's known for his connections, but rarely speaks, conducting business with cold precision.\nAll anyone really knows is Hakon's fierce loyalty to Valencia, and therefore the Guild.\n",
		"Hakon grunts non-committaly as you set at the bar beside him.\n",
		"He ignores you, taking a shot of liquor.\n",
		"The grizzled veteran nods to you as you take your leave.\n",
		"'...'\n",
		13};
		nlist[13].q=qlog[13];
		nlist[13].dopt[0]="(1) Do you have any work for me?\n(2) Who are you?\n(3) Leave\n";
		nlist[13].info[0]="He grunts. 'Doesn't matter.'\n";
		nlist[13].qline[1]="He shakes his head. 'Talk to the boss. Jobs're only for ranking members.'\n";
		nlist[13].dopt[1]="(1) I joined the Guild. (Give Hakon the slayer coin)\n(2) How exactly would I join?\n(3) Leave\n";
        nlist[13].info[1]="'That's for Valencia to decide. Do whatever she tells you.\n";
        nlist[13].qline[2]="'I heard.' He reaches down and pulls out a sheaf of papers.\n'There are a few bandits who think they can operate in the city without the Assassin's Guild.\nHere are their descriptions. Make sure they don't bother us again.'\n";
		nlist[13].dopt[2]="(1) Those bandits won't be a problem anymore.\n(2) Where can I find these men?\n(3) Leave\n";
		nlist[13].info[2]="He thinks a moment. 'They usually wait for unarmed merchants on the bridge to the south.\nOtherwise you can find them roaming the streets around here.'\n";
		nlist[13].dopt[3]="(1) '...'\n(2) Now will you tell me about yourself?\n(3) Leave\n";
        nlist[13].info[3]="Hakon downs a shot and stares at the wall for a moment.\nHe sighs. 'What's to tell? I grew up here. Joined the guard. Got kicked out. Started taking odd jobs to survive.\nThen Valencia found me. We formed the Guild, and the rest is history.' He refills the glass.\n";

		nlist[14]={
		"Archmage",
		"poring over an arcane tome by candlelight",
		"Archmage Anias Kosseda is difficult to look at. Besides being presumably over a hundred,\nhe has an intense, almost feverish stare. He traces the lines in his book with a bony,\nstick-thin finger, muttering the words into his beard.\n",
		"The Archmage glares at you icily. 'Yes? What is it?'.\n",
		"He looks away, as though considering the phrase, then shakes his head.\n",
		"He waves you away imperiously, returning to his studies.\n",
		"The Archmage looks at you with something resembling respect. 'Slaying that demon was an impressive feat;\nyou're welcome in the Arcanum anytime. Just don't go trying to explore the catacombs, ha ha.'\n",
		14};
		nlist[14].q=qlog[14];
		nlist[14].dopt[0]="(1) Can I use the facilities here?\n(2) What is this place?\n(3) Leave\n";
		nlist[14].info[0]="He huffs with annoyance. 'This is the Arcanum, a place of study and practice for mages of all kinds.'\n";
		nlist[14].qline[1]="'Absolutely not! The very nerve...Although, I suppose I could let you\nread a book or two if you find some ingredients for me.\n";
		nlist[14].dopt[1]="(1) What do you need?\n(2) What are the ingredients for?\n(3) Leave\n";
		nlist[14].info[1]="The Archmage looks at you intently for a moment. 'The plan is to summon a golem, or rather, create one.\nThus far, how nature forms a golem is beyond us; but I believe we've finally got it.'\n";
		nlist[14].qline[2]="'Well, for a summoning like this we'll need to start with...' He flips through the book.\n'A feather, an iron dagger, a ruby, and the heart of a Lava Golem.\n";
		for (int x=3;x<=5;x++) nlist[14].qline[x]="'Excellent. On to the next item, now.'\n";

		nlist[14].qline[6]="The Archmage places the items into the summoning circle and steps back to\njoin the ranks of the gathered magi. The candles around the edge of the circle sputter and flare,\na sheet of flame surrounding the circle. Terrified cries fill the air as the flame\nsuddenly explodes outward, followed by a monstrous, horned head and a massive clawed hand.\nSoon pandemonium reigns, horrified mages flying through the air as the demon rampages.\nFinally, it comes to a heaving halt in front of you, staring down at you with hate-filled eyes...\n";
		nlist[14].qline[7]="The surviving Arcanum mages stagger to their feet, groaning, as the demon topples backward,\nyour weapon lodged between its horns. The Archmage emerges from behind a desk,\nshaking, looking at you with wonder. 'How...even the Adepti couldn't...' He regains his composure, drawing\nhimself to his full height. 'Well. Seems you may have a place here after all.\nConsider yourself an Arcanum Adept from here on; we owe you our lives.\n";
		nlist[14].dopt[7]="(1) I'm glad that's over.\n(2) Is everyone alright?\n(3) Leave\n";
		nlist[14].info[7]="The Archmage shrugs. 'No, but this is a dangerous profession. We all know the risks.'\n";
		nlist[14].dopt[8]="(1) So, can I use the facilities?\n(2) What can I do at the Arcanum?\n(3) Leave\n";
		nlist[14].info[8]="'Well, you can use the summoning circle here to conjure all manner of beasts.\nThere's an enchanting obelisk that will strengthen your enchantments.\nAnd, of course, you can buy Arcanum vestments and weapons from Azelfoff, there.' He indicates the blue-robed wizard ambling about the open floor.\n";

		nlist[14].dopt[2]="(1) Here's the feather.\n(2) What all did you need again?\n(3) Leave\n";
		nlist[14].dopt[3]="(1) Here's the dagger.\n(2) What all did you need again?\n(3) Leave\n";
		nlist[14].dopt[4]="(1) Here's the ruby.\n(2) What all did you need again?\n(3) Leave\n";
		nlist[14].dopt[5]="(1) Here's the molten core.\n(2) What all did you need again?\n(3) Leave\n";
		for(int x=2; x<=5; x++) {nlist[14].info[x]="'A feather, an iron dagger, a ruby, and a Molten Core.'\n";}

		nlist[15]={
		"Azelfoff",
		"sweeping about on the summoning circle as though in a gothic ballroom",
		"The ancient wizard wears a perpetual placid smile beneath his voluminous beard.\nEven after speaking to him it's unclear if his expression is the result of an easygoing attitude or total detachment;\neither way he's still a Grand Archon, and the Arcanum's only armskeeper.\n",
		"Azelfoff grins unguardedly, sweeping closer and pulling you into his imagined dance.\n'What can I do for you, young'n?' he asks, leading you in a complicated waltz.\n",
		"The old man cocks an ear. 'Eh? I don't think I've learned that language yet.'\n",
		"Azelfoff dances you to the edge of the circle, then gracefully slips away.\n",
		"The old wizard claps you heartily on the back. 'Excellent work you've done here, young'n.\nBet that fellow will think twice before betraying the Arcanum!\nWell, in his next life, anyway.'\n",
		15};
		nlist[15].q=qlog[15];
		nlist[15].dopt[0]="(1) Can I buy some Arcanum gear?\n(2) Who are you?\n(3) Leave\n";
		nlist[15].info[0]="With a twinkle in his eye, the old man chuckles, coughing up a live butterfly.\nIt doesn't appear that Azelfoff expected this.\nHe looks back at you. 'No one, really. At least, I think so.'\n";
		nlist[15].qline[1]="'I think you should offer your services before asking for mine, no?'\n";
		nlist[15].dopt[1]="(1) I joined the Guild.\n(2) How do I buy some sweet wizard drip?\n(3) Leave\n";
		nlist[15].info[1]="'Well, as long as I'm here, you can just walk in and say 'guildshop'!\n";
		nlist[15].qline[2]="'Oh, good! We have a problem I'm going to need you to...take care of.'\n";
		nlist[15].dopt[2]="(1) I expected no less. What's the job?\n(2) Can you tell me about enchanting?\n(3) Leave\n";
		nlist[15].info[2]="'Certainly! Well, the first thing you'll need is a gemstone. It's important to remember the different kinds:\nRubies are for fire and strength enchantments,\nEmeralds for earth and defense,\nSapphire for water and intellect,\nCrystal for wind and dexterity,\nAmethyst for lightning and luck,\nand Diamond for ice and attack enchantments.'\n";
		nlist[15].qline[3]="Azelfoff smiles dreamily, gazing at the rafters.\n'Well, one of our order left here like a thief in the night, the scoundrel;\nwhat's worse, he plans to sell Arcanum knowledge to unincorporated magi!\n...I need you to break his legs.'\n";
		nlist[15].dopt[3]="(1) Your rogue mage won't be spilling any secrets.\n(2) Can you tell me more about enchanting?\n(3) Leave\n";
		nlist[15].info[3]="'Well, there's an old elf working in the Elven Workshop, far to the southeast,\nwith a penchant for gemstones. He always has more than he needs, so he sells the surplus.\nNot cheap, though. Old tightwad won't even lower his rates for me, a Grand Archon.\nRidiculous.'\n";
		nlist[15].dopt[4]="(1) My pleasure.\n(2) Is there anything else I need to know about enchanting?\n(3) Leave\n";
		nlist[15].info[4]="He thinks about it. 'Sure, here's a few tips:\n-Enchanting at the Arcanum always yields a stronger enchantment\n-An enchanted item cannot be enchanted again\n-The strength of an enchantment is based on intellect as well as skill'\n";

nlist[16]={
		"Viri",
		"contemplating the fountain",
		"Brother Viri is a placid, unassuming presence.\nYou hardly notice him standing before the fountain.\nHe turns to look at you, as if sensing your scrutiny.\nThe Avatar's eyes are completely white, absent of pupil or iris,\nand seem to peer into some deeply sensitive, hidden part of you.\n",
		"Viri inclines his head slightly, smiling gently.\n",
		"The venerated Brother merely looks at you, empty eyes sensing your intention.\n",
		"Viri places his hands together and nods to you.\n",
		"The inscrutable Avatar smiles.\n'Word has reached me of your good deeds. The land rejoices, and you are welcomed among us.'\n",
		16};
		nlist[16].q=qlog[16];
		nlist[16].dopt[0]="(1) Does the Temple have any need?\n(2) What is this place?\n(3) Leave\n";
		nlist[16].info[0]="Viri looks upward into the skylight. 'This temple is home to Light, and many more besides. If you feel your heart begin to stray, you may always come here to pray.\n";
		nlist[16].qline[1]="He clasps his hands together. 'Our need here is no different from that of the world around us.\nGo forth and seek the needs of the people, and you will find what you seek.\n";
		nlist[16].dopt[1]="(1) I have found what I seek.\n(2) Who are you?\n(3) Leave\n";
		nlist[16].info[1]="'I am a vessel of Light, nothing more, nothing less.'\n";
		//This step gives the player "smooth stone" and changes class to "Avatar"
		//The stone can be traded to Suni to take on her quest
		nlist[16].qline[2]="Brother Viri turns his head slightly.\n'Say rather, that which you did not know you sought, has found you.'\n\nBrother Viri hands you a simple, smooth stone.\nAs you take it, suddenly you feel the stone's connection to the world around it, and your own;\nthe Light of understanding fills your body, spilling from you in golden waves.\n\nHe smiles. 'You have made the world a better one, for all of us. You are welcome now to\nall the temple may offer you. Speak with Sister Suni if you have need of equipment\nor if you desire to assist the Temple further.'\n\n";
		nlist[16].dopt[2]="(1) (Nod.)\n(2) What can I do here?\n(3) Leave\n";
		nlist[16].info[2]="He gestures as he speaks. 'Many find clarity by praying before the fountain.\nSister Suni is also always happy to converse, or of course supply our\nraiments, tokens, and litany.'\n";
		nlist[16].dopt[3]="(1) (Nod.)\n(2) What can I do here?\n(3) Leave\n";
		nlist[16].info[3]=nlist[16].info[2];

nlist[17]={
		"Suni",
		"watering the flowers in an alcove",
		"This gentle soul wears a perpetual beatific smile,\nbeaming at each visitor to the Temple. It seems apparent that she's spent most of her life here, and it's\nhard to imagine her anywhere else. Suni is almost a literal ray of sunshine, always busy,\nhumming cheerily to herself as she drifts between flowerboxes and visitors.\n",
		"The priestess gives you a radiant smile.\n'What can I help you with today?'\n",
		"Suni tilts her head slightly, still beaming.\n",
		"She flutters a hand at you as you take your leave.\n'Come back anytime you need peace and guidance.'\n",
		"Suni's radiant expression gets even brighter. 'The Temple has been so lively of late,\nwith all these pilgrims from lands beyond! Thank you, stranger.'\n",
		17};
		nlist[17].q=qlog[17];
		nlist[17].dopt[0]="(1) Does the Temple have any need?\n(2) Who are you?\n(3) Leave\n";
		nlist[17].info[0]="She grasps your hand emphatically, looking sincerely into your eyes as she\ngives it a vigorous shaking. 'Well met, stranger! I am Suni, a priestess here at the Temple.\nI water the plants, and make sure everything stays clean, and everyone stays happy!'\n";
		nlist[17].qline[1]="Suni deliberates a moment. 'Normally, only priests and priestesses\nare allowed to handle Temple business...talk to our Avatar, Brother Viri.'\n";
		nlist[17].dopt[1]="(1) I've done as Brother Viri asked, and helped the people.\n(2) What can you tell me about the temple, and the Light?\n(3) Leave\n";
		nlist[17].info[1]="Suni smiles broadly.\n\n'The Light is all around us, in every good deed\nand every pure, kind thought.\n\nThe Temple represents an asylum,\na sacred space to commune with the Light and meditate on peace.'\n";
		//step 3 gives player the Sacred Torch item
		nlist[17].qline[2]= "The first tinge of anything but boundless positivity creeps into Suni's countenance.\n'Well, stranger, there is one thing...' She moves to one of the window ledges and\nlooks out, a frail air of melancholy settling over her shoulders.\n'This temple used to see so many travelers. It was wonderful. But then, the great Beacon\nilluminating the path through the northern caves went dark. People got lost, and the cave beasts got bolder...\n...I feel bad, asking this of you, as the way can be dangerous...'\n\n(Suni hands you a Sacred Torch)\n\n";
		nlist[17].dopt[2]="(1) I've lit the beacon; the way is safe once more.\n(2) Is there anything I should know about the caves?\n(3) Leave\n";
		nlist[17].info[2]="'Just be careful. There are some dangerous creatures there.' She thinks for a moment.\n'Well, Brother Viri once told me of a lost Elven tribe that lives somewhere in the caves.'\n";
		//step 4 gives player the mace of blessed bashing
		nlist[17].qline[3]= "She claps her hands. 'Wonderful! Now visitors from afar can come to pray in peace once more.'\n'Now, how can I repay you?'\nShe muses for a moment before smacking her fist into her palm. 'Got it! Come with me.'\n\nSuni leads you deeper into the temple, through marble corridors and past sparkling\nfountains and sunbathed atriums until you arrive at a simple wooden door.\n\nSuni produces a key from her habit and opens the door, revealing a sparse but tasteful bedroom.\nYou peer in as she opens an ironbound chest.\nSuni turns back to you with an ancient-looking mace in hand, hefting it reverently.\n'This was my companion for many years.' Noting your expression, she laughs, handing you the weapon.\n\n'Who do you think used to protect pilgrims and relight the Beacon?\n\n";
		nlist[17].dopt[3]="(1) Glad I could help.\n(2) How did you come to live at the temple?\n(3) Leave\n";
		nlist[17].info[3]="Suni's eyes grow misty. She moves to the edge of the fountain, placing her hands on the rim\nas she looks into the rippling waters.\n\n'I've lived here at the temple since I was a little girl.\nBrother Viri, he was just a priest then, took me in after he found me wandering\nnear the East Gate, alone and disheveled.'\n\nShe looks up, smiling again. 'He spent most of his time meditating,\nso I started planting flowers, warming the place up.'\n\nHer usual sunny disposition returns, lighting up the marble\nhall as she wipes away an unshed tear.\n'The guild started to grow, and thanks to the shop we can afford\nto send our acolytes anywhere, helping those in need.'\n";
		nlist[17].dopt[4]="(1) Glad I could help.\n(2) Is there anything else I can do for the Temple?\n(3) Leave\n";
		nlist[17].info[4]="She smiles. 'Traveler, you have already brought much light into the world.\nTrust in the Light, and watch as your good deeds ripple outward.'\n";

nlist[18]={
		"John",
		"wheezing noisily",
		"John the Smith, renowned craftsman and metalworker, has clearly seen better days.\nHis face is pale and drawn, and his breathing is shallow and labored; powerful limbs that\nwrought steel for the king's guard now lay wasting in cold sweat.\n",
		"The smith greets you wearily. 'Ho...and well met...stranger.'\n",
		"He retches miserably, holding up a finger\nas his head dips into a nearby barrel.\n",
		"John the Smith nods amiably as you leave,\nletting his head drop back onto the bench.\n",
		"'Thank you...so much. My customers...are satisfied...with your work.'\n",
		9};
		nlist[18].q=qlog[9];
		nlist[18].dopt[0]="(1) Do you need help with anything?\n(2) Are you okay?\n(3) Leave\n";
		nlist[18].info[0]="'Yeah...I'm...doing great...\nJust need a little...rest.\n";
		nlist[18].qline[1]="He struggles to sit up halfway, falling back. 'Well, maybe...a little.'\nHe summons, apparently, what remains of his strength.\n'I have orders to fill. But I'm...a little behind on my work.\nI have commissions for an iron dagger, a bar of steel, and a steel chainmail hauberk.'\n";
		nlist[18].dopt[1]="(1) I brought an iron dagger.\n(2) How should I obtain these items?\n(3) Leave\n";
		nlist[18].info[1]="'You can mine the materials and smith them yourself, or buy them from a different shop.'\n";
		nlist[18].qline[2]="'Thank you. Now I need...a bar of steel.'\n";
		nlist[18].dopt[2]="(1) Here's a steel bar, boss.\n(2) How do I make a steel bar?\n(3) Leave\n";
		nlist[18].info[2]="'You'll need...coal. And...iron.'\n";
		nlist[18].qline[3]="He chuckles weakly. 'Now...a set of steel chainmail.'\n";
		nlist[18].dopt[3]="(1) Here's that chainmail.\n(2) You're not gonna die on me, are you?\n(3) Leave\n";
		nlist[18].info[3]="He grins wanly. 'It's not...likely.'\n";
		nlist[18].dopt[4]="(1) I'm glad I could help.\n(2) What is your illness, exactly?\n(3) Leave\n";
		nlist[18].info[4]="'Guess I...caught a cold. I'll be...right as rain...anytime now. Don't you...worry.'\n";

nlist[19]={
		"Fisherman",
		"patching up his dinghy",
		"With a tarred brush in one hand, bucket in the other, and a stack of planks besides,\nthe stalwart fisherman is busily repairing several splintery holes in his craft.\n",
		"He glances up as you approach, wiping sweat from his eyes.\n",
		"The sunburnt fisherman peers at you keenly.\n'Was that a stroke? Gotta stay hydrated, friend.'\n",
		"He clasps your hand and returns to work, accidentally leaving you with a handful of pitch.\n",
		"The old salt shades his eyes, looking out over the lake.\n'Hard to believe e's really gone. Guess I better get back out there.'\n",
		19};
		nlist[19].q=qlog[18];
		nlist[19].dopt[0]="(1) What happened to your boat?\n(2) Are the fish biting today?\n(3) Leave\n";
		nlist[19].info[0]="He grins wryly. 'A little too much, I'm afraid.'\n";
		nlist[19].qline[1]="He looks out over the lake.\nAfter a beat of silence, he yells excitedly. 'There 'e is! Look at the size of 'im!'\nYou follow his gaze in time to see an enormous, spiny tail\nvanish beneath the waves in a spray of water.\n";
		nlist[19].dopt[1]="(1) Let me guess...\n(2) It's just the one, right?\n(3) Leave\n";
		nlist[19].info[1]="He shrugs. 'Probably, right? How many giant monsters can live in one lake?'\n";
		nlist[19].qline[2]="He pushes you in the direction of the lake. 'Get going! There are still people out there!'\n";
		nlist[19].dopt[2]="(1) Alright, the Lake Serpent is dead.\n(2) How should I go about beating the serpent?\n(3) Leave\n";
		nlist[19].info[2]="'Well, it's always surrounded by water; you could try an electric attack.'\n";
		nlist[19].dopt[3]="(1) There were more. Like a lot more.\n(2) Got any fishing tips?\n(3) Leave\n";
		nlist[19].info[3]="'Well, sure.' He scratches his head.\n'If you're looking for supplies, you'd best see my cousin in the city;\nyou can buy rods and bait there, but most importantly, his lures are the best in the business.\n";

nlist[20]={
		"Mayor",
		"standing on the main street, greeting the townsfolk",
		"The elderly mayor of Winterhold, dressed in a strange, velvety red suit, is walking along\nthe snowswept main street, shaking hands, exchanging pleasantries, and helping\ncarry packages, now and then emitting a booming, jolly laugh.\n",
		"The mayor greets you with a warm smile and a wink.\n",
		"With a chuckle, he says 'Sorry, my ears aren't what they used to be!'\n",
		"He picks you up in a surprisingly strong embrace. 'Remember, good cheer to all, my friend!'\n",
		"The ruddy-cheeked mayor lets out a booming laugh.\n'Ho, ho, ho! You've saved the festival, now all that remains is to join in the fun!'\n",
		19};
		nlist[20].q=qlog[19];
		nlist[20].dopt[0]="(1) Do you need help with anything?\n(2) What's with that suit?\n(3) Leave\n";
		nlist[20].info[0]="He looks down at the red, fur-trimmed suit. 'This? Oh, this is just my style.'\nHe gives you a broad wink, leaving you more confused than before.\n";
		nlist[20].qline[1]="He taps his chin. 'As it happens, I do;\nour Winter Festival is fast approaching, and you can imagine\how important that is in a town called 'Winterhold.'\nAnyhow, the exchanging of gifts is an important part, and a few of my folk have come up short this year.\n\nIt'd would surely raise their spirits if you could provide some gifts!'\n";
		nlist[20].dopt[1]="(1) Of course! I love spreading cheer.\n(2) What other festivals do you have here?\n(3) Leave\n";
		nlist[20].info[1]="The brightly-clothed mayor seems to think about this, then shakes his head in puzzlement.\n'I'm afraid I don't know what you mean!'\n";
		nlist[20].qline[2]="He grins merrily. 'First, Hilda wanted a wooden dagger for her son.'\n";
		nlist[20].dopt[2]="(1) Here's the wooden dagger!\n(2) How else do you celebrate the festival?\n(3) Leave\n";
		nlist[20].info[2]="'Oh, the usual! Feasts, music, dancing in the square, camaraderie as far as the eye can see!\n...and like as not, a bit too much drink for all. All in good fun!'\n";
		nlist[20].qline[3]="'This is perfect! They'll love it.\nNow, old Abenthy loves pies, especially around this time of year, but\nhis dear wife, who used to bake for him, passed on a few winters back.\nHe'd grin from ear to ear to get a redberry pie for the Festival.'\n";
		nlist[20].dopt[3]="(1) Here's a redberry pie for Abenthy.\n(2) Where can I find a pie?\n(3) Leave\n";
		nlist[20].info[3]="'There's a bakery in the city to the south that sells them...\nOr, if you want to add some love, you can make it yourself at the oven in the square.'\n";
		nlist[20].qline[4]="He examines the pie. 'Well done! Alright, the last gift we're missing this year:\nElric's wife has been sewing him a new tunic, but it won't be ready until after the Festival;\nShe'd be much obliged if we could find her one to use for a gift for him.'\n";
		nlist[20].dopt[4]="(1) Here's that tunic!\n(2) That's really it?\n(3) Leave\n";
		nlist[20].info[4]="The mayor smiles. 'We're a simple folk; usually we have everything we need here.'\n";
		nlist[20].dopt[5]="(1) Alright! Let the festivities commence!\n(2) What will you do?\n(3) Leave\n";
		nlist[20].info[5]="He lets out another booming laugh. 'Well, I'm the mayor, aren't I?\n...I'll just ensure the magic stays, magical.' He winks and taps the side of his nose.\n";
}

void defineCastleNPCs()
{
    cast_npc[0]={
		"null",//name
		"null",//idle
		" This is the ghost of a long dead NPC.\nYou're not sure how you're seeing it, or how long it's been here.\n",//description
		"The ghost looks up with a start.\n'You can see me?\n",//greeting
		"The phantasm howls mournfully.\n",//wrong command
		"'Remember to finish all your buuusineeeesss\n",//leaving
		"'oooOOoo-'\n",//quest completed
		2000};//ID number

		//Quest assigned - bas_q[0] is default NULL
		cast_npc[0].q=qlog[0];

		//dialog
		//dialog options first - chat response first - quest response first
		cast_npc[0].dopt[0]="(1) Do you need help with anything?\n(2) What's with that suit?\n(3) Leave\n";
		cast_npc[0].info[0]="'No, my business is finished, why?'\n";
		cast_npc[0].qline[1]="'This must be what I was wearing when I died.'\n";
		//dialog options second - chat response second - quest response second

    cast_npc[1]={
		"Doug",//name
		"standing uncomfortably slack-jawed",//idle
		"Doug appears to neither know or care how he got here.\nHe's wearing sweatpants and a t-shirt, both heavily stained.\n",//description
		"He looks up at you and grunts with a half nod. His eyes are kind of glazed.\n",//greeting
		"He blinks slowly and a little unevenly.\n",//wrong command
		"'Yeah.'\n",//leaving
		"'...right.'\n",//quest completed
		2001};//ID number

		//Quest assigned - bas_q[0] is default NULL
		cast_npc[0].q=bas_q[0];

		//dialog
		//dialog options first - chat response first - quest response first
		cast_npc[1].dopt[0]="(1) Do you need help with anything?\n(2) What's with that suit?\n(3) Leave\n";
		cast_npc[1].info[0]="'This is just how I dress.'\n";
		cast_npc[1].qline[1]="'What? Oh, no, not really.'\n";
		//dialog options second - chat response second - quest response second
		cast_npc[1].dopt[1]="(1) Do you need help with anything?\n(2) What's with that suit?\n(3) Leave\n";
		cast_npc[1].info[1]="'This is just how I dress.'\n";
		cast_npc[1].qline[2]="'What? Oh, no, not really.'\n";

cast_npc[2]={
		"Tom",//name
		"looking up at the sky",//idle
		"Tom looks strangely out of place here, though his demeanor is relaxed and friendly.\nHe's wearing a white t-shirt and a pair of well-worn jeans.\n",//description
		"Tom smiles and waves as you approach. 'Hey there!' he says enthusiastically.\n",//greeting
		"He shakes his head, looking nonplussed. 'Sorry, what was that?'\n",//wrong command
		"'I'll see you later, then!'\n",//leaving
		"'Thanks so much! I couldn't have done it without you!'\n",//quest completed
		2001};//ID number

		//Quest assigned - bas_q[0] is default NULL
		cast_npc[2].q=bas_q[0];

		//dialog
		//dialog options first - chat response first - quest response first
		cast_npc[2].dopt[0]="(1) Do you need help with anything?\n(2) Don't I know you from somewhere?\n(3) Leave\n";
		cast_npc[2].info[0]="He thinks about it. 'Hmm, no, I don't think so -\nI have a lot of friends, but I don't go out often.\nI usually just stay in my space.'\n";
		cast_npc[2].qline[1]="'Yes, please! I'm looking for an item - here, I'll write a description\nin your quest journal.'\n";
		//dialog options second - chat response second - quest response second
		cast_npc[2].dopt[1]="(1) Here's the item you needed.\n(2) What else has been going on lately?\n(3) Leave\n";
		cast_npc[2].info[1]="'Oh, nothing. There's not been a whole lot for me to do for the last few years.'\n";
		cast_npc[2].qline[2]="'Well done!'\n";
		//dialog options third - chat response third - quest response third
		cast_npc[2].dopt[2]="(1) No problem.\n(2) Do you need anything else?\n(3) Leave\n";
		cast_npc[2].info[2]="'No, I'm just glad to have such good friends.'\n";
		cast_npc[2].qline[3]="\n";

cast_npc[3]={
		"Henry",//name
		"leafing through a book",//idle
		"Henry is a placid-looking individual, wearing a comfortable yet sensible ensemble in unassuming earth tones.\nHe's studiously reading a complex-looking tome, glancing up every once in a while to survey the area.\n",//description
		"Henry smiles and waves as you approach. 'Hey there!' he says enthusiastically.\n",//greeting
		"He shakes his head, looking nonplussed. 'Sorry, what was that?'\n",//wrong command
		"'I'll see you later, then!'\n",//leaving
		"'Thanks so much! I couldn't have done it without you!'\n",//quest completed
		2002};//ID number

		//Quest assigned - bas_q[0] is default NULL
		cast_npc[3].q=bas_q[0];

		//dialog
		//dialog options first - chat response first - quest response first
		cast_npc[3].dopt[0]="(1) Do you need help with anything?\n(2) Don't I know you from somewhere?\n(3) Leave\n";
		cast_npc[3].info[0]="He thinks about it. 'Hmm, no, I don't think so -\nI have a lot of friends, but I don't go out often.\nI usually just stay in my space.'\n";
		cast_npc[3].qline[1]="'Yes, please! I'm looking for an item - here, I'll write a description\nin your quest journal.'\n";
		//dialog options second - chat response second - quest response second
		cast_npc[3].dopt[1]="(1) Here's the item you needed.\n(2) What else has been going on lately?\n(3) Leave\n";
		cast_npc[3].info[1]="'Oh, nothing. There's not been a whole lot for me to do for the last few years.'\n";
		cast_npc[3].qline[2]="'Well done!'\n";
		//dialog options third - chat response third - quest response third
		cast_npc[3].dopt[2]="(1) No problem.\n(2) Do you need anything else?\n(3) Leave\n";
		cast_npc[3].info[2]="'No, I'm just glad to have such good friends.'\n";
		cast_npc[3].qline[3]="\n";
}

void defineMainNPCs()
{
    mq_npc[0]={
		"Elder",//name
		"sitting on a bench, feeding the birds",//idle
		"Wearing the same long, grey robes you remember,\nyour esteemed village elder is looking up at the sky,\na half-torn loaf of bread in one hand.\nA group of small birds gather around, inquisitively waiting for their next morsel.\n\n",//description
		"The Elder greets you with a smile, evoking warm childhood memories.\n'What can I do for you, young'n?'\n",//greeting
		"The Elder frowns at you. 'I'm afraid I don't understand.'\n",//wrong command
		"'Be sure and take care of yourself.\n",//leaving
		"'oooOOoo-'\n",//quest completed
		2000};//ID number

		//Quest assigned - bas_q[0] is default NULL
		mq_npc[0].q=main_q[0];

		//dialog
		//dialog options first - chat response first - quest response first
		mq_npc[0].dopt[0]="(1) Do you need help with anything?\n(2) How are you today?\n(3) Leave\n";
		mq_npc[0].info[0]="He smiles broadly.\n'All my business for today is finished...I'm doing well!\n";
		mq_npc[0].qline[1]="'Well, I do have a package to deliver. But it could be dangerous.'\nHe squints at you appraisingly.\n\nAre you sure you'd be up to it?'\n";
        mq_npc[0].dopt[1]="(1) How dangerous?\n(2) What's in the package?\n(3) Leave\n";
		mq_npc[0].info[1]="A strange expression crosses his face.\n'Nothing special. Just a...an enchanted item, of sorts.'\n";
		mq_npc[0].qline[2]=" He laughs. 'Nothing you can't handle, I'm sure.\nA few wild Slimes in the forests, some wandering goblins.\nJust make sure you watch out for snakes.\n";
		mq_npc[0].dopt[2]="(1) Okay, I'll do it.\n(2) Anything else I should know about?\n(3) Leave\n";
		mq_npc[0].info[2]="He thinks about it.\n'Well, just make sure you have\nenough provisions for the journey, I suppose.'\n";
		//This option gives the player "The Silver Flask"
		mq_npc[0].qline[3]="'Excellent! Here, keep this safe, and be sure to tell me what he says.'\n";
		mq_npc[0].dopt[3]="(1) I've delivered the flask...\n(2) How do I survive the wilderness?\n(3) Leave\n";
		mq_npc[0].info[3]="'You may want to get some tools, like a tinderbox, and learn to light a 'fire'.'\n";
}

void defineCompNPCs()
{
    comp_npc[0]={
		"Luz",//name
		"launching arrows into a target with uncanny precision",//idle
		"The auburn-haired Elven huntress doesn't seem to have noticed you.\nHer eye is intent on her target, arrow shaft pressed against her cheek, bow drawn taut.\n\n",//description
		"She looks at you dismissively. 'What is it?'\n",//greeting
		"She rolls her eyes. 'You might at least attempt communication.'\n",//wrong command
		"'Go on, then. Please, don't hurry back.'\n",//leaving
		"'You actually did it! I'm impressed.'\n",//quest completed
		2000};//ID number

		//Quest assigned - bas_q[0] is default NULL
		comp_npc[0].q=qlog[20];

		//dialog
		//dialog options first - chat response first - quest response first
		comp_npc[0].dopt[0]="(1) Do you need help with anything?\n(2) How are you today?\n(3) Leave\n";
		comp_npc[0].info[0]="She doesn't appear to have heard you.\n";
		comp_npc[0].qline[1]="She releases her arrow, looking you up and down.\n'Sure, alright. If you can gather some herbs for me, I'll forgive you\nfor interrupting my training.'\n";
        comp_npc[0].dopt[1]="(1) Uh...okay. What do you need?\n(2) What makes you think I care?\n(3) Leave\n";
		comp_npc[0].info[1]="She smirks, turning back to her target and nocking another arrow.\n\n'Good, we're in agreement. Now leave me be.'\n";
		comp_npc[0].qline[2]="'There's a green herb that grows in the forest.\nGo and pick me one of those.'\n";
		comp_npc[0].dopt[2]="(1) I've brought the herb you wanted.\n(2) What else are you going to need?\n(3) Leave\n";
		comp_npc[0].info[2]="She glances at you, releasing another arrow into her target.\n'I won't know until you get me that one, will I?'\n";
		comp_npc[0].qline[3]="Luz takes the herb from your hand.\n\n'Good. Now, this one's a little harder, so I doubt you'll make it,\nbut there's a small, blue flower that grows in the icy north...'\n";
		comp_npc[0].dopt[3]="(1) I got the flower.\n(2) Should I know anything else about this flower?\n(3) Leave\n";
		comp_npc[0].info[3]="She doesn't look at you while she speaks, squinting at her distant target.\n\n'It's unusually beautiful...some even say it glows a little.\n\nIt grows in the north year-round, but it'll grow anywhere in the winter.\nIt's like nature's reminder that the harsher seasons are beautiful, too.'\n";
		comp_npc[0].qline[4]="The sarcastic huntress nods approvingly.\n\n'That's the one. I'm surprised you found it.\n\nNow, this one's actually dangerous, so take care...\nFar to the northeast, in the cooling lava plains surrounding\nthe ancient volcano there, legend tells of a bright orange flower\nwith potent, bitter stalks.\n\nBring me one of those and we're all done.\n";
		comp_npc[0].dopt[4]="(1) I've brought the last flower.\n(2) Why haven't you gotten these yourself?\n(3) Leave\n";
		comp_npc[0].info[4]="She scowls darkly.\n'Our customs prevent us from leaving the village without approval.\nBesides, I'm not even sure this volcano exists...'\n";
		comp_npc[0].qline[5]="Luz grins, holding out her hand for the bundle of torchweed stalks.\n\n'Great! Thank you. I can hardly believe they're real.\n\nShe frowns slightly.\n'I guess that mean's we're done, then.'\n\nShe shrugs, shouldering her bow.\n";
		comp_npc[0].dopt[5]="(1) Well...you could come with me.\n(2) What will you do now?\n(3) Leave\n";
		comp_npc[0].info[5]="Luz shrugs with a little half-smile.\n'I'll just keep practicing my archery, I suppose.'\n";

		comp_npc[1]={
		"Grognak",//name
		"crouching over the corpse of a slaughtered frillneck",//idle
		"This scarred giant seems barely human,\nthough there is a strange intelligence burning in his dark eyes.\nShaggy, greasy black hair hangs down past his shoulders,\nhis only raiment besides a ragged loincloth.\n",//description
		"He doesn't look up as you approach, but you can see he's listening.\n",//greeting
		"His heavy brow furrows. 'Unh?'\n",//wrong command
		"He raises a massive hand in salute. 'No let knifetooth bite.'\n",//leaving
		"He grins. 'Meat good! Eat good!'\n",//quest completed
		3000};//ID number

		//Quest assigned - bas_q[0] is default NULL
		comp_npc[1].q=qlog[21];

		//dialog options first - chat response first - quest response first
		comp_npc[1].dopt[0]="(1) Do you need help with anything?\n(2) What can you tell me about this forest?\n(3) Leave\n";
		comp_npc[1].info[0]="\nGrognak looks up at the forest canopy, watching light play through the broad leaves.\n'Forest deadly,' he says after a while. 'Forest hungry.'\nHe looks down at you, tapping his chest. 'Grognak part of forest.'\nThe hint of a smile gleams in his dark eye. 'Grognak hungry, too.'\n";
		comp_npc[1].qline[1]="The tan-skinned giant leans back from his kill,\nwiping the bone knife on his thigh.\n'Grognak hunt this one many day; tired. You hunt, Grognak rest here,\ntogether we eat, yes?'\n";
        comp_npc[1].dopt[1]="(1) Sounds fair. How many do we need?\n(2) How is it you speak the common tongue? Have there been other outsiders here?\n(3) Leave\n";
		comp_npc[1].info[1]= "His eyes darken. 'Men in armor came once. Attack village.'\nHe stabs into the scaly beast's thigh.\n'They not return.'\n";
        comp_npc[1].qline[2] = "He grins, showing huge molars. '5 frillneck be enough beast to feast.'\n";
        comp_npc[1].info[2] = "He taps his chin with the point of his grimy bone knife.\n'Hmm. Frillneck hard fight face to face. Maybe hunt, trap, then kill easy.'\n";
        comp_npc[1].dopt[2]="(1) Here, 5 frillneck carcasses.\n(2) Those things look tough...any advice?\n(3) Leave\n";
        comp_npc[1].qline[3] = "The burly warrior takes the dead lizards eagerly.\n'Good! This one done too. Come, come, to village!'\n\nGrognak leads you deep into the jungle.\nEventually you enter through the crude gates of his village,\ngreeted by the cheers of his tribesmen as he holds aloft the frillneck carcassess.\n\nA flurry of unfamiliar language and activity sweep you along.\nYou find yourself helping to build a firepit and skewer the meaty lizards.\n\nGreat bowls of a spicy, bitter liquid are poured, and the night\nbegins to pass in a blur of dancing and revelry.\nFat dribbles down your chin as you bite into a well-deserved\nchunk of charred lizard meat. You whirl around the fire, dancing with many jubilant, grinning faces\nbefore retiring to a flattish rock outside the circle.\n\nWhat a night.\n";


}

#endif // TSF_NPCS_H_INCLUDED
