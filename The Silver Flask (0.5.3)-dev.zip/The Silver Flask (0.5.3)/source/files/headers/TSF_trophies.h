#ifndef TSF_TROPHIES_H_INCLUDED
#define TSF_TROPHIES_H_INCLUDED

#include "tsf_classes.h"

void showTrophyList()
{
    int pts=0;
    int pts_tot=0;
    for(int x=1; x<100; x++)
    {
        pts_tot+=trophy_list[x].pts;
        cout<<"("<<x<<"): ";
        if(trophy_list[x].unlock)
            {cout<<trophy_list[x].mat<<" "<<trophy_list[x].name<<"\n"; pts+=trophy_list[x].pts;}
        else cout<<" -- \n";
    }
    cout<<"Collection score: "<<pts<<"/"<<pts_tot<<"\n\n";
}

void trophyGet(string name, int num)
{
    int get=0;
    if(num!=0)
    {
        get=num;
    }

    else
    {
        for (int x=1;x<101;x++)
        {
            if(trophy_list[x].name==name)
            {
                get=x;
                break;
            }
        }
    }

    trophy_list[get].unlock=true;
        cout<<"\nWhat's this? ...something dropped on the ground just now.\n";
        cout<<"\nIt's a "<<trophy_list[get].mat<<" "<<trophy_list[get].name<<" trophy!\n\nYou store the trophy in your pack.\n\n";

}

int trophyGetID(string name)
{
    int y=0;
    for (int x=1;x<101;x++)
        {
            if(trophy_list[x].name==name)
            {
                y=x;
                break;
            }
        }
    return y;
}

void defineTrophies()
{

//empty trophy slot for organization
trophy_list[0]={"null", "null", "null", 0, 0, 0};

//Group 1: quests
trophy_list[1]={"pine", "bronze", "null", 1, 1, 0};//Arana
trophy_list[2]={"hoe", "bronze", "null", 2, 1, 0};//Farmer
trophy_list[3]={"leaf", "bronze", "null", 3, 1, 0};//Sera
trophy_list[4]={"tunic", "bronze", "null", 4, 1, 0};//Fortuno
trophy_list[5]={"flute", "bronze", "null", 5, 1, 0};//Aria
trophy_list[6]={"bridge", "silver", "null", 6, 2, 0};//Mason
trophy_list[7]={"minecart", "silver", "null", 7, 2, 0};//D'tuum
trophy_list[8]={"bucket", "bronze", "null", 8, 1, 0};//Ferryman
trophy_list[9]={"skull charm", "bronze", "null", 9, 1, 0};//Shaman
trophy_list[10]={"bellows", "silver", "null", 10, 2, 0};//Smith
trophy_list[11]={"sword", "silver", "null", 11, 2, 0};//Emiria
trophy_list[12]={"chalice", "golden", "null", 12, 3, 0};//Gareth
trophy_list[13]={"serpent", "silver", "null", 13, 2, 0};//Valencia
trophy_list[14]={"skull", "golden", "null", 14, 3, 0};//Hakon
trophy_list[15]={"demon skull", "golden", "null", 15, 3, 0};//Archmage
trophy_list[16]={"wizard hat", "silver", "null", 16, 2, 0};//Azelfoff
trophy_list[17]={"fountain", "silver", "null", 17, 2, 0};//Viri
trophy_list[18]={"torch", "golden", "null", 18, 3, 0};//Suni

//Group 2: enemies
for(int x=0; x<39; x++)
{
    int y=x+19;
    //set trophy names by the list of enemy names;
    trophy_list[y]={elist[x].name, "bronze", "null", y, 1, 0};
    //set color to silver based on hp, atk, and def
    if(elist[x].hp>=40||elist[x].atk>9||elist[x].def>9){trophy_list[y].mat="silver";}
    //set boss trophies to golden
    if(elist[x].type=="boss"){trophy_list[y].mat="golden";}
}//end define enemy trophies


//Group 3: Exploration
trophy_list[58]={"spyglass", "golden", "null", 1, 1, 0};//100% exploration
trophy_list[59]={"snowman", "bronze", "null", 2, 1, 0};//Found Winterhold
trophy_list[60]={"gear", "bronze", "null", 3, 1, 0};//Found Elven Workshop
trophy_list[61]={"mountain", "bronze", "null", 4, 1, 0};//Found Glacial Palace
trophy_list[62]={"throne", "bronze", "null", 5, 1, 0};//Visited throne room
trophy_list[63]={"torchweed", "bronze", "null", 6, 3, 0};//Discovered volcano
trophy_list[64]={"redwood", "bronze", "null", 7, 2, 0};//Navigated ancient forest

//Random Encounters
trophy_list[65]={"faerie", "glass", "null", 8, 3, 0};//Faerie encounter
trophy_list[66]={"waterfall", "crystal", "null", 9, 4, 0};//Completed faerie quest
trophy_list[67]={"toadstool", "golden", "null", 10, 2, 0};//found fae court
trophy_list[68]={"signpost", "silver", "null", 11, 2, 0};//the Lost
trophy_list[69]={"crate", "golden", "null", 12, 3, 0};//the Needy
trophy_list[70]={"potion", "bronze", "null", 13, 2, 0};//the Sick
trophy_list[71]={"shield", "bronze", "null", 14, 3, 0};//the Weak
trophy_list[72]={"weasel", "silver", "null", 15, 3, 0};//thief
trophy_list[73]={"hawk", "golden", "null", 16, 2, 0};//traveler
trophy_list[74]={"net", "bronze", "null", 17, 2, 0};//trapper
trophy_list[75]={"straw hat", "silver", "null", 18, 3, 0};//wanderer

//Skills
trophy_list[76]={"axe", "golden", "null", 10, 1, 0};//woodcutting
trophy_list[77]={"anvil", "golden", "null", 9, 1, 0};//smithing
trophy_list[78]={"spool of thread", "golden", "null", 10, 2, 0};//sewing
trophy_list[79]={"pickaxe", "golden", "null", 11, 2, 0};//mining
trophy_list[80]={"cake", "golden", "null", 12, 3, 0};//baking
trophy_list[81]={"roast", "golden", "null", 13, 2, 0};//cooking
trophy_list[82]={"campfire", "golden", "null", 14, 3, 0};//firemaking
trophy_list[83]={"cauldron", "silver", "null", 15, 3, 0};//brewing
trophy_list[84]={"staff", "golden", "null", 16, 2, 0};//carving
trophy_list[85]={"obelisk", "golden", "null", 17, 2, 0};//enchanting
trophy_list[86]={"flute", "golden", "null", 18, 3, 0};//music
trophy_list[87]={"quill", "golden", "null", 9, 1, 0};//literacy
trophy_list[88]={"quiver", "golden", "null", 10, 2, 0};//hunting
trophy_list[89]={"trout", "golden", "null", 11, 2, 0};//fishing

//Gathering
trophy_list[90]={"cornstalk", "golden", "null", 12, 3, 0};//harvesting
trophy_list[91]={"firefly", "golden", "null", 13, 2, 0};//catching fireflies
trophy_list[92]={"millstone", "golden", "null", 14, 3, 0};//grinding flour
trophy_list[93]={"fleece", "golden", "null", 15, 3, 0};//shearing sheep

//Time
trophy_list[94]={"hourglass", "golden", "null", 16, 2, 0};//one year
trophy_list[95]={"snowflower", "sapphire", "null", 17, 2, 0};//winter
trophy_list[96]={"gourd", "amber", "null", 18, 3, 0};//fall
trophy_list[97]={"rose", "ruby", "null", 17, 2, 0};//summer
trophy_list[98]={"pinecone", "emerald", "null", 18, 3, 0};//spring

//Hidden Objective
trophy_list[99]={"staircase", "crystal", "null", 15, 3, 0};//???
trophy_list[100]={"homestead", "model", "null", 16, 2, 0};//build a house


for(int x=0;x<100;x++)
    {
        trophy_list[x].id=x;
        if (trophy_list[x].mat=="bronze") trophy_list[x].pts=1;
    else if(trophy_list[x].mat=="silver")trophy_list[x].pts=2;
    else if(trophy_list[x].mat=="golden")trophy_list[x].pts=3;
    else if(trophy_list[x].mat=="crystal")trophy_list[x].pts=4;}

}//end define trophies

#endif // TSF_TROPHIES_H_INCLUDED
