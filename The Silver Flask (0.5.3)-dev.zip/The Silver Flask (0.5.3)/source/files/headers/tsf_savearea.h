#ifndef TSF_SAVEAREA_H_INCLUDED
#define TSF_SAVEAREA_H_INCLUDED

#include <tsf_classes.h>
#include <fstream>
#include <string>
#include <iostream>

for (int x = 0; x < 11; x++)
    for (int y = 0; y < 11; y++)
{
    //
    save_area(loc[x][y]);
}


void save_area(area a)
{
    //Area is passed here, written to file

    ofstream f_area;

    string fname = pc.name +"_area_" + to_string(a.id) + ".txt";
    f_area.open(fname);
    if(!f_area.is_open()) {cout<<"\nFile error! Could not create " << fname << "\n"; return;}

    f_area << a.armory << endl;
    f_area << a.chest << endl;
    f_area << a.crops << endl;
    f_area << a.desc << endl;
    f_area << a.east << endl;
    f_area << a.echance << endl;
    f_area << a.enemies << endl;
    f_area << a.fire << endl;
    f_area << a.foe.name << endl;
    f_area << a.herbs << endl;
    f_area << a.id << endl;
    f_area << a.is_outside << endl;
    f_area << a.key << endl;
    f_area << a.lastvisitday << endl;
    f_area << a.loc_fauna.id << endl;
    f_area << a.loc_flora.id << endl;
    f_area << a.loc_shop.id << endl;
    f_area << a.loc_tobj.id << endl;
    f_area << a.loot.id << endl;
    f_area << a.map_color1 << endl;
    f_area << a.map_color2 << endl;
    f_area << a.mine << endl;
    f_area << a.north << endl;
    for(int i = 0; i < 2; i++) {f_area << a.npcs[i].id << endl;}
    f_area << a.sheep << endl;
    f_area << a.smithy << endl;
    f_area << a.south << endl;
    f_area << a.toolshop << endl;
    f_area << a.visits << endl;
    f_area << a.water << endl;
    f_area << a.west << endl;
    f_area << a.wood << endl;

    f_area.close();
    if(f_area.is_open()) {cout <<"\nFile error! Could not close " << fname <<"\n";}
}

static_object load_indoor_object(int area_id, int vector_position, int contents_size)
{
    static_object obj = static_object_list[object_id];
    vector <equipment> contents[contents_size];
    ifstream f_obj;
    string fname = pname + "_area" + area_id + "_obj" +vector_position+".txt";

    //Load object from index
    //Load contents from file
    f_obj.open(fname);
    for (int i = 0; i < contents_size; i++)
    {
        //Get an object from the corresponding file
        //Area loot, player inventory,
        //Or in this case, a specific object's contents
        equipment temp = temp.loadFromFile(pc.name, "_obj_", n);
        obj.contents.push_back(temp);
    }
    f_obj.close();
}

building load_building(string player_name, int area_id, int obj_size)
{
    ifstream f_bldg;
    string fname = player_name + "_area" + area_id + "_" + "bldg.txt";
    building b;
    vector <int> contents_size[obj_size];

    f_bldg.open(fname)
    if(!f_bldg.is_open())
    {
        cout << "\nFile error! Could not open " << fname << "\n";
    }

    f_bldg >> b.name;
    f_bldg >> b.complete;
    f_bldg >> b.ireq;
    f_bldg >> b.loc_npc.id;
    f_bldg >> b.sreq;
    f_bldg >> b.wreq;

    for (int i = 0; i < obj_size; i++)
    {
        f_bldg >> contents_size[i];
        b.objects.push_back( load_indoor_object(n, i, contents_size[i]) );
    }
}

void load_area_main(x, y)
{
    area a = area_search(11, 11, loc[x][y].name);

    ifstream f_area;
    string fname = pc.name + "_area_" + a.id;

    f_area.open(fname);

    if(!f_area.is_open())
    {
        cout << "\nFile error! Could not find " << fname << "\n";
        return;
    }

    //Creates a blank temporary area struct
    //Loads data into it from the main area index
    //Overwrites from file
    //Returns that area to the main index

    f_area >> a.armory;
    f_area >> a.chest;
    f_area >> a.crops;
    f_area >> a.desc;
    f_area >> a.east;
    f_area >> a.echance;
    f_area >> a.enemies;
    f_area >> a.fire;
    f_area >> a.foe.name;
    f_area >> a.herbs;
    f_area >> a.id;
    f_area >> a.is_outside;
    f_area >> a.key;
    f_area >> a.lastvisitday;

    a.loc_bldg = load_building(pc.name, a.id);

    f_area >> a.loc_fauna.id;
    a.loc_fauna = anim[a.loc_fauna.id];
    f_area >> a.loc_flora.id;
    a.loc_flora = anim[a.loc_flora.id];

    f_area >> a.loc_shop.id;
    a.loc_shop = shops[a.loc_shop.id];

    f_area >> a.loc_tobj.id;
    a.loc_tobj = tobj[a.loc_tobj.id];

    f_area >> a.loot.id;
    a.loot = eq[a.loot.id];

    f_area >> a.map_color1;
    f_area >> a.map_color2;
    f_area >> a.mine;
    f_area >> a.north;

    for(int i = 0; i < 2; i++) {f_area >> a.npcs[i].id; a.npcs[i] = nlist[a.npcs[i].id];}

    f_area >> a.sheep;
    f_area >> a.smithy;
    f_area >> a.south;
    f_area >> a.toolshop;
    f_area >> a.visits;
    f_area >> a.water;
    f_area >> a.west;
    f_area >> a.wood;

    cout <<"\nLoad Successful!\n";

    f_area.close()
    if(f_area.is_open())
    {
        cout << "\nFile error! Could not close " << fname <<"\n";
    }

    loc[x][y] = a;
}

#endif // TSF_SAVEAREA_H_INCLUDED
