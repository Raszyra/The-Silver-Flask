#ifndef STATIC_WINDOW_H_INCLUDED
#define STATIC_WINDOW_H_INCLUDED

#include <Windows.h>
#include <iostream>
#include <fstream>
#inclue <ctime>

// Define the custom window class globally
LPCSTR g_szClassName = "MyCustomWindowClass";

 string shape = "rect";

// Function to create a new window
HWND CreateCustomWindow(HINSTANCE hInstance, int nCmdShow, LPCSTR title, int width, int height) {
    // Step 1: Create the window
    HWND hwnd = CreateWindowEx(
        0,
        g_szClassName,            // Window class name
        title,                    // Window title
        WS_OVERLAPPEDWINDOW,      // Window style
        CW_USEDEFAULT,            // Initial X position
        CW_USEDEFAULT,            // Initial Y position
        width,                    // Initial width
        height,                   // Initial height
        NULL,                     // Parent window
        NULL,                     // Menu
        hInstance,                // Instance handle
        NULL                      // Additional application data
    );

    if (!hwnd) {
        MessageBox(NULL, "Window Creation Failed!", "Error", MB_ICONERROR | MB_OK);
        return NULL;
    }

    // Show and update the window
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    return hwnd;
}

// Message callback function
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    switch (uMsg) {
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        case WM_CLOSE:
            {
                int result = MessageBox(NULL, "Are you sure?", "Really sure?", MB_OK | MB_ICONQUESTION);

                if(result == IDOK)
                {
                    PostQuitMessage(0);
                    return 0;
                }
            }
            return 0;
        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd, &ps);

                HBRUSH hBrush = CreateSolidBrush(RGB(13, 20, 122));
                HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
                if(Rectangle(hdc, 50, 50, 200, 150);
            }
            return 0;
        case WM_LBUTTONDOWN:
            {
                std::cout<<"That's a mouse button.\nLeft, I think.\n";
            }
            return 0;
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}

// Main function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Step 1: Define the window class
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = g_szClassName;

    // Step 2: Register the window class
    if (!RegisterClass(&wc)) {
        MessageBox(NULL, "Window Registration Failed!", "Error", MB_ICONERROR | MB_OK);
        return 0;
    }

    // Step 3: Create windows on the fly
    HWND hwnd1 = CreateCustomWindow(hInstance, nCmdShow, "Window 1", 400, 300);
    HWND hwnd2 = CreateCustomWindow(hInstance, nCmdShow, "Window 2", 600, 400);

    // Step 4: Run the message loop
    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}


#endif // STATIC_WINDOW_H_INCLUDED
