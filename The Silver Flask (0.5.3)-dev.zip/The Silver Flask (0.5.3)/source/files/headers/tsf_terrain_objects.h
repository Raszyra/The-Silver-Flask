#ifndef TSF_TERRAIN_OBJECTS_H_INCLUDED
#define TSF_TERRAIN_OBJECTS_H_INCLUDED

#include "tsf_classes.h"

void define_terrain_objects()
{
    //name, desc, id;

    tobj[0]={
        "null",
        "null",
        0};

    tobj[1]={
        "boulder",
        "It's a nondescript hunk of rock. Unclear where it came from.\n",
        1};

    tobj[2]={
        "giant sycamore",
        "A huge, old tree with a mantle of green leaves. You can't see through the branches to the top.\n",
        2};

    tobj[3]={
        "fissure",
        "Some time in the primordial past this crack opened as tectonic plates moved.\nNow it's just a hole full of moss.\n",
        3};

    tobj[4]={
        "fallen log",
        "The collapsed trunk of an old oak, full of insects breaking it down.\n",
        4};

    tobj[5]={
        "bird's nest in a tree",
        "It's where birds live.\n",
        5};

    tobj[6]={
        "gully",
        "A short distance away the land dips into a shallow valley.\n",
        6};

    tobj[7]={
        "rustic well"
        "It's an old well. You peer down to the bottom; looks like there's still water in it.\n"
        7}

    tobj[8]={
        "statue",
        "A moss-covered stone sculpture. It's clearly been out here a while.\n",
        8};
}

#endif // TSF_TERRAIN_OBJECTS_H_INCLUDED
