#include<iostream>
#include<ctime>

using namespace std;

string suit[4]={" ", "blades", "leaves", "face"};
string face[8]={"drifting feathers", "lonely spire", "frozen spire", "red flame", "blue flame", "sunrise", "sunset", "soul"};
string desc[8]={
	"'Looks like you'll be travelling soon.'",
	"'You'll become strong, yes, but alone, so alone...'",
	"'You will gain great knowledge, but at what cost?' She cackles.",
	"'That's pain, that is, pain of the flesh.'",
	"'There's a stormcloud on your horizon...'",
	"'There's new beginnings in store for you! Oh, yes.'",
	"'Oh, dearie. There's great loss in store. An ending of some kind.'",
	"'It seems you're about to realize great potential.\n..how great, is up to you.'"};
string com[3]={"hmm", "huh", "eh"};
string type[3]={"null", "obstacle", "opportunity"};
string sev[5]={"null", "small", "common", "major", "grand"};

int snum, fnum, tnum, val;
string input="1";
int cnum;
int counter;

void dekara()
{
cout<<"\nYou approach the table. The old woman looks up as though she's been expecting you.\n'Go on then,' she says. 'Have a seat.'\n";

do{

snum=rand()%4+1;
val=rand()%4+1;
fnum=rand()%8;
cnum=rand()%3;

cout<<"\nThe hooded crone draws a card.\n";
if(snum<3)
{
	cout<<"'The "<<val<<" of "<<suit[snum]<<", "<<com[cnum]<<"?\n";
	cout<<"'Looks like there's a "<<sev[val]<<" "<<type[snum]<<" coming your way.'\n";
}
else
{
	cout<<"'It's the "<<face[fnum]<<" card.'\n";
	cout<<desc[fnum]<<"\n";
}

counter++;
cout<<"(1) next card\n(2) quit\n";
cin>>input;

if(counter==7)
{
    cout<<"The old woman leans back, looking at you shrewdly.\n'That's it, then. How you interpret that, is up to you.'\nShe returns to shuffling her cards.\n";
    cout<<"\nPlay Again?\n(1) yes\n(2) no\n";
    cin>>input;
    if(input=="1")
    {
        counter=0;
    }
    else {cout<<"You take your leave.\n";}
}
}while(input=="1"&&counter<7);
}
