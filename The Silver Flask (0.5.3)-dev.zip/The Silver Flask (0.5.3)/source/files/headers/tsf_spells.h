#pragma once

#ifndef TSF_SPELLS_H_INCLUDED
#define TSF_SPELLS_H_INCLUDED

#include "tsf_classes.h"

void define_spells()
{

	//name, class, elem, b. dmg, max dmg, cost, id, level, unlock

	null_spell = {"null", "", "", 0, 0, 0, 0, 0, false};
	null_spell.desc = "";

	splist[0]={"char", "Mage", "fire", 5, 10, 5, 0, 5, false};
	splist[0].desc = "Sear your opponent or light a fire with a small burst of flame.";

	splist[1]={"frostbite", "Mage", "ice", 3, 8, 5,1, 6, false};
	splist[1].desc = "Chill your opponent with a sudden wave of frigid air,\n    coating them in frost and lowering their dexterity.";

	splist[2]={"shock", "Mage", "electric", 5, 10, 7, 2, 7, false};
	splist[2].desc = "Jolt your enemy with a sudden bolt of electricity.\n    Has a chance to paralyze.";

	splist[3]={"gust", "Mage", "wind", 4, 10, 6, 3, 5, false};
	splist[3].desc = "Stagger your enemy with a gust of wind.";

	splist[4]={"rockspike",  "Mage", "earth", 5, 12, 7, 4, 6, false};
	splist[4].desc = "Summon a spur of stone from below, piercing the enemy's armor.";

	splist[5]={"pierce",  "Hunter", "physical", 3, 15, 5, 5, 5, false};//adds enemy armor to max dmg
	splist[5].desc = "Seek a gap in the opponent's armor with the point of your weapon.";

	splist[6]={"salve",  "Herbalist", "heal", 3, 10, 5, 6, 5, false};//heal
	splist[6].desc = "Heal a small amount of HP.";

	splist[7]={"throw",  "Adventurer", "none", 0, 10, 0, 7, 3, false};
	splist[7].desc = "Use in combat to throw a weapon or an item at your enemy.\nUse outside combat to get rid of unwanted items.";

	splist[8]={"crush",  "Fighter", "physical", 5, 15, 6, 8, 5, false};
	splist[8].desc = "Strike your opponent with a blunt edge.\nHas a chance to damage armor.";
	;
	splist[9]={"toxin",  "Herbalist", "poison", 3, 7, 8, 9, 7, false};//low chance to poison
	splist[9].desc = "Attempt to poison your enemy. Deals damage over time if successful.";

	splist[10]={"remedy", "Herbalist", "water", 0, 0, 10, 10, 6, false};//status heal
	splist[10].desc = "Remove all impurities from your body.";

	splist[11]={"fireball", "Wizard", "fire", 5, 20, 16, 11, 10, false};
	splist[11].desc = "Deal a large amount of fire damage.";

	splist[12]={"mist", "Necromancer", "water", 0, 0, 10, 12, 10, false};//raise dex
	splist[12].desc = "Covers the area in a cloaking mist. Temporarily raises evasion.";

	splist[13]={"drench", "Mage", "water", 3, 7, 5, 13, 5, false};
	splist[13].desc = "Douse your opponent in a deluge of water.\nLow damage but a chance to cause choking. Puts out nearby fires.";

	splist[14]={"hack", "Barbarian", "physical", 7, 25, 8, 14, 10, false};//critical damage
	splist[14].desc = "Aim to sever with high critical hit damage.";

	splist[15]={"pray", "Priest", "heal", 7, 12, 10, 15, 10, false};//heal
	splist[15].desc = "Heal a modest amount of HP with a chance to temporarily raise stats in combat.";

	splist[16]={"assess", "Scholar", "none", 0, 0, 0, 16, 3, false};//check enemy stats; analyze objects outside combat
	splist[16].desc = "Use on items or enemies to obtain detailed knowledge of their attributes.";

	splist[17]={"reanimate", "Necromancer", "dark", 0, 0, 40, 17, 12, false}; //noncom for xp farming
	splist[17].desc = "Bring a vanquished enemy back to life.";

	splist[18]={"venom", "Ranger", "poison", 5, 7, 15, 18, 11, false};//high chance to poison
	splist[18].desc = "Deals modest damage with a high chance to poison.";

	splist[19]={"defend", "Knight", "shield", 0, 0, 12, 19, 10, false};// this one's a bit tricky. Raises defense for two turns
	splist[19].desc = "Use a shield to defend against the next attack.";

	splist[20]={"blessing", "Priest", "holy", 0, 0, 20, 20, 12};//buff lck
	splist[20].desc = "Use in battle to temporarily increase luck.";

	splist[21]={"ward", "Priest", "holy", 0, 0, 15, 21, 12};//buff defense
	splist[21].desc = "Augment your defense with holy magic.";

	splist[22]={"burningblade", "Spellsword", "fire", 1, 10, 15, 22, 10};
	splist[22].desc = "Temporarily enchant your weapon.\nAdds fire damage based on intellect.";

	splist[23]={"aquablade", "Spellsword", "water", 1, 10, 13, 23, 10};
	splist[23].desc = "Temporarily enchant your weapon.\nAdds water damage based on intellect.";

	splist[24]={"hailstorm", "Wizard", "ice", 10, 20, 18, 24, 11};
	splist[24].desc = "Deal a large amount of ice damage.\nSlows the opponent.";

	splist[25]={"torrent", "Wizard", "water", 5, 20, 15, 25, 10};//choking hazard
	splist[25].desc = "Summon a mighty flood to overwhelm your opponents.";

	splist[26]={"gale", "Wizard", "wind", 10, 15, 17, 26, 11};//
	splist[26].desc = "Batter enemies with a powerful wind.\nHas a chance to stagger foes.";

	splist[27]={"sunray", "Priest", "holy", 5, 10, 15, 27, 11};//straight damage
	splist[27].desc = "Catch your opponent in an evil-cleansing ray of light.";

	splist[28]={"vine", "Druid", "earth", 1, 12, 12, 28, 10};//-dxt
	splist[28].desc = "Ensnare your foe in tangling vines.\nDeals moderate earth damage with a chance to paralyze.";

	splist[29]={"crow", "Druid", "wind", 8, 13, 20, 29, 13}; //straight damage; summons a crow
	splist[29].desc = "Summon a crow to attack your enemy.";

	splist[30]={"reaper", "Necromancer", "death", 0, 0, 30, 30, 15};//chance of instakill against str
	splist[30].desc = "Summon the essence of Death to drag your foes into the underworld.";

	splist[31]={"cleave", "Barbarian", "physical", 10, 17, 15, 31, 13};//breaks armor
	splist[31].desc = "Cleave your enemy with an overhead strike. Damages armor.";

	splist[32]={"stealth", "Ranger", "dark", 0, 0, 17, 32, 14};//unblockable
	splist[32].desc = "Change your stance to one that conceals your movements.\nDecreases enemy dodge chance while increasing your own.";

	splist[33]={"sunsear", "Priest", "holy", 10, 20, 42, 33, 13};//straight damage
	splist[33].desc = "Burn your foe with radiant light.";

	splist[34]={"iceblade", "Spellsword", "ice", 0, 0, 21, 34, 11};
	splist[34].desc = "Temporarily enchant your weapon.\nAdds ice damage based on intellect.";

	splist[35]={"sparkblade", "Spellsword", "electric", 0, 0, 25, 35, 11};
	splist[35].desc = "Temporarily enchant your weapon.\nAdds lightning damage based on intellect.";

	splist[36]={"lifedrain", "Necromancer", "death", 10, 15, 15, 36, 13};//returns a portion of damage as HP
	splist[36].desc = "Steal your opponent's vital energy, using it to heal yourself.";

	splist[37]={"doomshadow", "Necromancer", "dark", 1, 10, 30, 37, 13};//drops all enemy stats by base int
	splist[37].desc = "Plague your foes with malignant malaise. Reduces all stats if successful.";

	splist[38]={"grow", "Druid", "earth", 1, 40, 27, 38, 15};//causes plants to grow when used out of combat
	splist[38].desc = "Feed the earth with your mana.";

    splist[39]={"sunmeld", "Sunclan", "fire", 1, 10, 30, 39, 1};
    splist[39].desc = "Channel the energy of the sun. Use it to scorch foes or meld metal.";

    splist[40]={"inscribe", "Moonclan", "dark", 0, 0, 25, 40, 1};
    splist[40].desc = "Use the ancient runic language of the Moonclan to summon the elements or enchant weapons.";

    //damage min, damage max, mp cost, id number, level unlock
	splist[41]={"kick", "Adventurer", "physical", 1, 8, 5, 41, 4};
	splist[41].desc = "Lash out with your leg for a more powerful unarmed attack.\nHas a small chance to stun.";

	splist[42]={"vigor", "Bard", "music", 0, 0, 10, 42, 2};//raise atk by 1
	splist[42].desc = "Play a rousing melody to raise your party's Attack.";

	splist[43]={"charm", "Bard", "music", 0, 0, 10, 43, 4};//lower e.atk by 1/2 int
	splist[43].desc = "Accompany a wistful melody with a sweet scent, lowering your foe's aggression.";

	splist[44]={"swarm", "Druid", "poison", 10, 20, 30, 44, 13};//large damage, good chance to poison; summons a bee
	splist[44].desc = "Call nearby insects to your aid.";

	splist[45]={"raise", "Necromancer", "death", 0, 0, 45, 45, 15};//summon local enemy as practice target/party member?
	splist[46]={"bear", "Druid", "earth", 10, 15, 25, 46, 15};//straight damage; summons a bear

	//guild class skills
    splist[47]={"blessedblade", "Paladin", "light", 1, 1, 15, 47, 14};//buff atk, ench weap
    splist[48]={"holyshield", "Paladin", "light", 0, 0, 20, 48, 1};//buff def, ench acc
    //Avatar
    splist[49]={"presence", "Avatar", "spirit", 0, 0, 100, 49, 15};//super saiyan
    splist[49].desc = "Fill your soul with ancient energy.";
	splist[50]={"banish", "Avatar", "light", 0, 0, 75, 50, 15};//kill any dark, death
	splist[50].desc = "Destroy the enemies of light.";
	//Assassin
	splist[51]={"vitalstrike", "Assassin", "electric", 20, 20, 25, 51, 13};//triple crit chance
	splist[52]={"shadowstep", "Assassin", "dark", 5, 15, 30, 52, 14};//triple dex
	//Archon
	splist[53]={"skyfall", "Archon", "electric", 10, 37, 35, 53, 13};//massive lightning dmg
	splist[54]={"starfall", "Archon", "fire", 30, 55, 75, 54, 15};//massive fire damage; destroys structures

	//bard skills
    splist[55]={"infatuate", "Courtesan", "music", 1, 5, 15, 55, 10};//lowers e.atk
    splist[56]={"skewer", "Fencer", "physical", 7, 18, 15, 56, 10};//adds e.armor to dmg
    splist[57]={"riposte", "Fencer", "physical", 5, 10, 10, 57, 13};//
	splist[58]={"empower", "Courtesan", "music", 0, 0, 20, 58, 11};//raise atk for party
	splist[59]={"pacify", "Courtesan", "music", 0, 0, 25, 59, 12};//large chance to paralyze
	splist[60]={"steal", "Thief", "none", 0, 0, 10, 60, 5};//gain gold based on lck and e.gpdr
	splist[61]={"stab", "Bandit", "physical", 10, 20, 30, 61, 13};//adds half e.def to atk

    splist[62]={"diversion", "Trickster", "dark", 0, 0, 15, 62, 10};//lowers enemy int, lck, dex
    splist[63]={"cardtrick", "Trickster", "physical", 1, 18, 15, 63, 11};//straight damage with a random effect
    splist[64]={"vanish", "Trickster", "dark", 0, 0, 27, 64, 13};//raises dex by a lot
	splist[65]={"mug", "Bandit", "physical", 1, 13, 15, 65, 10};//damages and returns gold
	splist[66]={"sense", "Wanderer", "psyche", 0, 0, 2, 66, 3};//gain information about weather, season, enemy weakness
	splist[67]={"hide", "Wanderer", "dark", 0, 0, 15, 67, 2};//gain dex on int+dx check
	splist[68]={"meditate", "Scholar", "psyche", 0, 0, 0, 68, 2};//restore MP based on intellect
	splist[68].desc = "Focus your mind and restore your energy.\n";

	//Herbalist
	splist[69]={"poultice", "Herbalist", "heal", 5, 18, 20, 69, 7};//Heal a moderate amount of HP and restore status
        splist[69].desc = "Heal a moderate amount of HP and restore status.";
	splist[70]={"herblore", "Herbalist", "earth", 0, 0, 0, 70, 9};//Shows advanced information about herbs
        splist[70].desc = "[Passive] Shows advanced information about herbs.";

    //Enemy skills
    splist[71]={"acid", "reptile", "poison", 5, 20, 20, 71, 1};//damage, armor damage, poison chance
        splist[71].desc = "A scalding caustic compound that melts through armor and poisons the blood.";

}

void define_songs()
{
    songs[0]={"Battle March", "ACDC", "A rousing battle march. Nearby enemies have grown bolder.\n", 0};//raise danger level nearby
    songs[1]={"Seasons' Hymn", "DBCA", "A song of wistful nostalgia, and hope,\nreminiscent of the changing of the seasons.\n", 1};//rotate to next season
    songs[2]={"Sunrise Melody", "ABCD", "A chipper tune of wakefulness and sharp morning air.\n", 2};//change time to morning
    songs[3]={"Serenity", "CCBC", "A somber air, and a pacific aura settles over the area.\n", 3};//reduce threat level nearby to zero
    songs[4]={"Snowfall", "DADA", "A twinkling melody that brings to mind holly berries and pine trees;\na fine dusting of snow begins to drift down from the clouds.\n", 4};//change weather to snow
    songs[5]={"Song of Storms", "ABDA", "As if from a distant memory, your fingers\nfind the notes, playing a song of rising storms.\nRain begins to fall around you, distant thunder rumbling.\n", 5};//change weather to storm
    songs[6]={"Lucky Cat", "ADAD", "You hear the tinkling of a bell; to your surprise,\na calico cat darts out of the undergrowth, pauses to look at you,\nand very deliberately paws at the earth a few meters away.\nYou inspect the area.\n", 6};//reroll chest chance
    songs[7]={"Spring Song", "AABD", "A vibrant, vivacious melody - you feel a strange tingling \nin your fingertips. All around you the grass seems to stand up a little\nstraighter, and a few flowers bloom.\n", 7};//regrow all growables, grow herbs nearby
    songs[8]={"Rogue's Lament", "CBAA", "A mournful tune of a sailor down on his luck.\n", 8};//
    songs[9]={"Starlight Aria", "DCDD", "A low, contemplative melody, thinking of starry nights\nspent in wonder at the depth of the velvet sky.\n", 9};//change time to night
}


#endif
