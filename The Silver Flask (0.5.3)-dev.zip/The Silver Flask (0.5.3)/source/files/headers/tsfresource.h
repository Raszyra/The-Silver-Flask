#define IDR_SOUND 1
#define MY_ICON 1
