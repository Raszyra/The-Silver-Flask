#ifndef TSF_BUILDINGS_H_INCLUDED
#define TSF_BUILDINGS_H_INCLUDED

#include "tsf_classes.h"

/*==================================================
NOTE:
    -When defining shops, add in an extra item slot;
    the wares display list starts at 1, with an
    empty item at position 0.

====================================================*/

void define_buildings()
{
    //name, ext_desc, int_desc, wreq, ireq, sreq
    //loc_npc, a vector each for 'deco' and 'objects'

    null_bldg={
        "null",
        "null",
        "null",
        0, 0, 0};
    null_bldg.loc_npc=nlist[0];

    house={
        "House",
        "a quaint country home",
        "This house is simply furnished, with a few rustic touches to the architecture;\nsimple wooden floors, unpapered white walls, and a sturdy,\nwindowed wooden front door.\nSunlight streams in through the unshuttered windows.\n",
        10, 3, 5};
    house.loc_npc=nlist[0];
}

void define_shops()
{
    //armory, potion shop, merchant, fencer, gemshop
    //string name, desc, greeting, error, purchase; int wares_max; vector<int>wares_id;
    shops[0]={
        "null",
        "null",
        "null",
        "null",
        "null",
        "null",
        0, 0};
    shops[0].ext_desc="null";

    shops[1]={
        "Bakery",
        "The air in the bakery is warm, and smells of pie crust.\nA plump elven woman stands behind the counter, her apron dusted with flour.\nSeveral glass cases display a mouthwatering arrangement of cookies, pies, cakes, and bread.\n",
        "The baker smiles brightly. 'What can I get you?'\n",
        "'I'm sorry, I don't understand..'\n",
        "She opens the case and hands you the ",
        "She gives you a cheery wave and returns to rolling pastry.\n",
        6, 1};
    shops[1].ext_desc="a quaint bakery";
    shops[1].wares_id.push_back(getItemID("none", "bread"));
    shops[1].wares_id.push_back(getItemID("redberry", "pie"));
    shops[1].wares_id.push_back(getItemID("greenberry", "pie"));
    shops[1].wares_id.push_back(getItemID("sweet", "bun"));
    shops[1].wares_id.push_back(getItemID("none", "flour"));

    shops[2]={
        "Sandy's Sundries",
        "You stroll into a small, brightly lit shop. The shelves are lined with odds and ends,\nfrom bits of string to copper kettles. A narrow-faced man in an apron waves as you enter.\nYou can't help but notice you're the only customer in the shop.\nThe shopkeep calls to you from behind the counter.\n'Welcome in! I'm Sandy.'\nHe looks around. 'These are my sundries.\n",
        "\n'..Can I help you find anything?'\n",
        "Sandy stares at you for a second. 'What?'\n",
        "'Coming right up!' The rangy shopkeep swaps the item for your handful of coins.\n",
        "'Alright, then. Come back around some time! Tell your friends!'\n",
        5, 2};
    shops[2].ext_desc="a general store";
    shops[2].wares_id.push_back(getItemID("wooden", "bucket"));
    shops[2].wares_id.push_back(getItemID("raw", "meat"));
    shops[2].wares_id.push_back(getItemID("none", "wheat"));
    shops[2].wares_id.push_back(getItemID("iron", "pot"));

    shops[3]={
        "Kraftwerks",
        "The first thing that strikes you as you duck into the dark, tangled space is the noise; dozens of\nsteam-powered machines clatter away, gears turning, hissing spouts of vapor.\nA soot-covered elf with a sizable paunch is hunched over one of many steel pipes, wrenching a bolt.\n",
        "The elf turns around, raising his welding visor.\n'Welcome to the Kraftwerks. I'm Siegfried. Need some crafting materials?'\n",
        "Siegfried shakes his head, reaching over to adjust a dial.\n",
        "'Alright, hang on.' Siegfried rummages through a few nearby boxes, coming up with the requested item.\n",
        "The Elven engineer claps you wordlessly on the shoulder, then returns to his machines.\n",
        5, 3};
    shops[3].ext_desc="a ramshackle building covered in riveted iron plates and pipes";
    shops[3].wares_id.push_back(getItemID("none", "coal"));
    shops[3].wares_id.push_back(getItemID("iron", "ore"));
    shops[3].wares_id.push_back(getItemID("none", "wool"));
    shops[3].wares_id.push_back(getItemID("none", "leather"));

    shops[4]={
        "Wanderer",
        "You meet a strange swordsman training under a blossoming cherry tree.\nHe stares over the horizon and soliloquizes for a few minutes before\nunrolling a package of exotic gear.\n",
        "'Here, these are weapons and items from my homeland.'\n",
        "He ignores you, looking out into the distance.\n",
        "He nods, handing you the item and taking your coin.\n",
        "He makes no response as you leave, returning to his sword exercises.\n",
        4, 4};
    shops[4].ext_desc="a sombre stranger swinging a sword";
    shops[4].wares_id.push_back(getItemID("iron", "katana"));
    shops[4].wares_id.push_back(getItemID("cloth", "obi"));
    shops[4].wares_id.push_back(getItemID("straw", "hat"));

    shops[5]={
        "Trapper",
        "You approach the old hunter. He gives you a grizzled, slightly unhinged grin.\n",
        "'So you want to do some hunting, eh?'\n",
        "He scratches his head. 'What?'\n",
        "He nods, handing you the item and taking your coin.\n",
        "The fur-clad trapper claps you on the back. 'Best of luck to ye, friend!'\n",
        5, 5};
    shops[5].ext_desc="an old fur-clad huntsman";
    shops[5].wares_id.push_back(getItemID("none", "rope"));
    shops[5].wares_id.push_back(getItemID("none", "net"));
    shops[5].wares_id.push_back(getItemID("wooden", "shortbow"));
    shops[5].wares_id.push_back(getItemID("glass", "bottle"));

    shops[6]={
        "Gem Shop",
        "You approach the old jeweler.\n",
        "'Please, have a look. Only the finest here'\n",
        "He scratches his head. 'What?'\n",
        "He nods, handing you the item and taking your coin.\n",
        "The ancient Elf nods politely and returns to peering at an uncut stone.\n",
        9, 6};
    shops[6].ext_desc="an ancient, bespectacled Elf studying gems at a table";
    shops[6].wares_id.push_back(getItemID("golden", "ore"));
    shops[6].wares_id.push_back(getItemID("silver", "ore"));
    shops[6].wares_id.push_back(getItemID("none", "crystal"));
    shops[6].wares_id.push_back(getItemID("none", "sapphire"));
    shops[6].wares_id.push_back(getItemID("none", "emerald"));
    shops[6].wares_id.push_back(getItemID("none", "ruby"));
    shops[6].wares_id.push_back(getItemID("none", "amethyst"));
    shops[6].wares_id.push_back(getItemID("none", "diamond"));

    shops[7]={
        "Arykk's Arms",
        "You enter the shop through the open stone door, pushing aside the cloth covering.\n\nA barrel-chested Dwarf in full mail stands proudly amidst neatly\nordered racks of equipment, no doubt displaying his shop's finest on his person.\n",
        "Arykk gives you a broad grin. 'Go ahead, look around! You won't be disappointed.\n",
        "He scratches his head. 'What?'\n",
        "He nods, handing you the item and taking your coin.\n",
        "The affluent shopkeep waves heartily as you leave.\n'Please, come again sometime!\n",
        5, 7};
    shops[7].ext_desc="an impressive stone storefront bearing the sign\n    'Arykk's Arms' in Dwarven runes" ;
    shops[7].wares_id.push_back(getItemID("dwarven", "broad-axe"));
    shops[7].wares_id.push_back(getItemID("dwarven", "mail"));
    shops[7].wares_id.push_back(getItemID("dwarven", "helm"));
    shops[7].wares_id.push_back(getItemID("steel", "small shield"));

    shops[8]={
        "Mountain's Mourning",
        "The light inside the cavern is dim, cast weakly from a small oil lamp atop a nearby crate.\nA slow, rhythmic clanging leads you to a lone miner, swinging his pickaxe in the shallow gloom.\nHe looks up as you approach, deep, dark circles under his eyes belying his bored expression.\n",
        "'Care...to buy any ores?'\n",
        "He lets out a long sigh, just long enough to become uncomfortable.\n",
        "He nods, handing you the item and taking your coin.\n'Thank you...'\n",
        "For the first time since you entered, his pick pauses mid-swing.\n'Remember...to listen to the metal.'\n",
        7, 8};
    shops[8].ext_desc="a banner over a cave entrance reads 'Mountain's Mourning'" ;
    shops[8].wares_id.push_back(getItemID("stone", "block"));
    shops[8].wares_id.push_back(getItemID("iron", "ore"));
    shops[8].wares_id.push_back(getItemID("steel", "bar"));
    shops[8].wares_id.push_back(getItemID("iridium", "ore"));
    shops[8].wares_id.push_back(getItemID("silver", "ore"));
    shops[8].wares_id.push_back(getItemID("golden", "ore"));
}


#endif // TSF_BUILDINGS_H_INCLUDED
