#ifndef TSF_SAVE_LOAD_H_INCLUDED
#define TSF_SAVE_LOAD_H_INCLUDED

#include "tsf_classes.h"
#include "tsf_functions.h"

#include "serialization.h"

utils::datafile game_state;

void saveGameState()
{
auto& player = game_state["player"];
player["name"].SetString(pc.name);
player["race"].SetString(pc.race);
player["class"].SetString(pc.clas);
player["level"].SetInt(pc.lvl);
player["XP"].SetInt(pc.xp);
player["XP_next"].SetInt(pc.xpnxt);
player["HP"].SetInt(pc.hp);
player["HP_max"].SetInt(pc.hpmax);
player["MP"].SetInt(pc.mp);
player["MP_max"].SetInt(pc.mpmax);
player["attack"].SetInt(pc.atk);
player["defense"].SetInt(pc.def);
player["strength"].SetInt(pc.str);
player["dexterity"].SetInt(pc.dex);
player["intellect"].SetInt(pc.intl);
player["luck"].SetInt(pc.lck);
player["karma"].SetInt(pc.karma);
player["gold"].SetInt(pc.gp);

//Survival/Crafting skills
//Tools - boolean saved as integer
player["fishing_rod"].SetInt(pc.frod);
player["bait"].SetInt(pc.bait);
player["hammer"].SetInt(pc.ham);
player["pickaxe"].SetInt(pc.pick);
player["chisel"].SetInt(pc.chis);
player["needle_thread"].SetInt(pc.need);
player["shears"].SetInt(pc.shears);
player["wc_axe"].SetInt(pc.axe);
player["tinderbox"].SetInt(pc.tbox);
player["sheath"].SetInt(pc.sheath);
//Skills
player["mining"].SetInt(pc.mlvl);
player["smithing"].SetInt(pc.smlvl);
player["carving"].SetInt(pc.clvl);
player["woodcutting"].SetInt(pc.wclvl);
player["firemaking"].SetInt(pc.fmlvl);
player["cooking"].SetInt(pc.cklvl);
player["hunting"].SetInt(pc.hlvl);
player["sewing"].SetInt(pc.swlvl);
player["enchanting"].SetInt(pc.enchlvl);
player["foraging"].SetInt(pc.frglvl);

//Character appearance
player["sex"].SetString(pc.sex);
player["age"].SetInt(pc.age);
player["height"].SetInt(pc.height);
player["weight"].SetInt(pc.wt);
player["body_build"].SetString(pc.build);
player["hair_color"].SetString(pc.hairc);
player["eye_color"].SetString(pc.eyec);
player["skin_color"].SetString(pc.skinc);
player["hand_tattoo"].SetString(pc.tat);
//Body object details
auto& body = player["body"];
body["head"]["condition"].SetString(pc.body.head.con);
body["head"]["detail"].SetString(pc.body.head.det);
body["right_arm"]["condition"].SetString(pc.body.r_arm.con);
body["right_arm"]["detail"].SetString(pc.body.r_arm.det);

//Worn Equipment
//Weapon
auto& weap = player["weapon"];
weap["name"].SetString(pc.weap.name);
weap["material"].SetString(pc.weap.mat);
weap["material_bonus"].SetInt(pc.weap.matb);
weap["type"].SetString(pc.weap.type);
weap["subtype"].SetString(pc.weap.subt);
weap["enchantment"].SetString(pc.weap.ench);
weap["ench_bonus"].SetInt(pc.weap.enchb);
weap["attack_bonus"].SetInt(pc.weap.atkb);
weap["defense_bonus"].SetInt(pc.weap.defb);
weap["strength_bonus"].SetInt(pc.weap.strb);
weap["dexterity_bonus"].SetInt(pc.weap.dxb);
weap["intellect_bonus"].SetInt(pc.weap.intb);
weap["luck_bonus"].SetInt(pc.weap.lckb);
weap["weight"].SetInt(pc.weap.wt);
weap["price"].SetInt(pc.weap.price);
weap["item_id"].SetInt(pc.weap.id);
//Armor
auto& arm = player["armor"];
arm["name"].SetString(pc.arm.name);
arm["material"].SetString(pc.arm.mat);
arm["material_bonus"].SetInt(pc.arm.matb);
arm["type"].SetString(pc.arm.type);
arm["subtype"].SetString(pc.arm.subt);
arm["enchantment"].SetString(pc.arm.ench);
arm["ench_bonus"].SetInt(pc.arm.enchb);
arm["attack_bonus"].SetInt(pc.arm.atkb);
arm["defense_bonus"].SetInt(pc.arm.defb);
arm["strength_bonus"].SetInt(pc.arm.strb);
arm["dexterity_bonus"].SetInt(pc.arm.dxb);
arm["intellect_bonus"].SetInt(pc.arm.intb);
arm["luck_bonus"].SetInt(pc.arm.lckb);
arm["weight"].SetInt(pc.arm.wt);
arm["price"].SetInt(pc.arm.price);
arm["item_id"].SetInt(pc.arm.id);
//Accessory
auto& acc = player["accessory"];
acc["name"].SetString(pc.acc.name);
acc["material"].SetString(pc.acc.mat);
acc["material_bonus"].SetInt(pc.acc.matb);
acc["type"].SetString(pc.acc.type);
acc["subtype"].SetString(pc.acc.subt);
acc["enchantment"].SetString(pc.acc.ench);
acc["ench_bonus"].SetInt(pc.acc.enchb);
acc["attack_bonus"].SetInt(pc.acc.atkb);
acc["defense_bonus"].SetInt(pc.acc.defb);
acc["strength_bonus"].SetInt(pc.acc.strb);
acc["dexterity_bonus"].SetInt(pc.acc.dxb);
acc["intellect_bonus"].SetInt(pc.acc.intb);
acc["luck_bonus"].SetInt(pc.acc.lckb);
acc["weight"].SetInt(pc.acc.wt);
acc["price"].SetInt(pc.acc.price);
acc["item_id"].SetInt(pc.acc.id);

//Inventory
string node_name;
for(int x=1;x<11;x++)
{
    string node_num=to_string(x);
    node_name="inventory_"+node_num;
    auto& inv = player[node_name];

inv["name"].SetString(pc.inv[x].name);
inv["material"].SetString(pc.inv[x].mat);
inv["material_bonus"].SetInt(pc.inv[x].matb);
inv["type"].SetString(pc.inv[x].type);
inv["subtype"].SetString(pc.inv[x].subt);
inv["enchantment"].SetString(pc.inv[x].ench);
inv["ench_bonus"].SetInt(pc.inv[x].enchb);
inv["attack_bonus"].SetInt(pc.inv[x].atkb);
inv["defense_bonus"].SetInt(pc.inv[x].defb);
inv["strength_bonus"].SetInt(pc.inv[x].strb);
inv["dexterity_bonus"].SetInt(pc.inv[x].dxb);
inv["intellect_bonus"].SetInt(pc.inv[x].intb);
inv["luck_bonus"].SetInt(pc.inv[x].lckb);
inv["weight"].SetInt(pc.inv[x].wt);
inv["price"].SetInt(pc.inv[x].price);
inv["item_id"].SetInt(pc.inv[x].id);
}

//Save quest levels
for(int x=0;x<18;x++)
{
    auto& quest = game_state["quest"][qlog[x].name];
    quest.SetInt(qlog[x].lvl);
}

//Save spells
for(int x=0;x<69; x++)
{
    game_state["spell"][splist[x].name].SetInt(splist[x].unlock);
}

//Save current location data
player["location_x"].SetInt(pc.area.x);
player["location_y"].SetInt(pc.area.y);

//Exploration data
for(int x=1;x<11;x++)
{
    for(int y=1; y<11; y++)
    {
        game_state[loc[x][y].name+"_visits"].SetInt(loc[x][y].visits);
    }
}

//Game settings
auto& sets = game_state["settings"];
sets["sound"].SetInt(game_settings.sound);
sets["display_type"].SetInt(game_settings.display_type);
sets["player_color_1"].SetInt(game_settings.pcol_1);
sets["player_color_2"].SetInt(game_settings.pcol_2);
sets["main_text_color"].SetInt(game_settings.mtcol);
sets["s_dsp_type"].SetString(game_settings.s_dsp_type);
sets["combat_display"].SetString(game_settings.combat_display);
sets["status_display"].SetString(game_settings.status_display);

//Side quest data
game_state["lost_in_party"].SetInt(m_data.lost_in_party);
game_state["lost_x"].SetInt(m_data.lostx);
game_state["lost_y"].SetInt(m_data.losty);
game_state["fairy_missive"].SetInt(pc.fairy_missive);
game_state["fairy_location"].SetString(m_data.fairy_loc);
game_state["ferry_open"].SetInt(m_data.ferry);
game_state["bridge_open"].SetInt(m_data.bridge);

//Save companion stats
//General
auto& comp = player["companion"];
comp["name"].SetString(pc.comp.name);
comp["race"].SetString(pc.comp.race);
comp["class"].SetString(pc.comp.clas);
comp["attitude"].SetString(pc.comp.ai);
comp["level"].SetInt(pc.comp.lvl);
comp["XP"].SetInt(pc.comp.xp);
comp["XP_next"].SetInt(pc.comp.xpnxt);
comp["HP"].SetInt(pc.comp.hp);
comp["HP_max"].SetInt(pc.comp.hpmax);
comp["MP"].SetInt(pc.comp.mp);
comp["MP_max"].SetInt(pc.comp.mpmax);
comp["attack"].SetInt(pc.comp.atk);
comp["defense"].SetInt(pc.comp.def);
comp["strength"].SetInt(pc.comp.str);
comp["dexterity"].SetInt(pc.comp.dex);
comp["intellect"].SetInt(pc.comp.intl);

//Companion equipment
//Weapon
auto& c_weap = comp["weapon"];

c_weap["name"].SetString(pc.comp.weap.name);
c_weap["material"].SetString(pc.comp.weap.mat);
c_weap["material_bonus"].SetInt(pc.comp.weap.matb);
c_weap["type"].SetString(pc.comp.weap.type);
c_weap["subtype"].SetString(pc.comp.weap.subt);
c_weap["enchantment"].SetString(pc.comp.weap.ench);
c_weap["ench_bonus"].SetInt(pc.comp.weap.enchb);
c_weap["attack_bonus"].SetInt(pc.comp.weap.atkb);
c_weap["defense_bonus"].SetInt(pc.comp.weap.defb);
c_weap["strength_bonus"].SetInt(pc.comp.weap.strb);
c_weap["dexterity_bonus"].SetInt(pc.comp.weap.dxb);
c_weap["intellect_bonus"].SetInt(pc.comp.weap.intb);
c_weap["luck_bonus"].SetInt(pc.comp.weap.lckb);
c_weap["weight"].SetInt(pc.comp.weap.wt);
c_weap["price"].SetInt(pc.comp.weap.price);
c_weap["item_id"].SetInt(pc.comp.weap.id);

auto& c_arm = comp["armor"];

c_arm["name"].SetString(pc.comp.arm.name);
c_arm["material"].SetString(pc.comp.arm.mat);
c_arm["material_bonus"].SetInt(pc.comp.arm.matb);
c_arm["type"].SetString(pc.comp.arm.type);
c_arm["subtype"].SetString(pc.comp.arm.subt);
c_arm["enchantment"].SetString(pc.comp.arm.ench);
c_arm["ench_bonus"].SetInt(pc.comp.arm.enchb);
c_arm["attack_bonus"].SetInt(pc.comp.arm.atkb);
c_arm["defense_bonus"].SetInt(pc.comp.arm.defb);
c_arm["strength_bonus"].SetInt(pc.comp.arm.strb);
c_arm["dexterity_bonus"].SetInt(pc.comp.arm.dxb);
c_arm["intellect_bonus"].SetInt(pc.comp.arm.intb);
c_arm["luck_bonus"].SetInt(pc.comp.arm.lckb);
c_arm["weight"].SetInt(pc.comp.arm.wt);
c_arm["price"].SetInt(pc.comp.arm.price);
c_arm["item_id"].SetInt(pc.comp.arm.id);

auto& c_acc = comp["accessory"];

c_acc["name"].SetString(pc.comp.acc.name);
c_acc["material"].SetString(pc.comp.acc.mat);
c_acc["material_bonus"].SetInt(pc.comp.acc.matb);
c_acc["type"].SetString(pc.comp.acc.type);
c_acc["subtype"].SetString(pc.comp.acc.subt);
c_acc["enchantment"].SetString(pc.comp.acc.ench);
c_acc["ench_bonus"].SetInt(pc.comp.acc.enchb);
c_acc["attack_bonus"].SetInt(pc.comp.acc.atkb);
c_acc["defense_bonus"].SetInt(pc.comp.acc.defb);
c_acc["strength_bonus"].SetInt(pc.comp.acc.strb);
c_acc["dexterity_bonus"].SetInt(pc.comp.acc.dxb);
c_acc["intellect_bonus"].SetInt(pc.comp.acc.intb);
c_acc["luck_bonus"].SetInt(pc.comp.acc.lckb);
c_acc["weight"].SetInt(pc.comp.acc.wt);
c_acc["price"].SetInt(pc.comp.acc.price);
c_acc["item_id"].SetInt(pc.comp.acc.id);

auto& c_inv = comp["inventory"];

c_inv["name"].SetString(pc.comp.inv.name);
c_inv["material"].SetString(pc.comp.inv.mat);
c_inv["material_bonus"].SetInt(pc.comp.inv.matb);
c_inv["type"].SetString(pc.comp.inv.type);
c_inv["subtype"].SetString(pc.comp.inv.subt);
c_inv["enchantment"].SetString(pc.comp.inv.ench);
c_inv["ench_bonus"].SetInt(pc.comp.inv.enchb);
c_inv["attack_bonus"].SetInt(pc.comp.inv.atkb);
c_inv["defense_bonus"].SetInt(pc.comp.inv.defb);
c_inv["strength_bonus"].SetInt(pc.comp.inv.strb);
c_inv["dexterity_bonus"].SetInt(pc.comp.inv.dxb);
c_inv["intellect_bonus"].SetInt(pc.comp.inv.intb);
c_inv["luck_bonus"].SetInt(pc.comp.inv.lckb);
c_inv["weight"].SetInt(pc.comp.inv.wt);
c_inv["price"].SetInt(pc.comp.inv.price);
c_inv["item_id"].SetInt(pc.comp.inv.id);
}

void writeState()
{
    string sname;
    ofstream save;
    ofstream recent_saves;

    //get date and time for saves
    time_t now = time(0);
    char* dt = ctime(&now);

    cout<<"Name your save file: ";
    cin>>sname;

    //add save file name to list for recent load
    recent_saves.open("recent_saves.txt", std::ios::app);
    if(!recent_saves.is_open()){cout<<"File error: could not load recent saves.\n";}
    recent_saves<<sname<<" - "<<dt;
    recent_saves.close();
    if(recent_saves.is_open()){cout<<"File error: could not close recent saves.\n";}

    sname+=".txt";
    saveGameState();
    game_state.Write(game_state, sname);
}

/*--------> pc.name = game_state["player"]["name"]


void gameSetState(utils::datafile& n)
{
    //Reading and parsing stats from datafile
    //Load character

    auto& player = n["player"];
    pc.name = player["name"].SetString(pc.name);
pc.race = player["race"].SetString(pc.race);
pc.clas = player["class"].SetString(pc.clas);
pc.lvl = player["level"].SetInt(pc.lvl);
pc.xp = player["XP"].SetInt(pc.xp);
pc.xpnxt = player["XP_next"].SetInt(pc.xpnxt);
pc.hp = player["HP"].SetInt(pc.hp);
pc.hpmax = player["HP_max"].SetInt(pc.hpmax);
pc.mp = player["MP"].SetInt(pc.mp);
pc.mpmax = player["MP_max"].SetInt(pc.mpmax);
pc.atk = player["attack"].SetInt(pc.atk);
pc.def = player["defense"].SetInt(pc.def);
pc.str = player["strength"].SetInt(pc.str);
pc.dex = player["dexterity"].SetInt(pc.dex);
pc.intl = player["intellect"].SetInt(pc.intl);
pc.lck = player["luck"].SetInt(pc.lck);
pc.karma = player["karma"].SetInt(pc.karma);
pc.gp = player["gold"].SetInt(pc.gp);

//Survival/Crafting skills
//Tools - boolean saved as integer
pc.frod = player["fishing_rod"].SetInt(pc.frod);
pc.bait = player["bait"].SetInt(pc.bait);
pc.ham = player["hammer"].SetInt(pc.ham);
pc.pick = player["pickaxe"].SetInt(pc.pick);
pc.chis = player["chisel"].SetInt(pc.chis);
pc.need = player["needle_thread"].SetInt(pc.need);
pc.shears = player["shears"].SetInt(pc.shears);
pc.axe = player["wc_axe"].SetInt(pc.axe);
pc.tbox = player["tinderbox"].SetInt(pc.tbox);
pc.sheath = player["sheath"].SetInt(pc.sheath);
//Skills
pc.mlvl = player["mining"].SetInt(pc.mlvl);
pc.smlvl = player["smithing"].SetInt(pc.smlvl);
pc.clvl = player["carving"].SetInt(pc.clvl);
pc.wc = player["woodcutting"].SetInt(pc.wclvl);
pc.fm = player["firemaking"].SetInt(pc.fmlvl);
pc.cklvl = player["cooking"].SetInt(pc.cklvl);
pc.hlvl = player["hunting"].SetInt(pc.hlvl);
pc.swlvl = player["sewing"].SetInt(pc.swlvl);
pc.enchlvl = player["enchanting"].SetInt(pc.enchlvl);
pc.frglvl = player["foraging"].SetInt(pc.frglvl);

//Character appearance
pc.sex = player["sex"].SetString(pc.sex);
pc.age = player["age"].SetInt(pc.age);
pc.height = player["height"].SetInt(pc.height);
pc.wt = player["weight"].SetInt(pc.wt);
pc.build = player["body_build"].SetString(pc.build);
pc.hairc = player["hair_color"].SetString(pc.hairc);
pc.eyec = player["eye_color"].SetString(pc.eyec);
pc.skinc = player["skin_color"].SetString(pc.skinc);
pc.tat = player["hand_tattoo"].SetString(pc.tat);
//Body object details
auto& body = player["body"];
pc.body.head.cond = body["head"]["condition"]
body["head"]["detail"]
body["right_arm"]["condition"]
body["right_arm"]["detail"]

//Worn Equipment
//Weapon
auto& weap = player["weapon"];
pc.weap.name = weap["name"].SetString(pc.weap.name);
pc.weap.mat = weap["material"].SetString(pc.weap.mat);
pc.weap.matb = weap["material_bonus"].SetInt(pc.weap.matb);
pc.weap.type = weap["type"].SetString(pc.weap.type);
pc.weap.subt = weap["subtype"].SetString(pc.weap.subt);
pc.weap.ench = weap["enchantment"].SetString(pc.weap.ench);
pc.weap.enchb = weap["ench_bonus"].SetInt(pc.weap.enchb);
pc.weap.atkb = weap["attack_bonus"].SetInt(pc.weap.atkb);
pc.weap.defb = weap["defense_bonus"].SetInt(pc.weap.defb);
pc.weap.strb = weap["strength_bonus"].SetInt(pc.weap.strb);
pc.weap.dexb = weap["dexterity_bonus"].SetInt(pc.weap.dxb);
pc.weap.intlb = weap["intellect_bonus"].SetInt(pc.weap.intb);
pc.weap.lckb = weap["luck_bonus"].SetInt(pc.weap.lckb);
pc.weap.wt = weap["weight"].SetInt(pc.weap.wt);
pc.weap.price = weap["price"].SetInt(pc.weap.price);
pc.weap.id = weap["item_id"].SetInt(pc.weap.id);
//Armor
auto& arm = player["armor"];

//Accessory
auto& acc = player["accessory"];


//Inventory
string node_name;
for(int x=1;x<11;x++)
{
    string node_num=to_string(x);
    node_name="inventory_"+node_num;
    auto& inv = player[node_name];

inv["name"].SetString(pc.inv[x].name);
inv["material"].SetString(pc.inv[x].mat);
inv["material_bonus"].SetInt(pc.inv[x].matb);
inv["type"].SetString(pc.inv[x].type);
inv["subtype"].SetString(pc.inv[x].subt);
inv["enchantment"].SetString(pc.inv[x].ench);
inv["ench_bonus"].SetInt(pc.inv[x].enchb);
inv["attack_bonus"].SetInt(pc.inv[x].atkb);
inv["defense_bonus"].SetInt(pc.inv[x].defb);
inv["strength_bonus"].SetInt(pc.inv[x].strb);
inv["dexterity_bonus"].SetInt(pc.inv[x].dxb);
inv["intellect_bonus"].SetInt(pc.inv[x].intb);
inv["luck_bonus"].SetInt(pc.inv[x].lckb);
inv["weight"].SetInt(pc.inv[x].wt);
inv["price"].SetInt(pc.inv[x].price);
inv["item_id"].SetInt(pc.inv[x].id);
}
}*/

void loadState()
{
    string loadn;
    string itname;
    string recent, str;
    vector<string> saves_in_reverse;
    ifstream load;
    ifstream open_saves;

    //display the three most recent saves
    //if there are fewer than three saves, it will show only what there is
    //A good chunk of this is courtesy of ChatGPT. Stay humble.
    open_saves.open("recent_saves.txt");
    if(!open_saves.is_open()){cout<<"Error loading file!\n"; return;}

    cout<<"\nRecent:\n";
    while(getline(open_saves, str)){
            saves_in_reverse.insert(saves_in_reverse.begin(), str);
            if (open_saves.eof()) {
            break;}}
    for(int x=0; x<(saves_in_reverse.size() < 3 ? saves_in_reverse.size() : 3); x++){
            cout<<"("<<x<<") "<<saves_in_reverse[x]<<"\n";}
    open_saves.close();
    if (open_saves.is_open()) {cout << "Error closing file!" << endl;}


    cout<<"\nEnter the name of the save you wish to load: ";
    cin>>loadn;
    loadn+=".txt";
    game_state.Read(game_state, loadn);
}
#endif // TSF_SAVE_LOAD_H_INCLUDED
