#include "tsf_functions.h"

using namespace std;

int liars_dice()
{
    string turn="player";
	string input;
	int pbet, obet, pot, count, dnum, guess, pcash, ocash, dif;
	int phand[5], ohand[5];
	string pname, oname;
	string onopt[5]={"Ragh", "Taka", "Eirmen", "Kerus", "Imal"};

	srand(time(NULL));

	cout<<"You approach the table. The soldiers greet you drunkenly, inviting you to join their game.\n\n";
	//main menu
	do
	{
	    pcash=100; ocash=100;
	    cout<<"What would you like to do?\n";
	    cout<<"(1) New game\n(2) Leave the table\n";
	    input="0";
	    cin>>input;
	    if(input=="1")
	    {
	        if(pcash<=0)
	        {
	            cout<<"You've gone bust! "<<oname<<" wins!\n";
	            break;
	        }
	        if(ocash<=0)
	        {
	            cout<<oname<<" went bust! You win!\n";
	            break;
	        }
	        oname=onopt[rand()%5];
	        pot=0;
	        cout<<"\nNEW GAME\n\n";
	        cout<<"The chips are stacked and distributed evenly.\n";
	        cout<<"Your opponent this time is "<<oname<<".\n";
	        do{
                cout<<turn<<" turn -\n";
	            cout<<"Player tokens: "<<pcash<<";   Opponent tokens: "<<ocash<<"\n";
	            cout<<"(1) Next round\n(2) Return to main menu\n";
	            cin>>input;
	            if(input=="1")
	            {
	                cout<<"Your dice are: ";
	                for (int x=0;x<5;x++)
	                {
	                    phand[x]=rand()%6+1;
	                    ohand[x]=rand()%6+1;
	                    cout<<phand[x]<<" ";
	                }
	                //bets
	                cout<<"\nEnter your bet:\n";
	                do{
	                    pbet=check_int();
	                    if(pbet>pcash) cout<<"Enter a number less than your total tokens.\n";
	                }while(pbet>pcash);
	                obet=rand()%ocash;
	                pot=pbet+obet;
	                cout<<"Your opponent bets "<<obet<<", bringing the pot total to "<<pot<<".\n";

	                //player turn
	                if(turn=="player")
	                {
	                    cout<<"Enter a die value to bet on (1-6):\n";
	                    do{
	                        dnum=check_int();
	                        if(dnum>6||dnum<1) cout<<"Please enter a number between 1 and 6\n";
	                    }while(dnum>6||dnum<1);
	                    cout<<"Enter a number of dice to bet on (1-10):\n";
	                    guess=check_int();
	                    turn="opponent";
	                }

	                //opponent turn
	                else if(turn=="opponent")
	                {
	                    dnum=rand()%6+1;
	                    guess=rand()%10;
	                    cout<<oname<<" guessed there would be "<<guess<<" "<<dnum<<"'s.\n";
	                    turn="player";
	                }

	                for(int x=0;x<5;x++)
	                {
	                    if(phand[x]==guess) count++;
	                     if(ohand[x]==guess) count++;
	                }
	                dif=guess-count;
	                if(count==guess)
	                {
	                    if(turn=="opponent")
	                    {
	                        cout<<"You were exactly right! A winner is you.\nYou won "<<pot<<" tokens!\n";
	                        pcash-=pbet;
	                        pcash+=pot;
	                        pot=0;
	                    }
	                    else
	                    {
	                        cout<<oname<<" was exactly right, and won "<<pot<<" tokens!\n";
	                        ocash-=obet;
	                        ocash+=pot;
	                        pot=0;
	                    }
	                }
	                else{ cout<<"That guess was off by "<<dif<<". Nobody wins! Tokens returned.\n";}
	            }
	            else if(input=="2")
	                cout<<"Returning to main menu.\n";
	            else cout<<"Sorry, I don't understand.\n";
	        }while(input!="2");
	        input="0";
	        }
	    else if(input=="2")
	    {
	        cout<<"See you later.\n";
	    }
	    else
	    {
	        cout<<"Sorry, please try again.\n";
	    }
	} while(input!="2");
	return 0;
}
