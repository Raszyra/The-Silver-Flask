#ifndef SERIALIZATION_H_INCLUDED
#define SERIALIZATION_H_INCLUDED

#include <iostream>
#include <sstream>
#include <fstream>
#include <unordered_map>
#include <string>
#include <functional>
#include <stack>
#include <vector>

/*
+===================+
|>--Serialization--<|
+===================+

This program creates a multilevel
data structure, of proprietary type "datafile",
that can be filled with an unknown number of
variables of any type, each with its own string label -

EX: datafile["name"]["Will Hooker"]; || df["name"].SetString("Will Hooker");

This data structure can be searched dynamically,
ordered, and written to a file in a human-readable
format.
*/

namespace utils
{
    class datafile
    {
    public:

        inline void SetString(const std::string& sString, const size_t nItem=0)
        {
            if(nItem>=m_vContent.size())
                m_vContent.resize(nItem+1);

            m_vContent[nItem]=sString;
        }

        inline const std::string GetString(const size_t nItem) const
        {
            if(nItem>=m_vContent.size())
                return "";
            else
                return m_vContent[nItem];
        }

        inline void SetReal(const double d, const size_t nItem=0)
        {
            SetString(std::to_string(d), nItem);
        }
        inline const double GetReal(const size_t nItem=0)
        {
            return std::atof(GetString(nItem).c_str());
        }

        inline void SetInt (const int32_t n, const size_t nItem=0)
        {
            SetString(std::to_string(n), nItem);
        }
        inline const int32_t GetInt (const size_t nItem=0)
        {
            return std::atoi(GetString(nItem).c_str());
        }

        inline size_t GetValueCount() const
        {
            return m_vContent.size();
        }

        inline datafile& operator[](const std::string& name)
        {
            //Check if this node's map already contains an object of the same name
            if(m_mapObjects.count(name)==0)
            {
                //It did not, create this object in the map
                //Get a vector ID and link it with the name in the unordered_map
                m_mapObjects[name]=m_vecObjects.size();

                //Then create a new, blank object in the vector of objects
                m_vecObjects.push_back({name, datafile() });
            }
            //Object exists; return object by getting index from map and using index loop to find it
            return m_vecObjects[m_mapObjects[name]].second;
        }

        inline static bool Write(
            const datafile& n,
            const std::string& sFileName,
            const std::string& sIndent = "\t",
            const char sListSep = ',')
        {
            //cache separator string for convenience
            std::string sSeparator = std::string(1, sListSep) + " ";

            //cache indentation level
            size_t nIndentCount = 0;

            //Fully specified lambda function
            std::function<void(const datafile&, std::ofstream&)> write = [&](const datafile& n, std::ofstream& file)
            {
                //Lambda to create string given indentation preference
                auto indent = [&](const std::string& sString, const size_t nCount)
                {
                    std::string sOut;
                    for (size_t n = 0; n < nCount; n++) sOut += sString;
                    return sOut;
                };
                //Iterate through each property of this node
                for (auto const& property : n.m_vecObjects)
                {
                    //Does property contain any sub objects?
                    if(property.second.m_vecObjects.empty())
                    {
                        file << indent(sIndent, nIndentCount) << property.first << (property.second.m_bIsComment ? "" : " = ");

                        size_t nItems = property.second.GetValueCount();
                        for(size_t i = 0; i < property.second.GetValueCount(); i++)
                        {
                            size_t x = property.second.GetString(i).find_first_of(sListSep);
                            if(x!= std::string::npos)
                            {
                                //Value contains separator token, wrap in quotes
                                file<< "\"" <<property.second.GetString(i) << "\"" <<((nItems > 1) ? sSeparator : "");
                            }
                            else
                            {
                                file<< property.second.GetString(i) << ((nItems > 1) ? sSeparator : "");
                            }

                            nItems--;
                        }
                        //Property written, move to next line
                        file << "\n";
                    }
                    else
                    {
                        //Yes, property has properties of its own, so it's a node
                        //Force a new line and write out the node's name
                        file << "\n" << indent(sIndent, nIndentCount) << property.first << "\n";
                        //Open braces, update indentation
                        file << indent(sIndent, nIndentCount) << "{\n";
                        nIndentCount++;
                        //Recursively write that node
                        write(property.second, file);
                        //Node written, close braces
                        file << indent(sIndent, nIndentCount) << "}\n\n";
                    }
                }

                //Here, we've finished writing out a node, so decrease indentation unless at top level
                if (nIndentCount > 0) nIndentCount--;
            };

            std::ofstream file(sFileName);
            if(file.is_open())
            {
                write(n, file);
                return true;
            }

            return false;
        }

        inline static bool Read(
            datafile& n,
            const std::string sFileName,
            const char sListSep = ',')
        {
            //Open File
            std::ifstream file(sFileName);

            if(file.is_open())
            {
                //These variables are outside of the read loop as we will
                //need to refer to previous iteration values in certain conditions
                std::string sPropName = "";
                std::string sPropValue = "";

                std::stack<std::reference_wrapper<datafile>> stkPath;
                stkPath.push(n);

                while(!file.eof())
                {
                    std::string line;
                    std::getline(file, line);

                    //This function removes whitespace
                    //Check for reference to parsing other files as needed (?)
                    auto trim = [](std::string& s)
                    {
                        s.erase(0, s.find_first_not_of(" \t\n\r\f\v"));
                        s.erase(s.find_last_not_of(" \t\n\r\f\v") + 1);
                    };
                    trim(line);

                    //Check if line has content
                    if(!line.empty())
                    {
                        if(line[0] == '#')
                        {
                            //Line is comment, so ignore
                            datafile comment;
                            comment.m_bIsComment = true;
                            stkPath.top().get().m_vecObjects.push_back({ line, comment});
                        }
                        else
                        {
                        //Content present, so parse, find if the line contains an assignment
                        //If it does, then it's a property.
                        size_t x = line.find_first_of('=');
                        if(x != std::string::npos)
                        {
                            //If property, split into name and value variables

                            //Extract the name, which is all characters up to first assignment
                            //Trim whitespace from ends
                            sPropName = line.substr(0, x);
                            trim(sPropName);

                            //Extract the property value, which is all characters after the
                            //assignment operator; trim whitespace
                            sPropValue = line.substr(x+1, line.size());
                            trim(sPropValue);

                            //Check character by character if the value is in quotes,
                            //regardless of position in the list (a, b, c, "d, e", f)
                            bool bInQuotes = false;
                            std::string sToken;
                            size_t nTokenCount = 0;
                            for(const auto c : sPropValue)
                            {
                                //Check if current character is a quote
                                if(c== '\"')
                                {
                                    //Toggle quote state
                                    bInQuotes = !bInQuotes;
                                }
                                else
                                {
                                    //Character is not a quotation, so proceed creating token
                                    //If in quote state just append characters until exit quote state
                                    if (bInQuotes)
                                    {
                                        sToken.append(1, c);
                                    }
                                    else
                                    {
                                        //Check if character is the separator
                                        if(c==sListSep)
                                        {
                                            //Clean up token, removing whitespace
                                            trim(sToken);
                                            //Add it to the vector of values for this property
                                            stkPath.top().get()[sPropName].SetString(sToken, nTokenCount);
                                            //Reset token state
                                            sToken.clear();
                                            nTokenCount++;
                                        }
                                        else
                                        {
                                            //Not the separator character, so just append to token
                                            sToken.append(1, c);
                                        }
                                    }
                                }
                            }

                            //Any residual characters at this point just make up the final token
                            //so clean it up and add it to the vector of values
                            if(!sToken.empty())
                            {
                                trim(sToken);
                                stkPath.top().get()[sPropName].SetString(sToken, nTokenCount);
                            }
                        }
                        else //Not an assignment, i.e., no ' = '
                        {
                            //If line begins with a curly brace
                            if (line[0] == '{')
                            {
                                //opening brace, push this node to stack
                                //Subsequent properties will belong to the new node
                                stkPath.push(stkPath.top().get()[sPropName]);
                            }
                            else
                            {
                                if (line[0] == '}')
                                {
                                    //Closing brace, so this node has been defined
                                    //Pop from stack
                                    stkPath.pop();
                                }
                                else
                                {
                                    //Line is a property with no assignment; no way of telling if it's
                                    //necessary, so just add it as a valueless property
                                    sPropName = line;
                                    //Actually, it is useful, as empty properties are typically
                                    //going to be the names of new datafile nodes on the next
                                    //iteration.
                                }
                            }
                        }
                    }
                    }

                }

                //Procedure is finished, close and exit
                file.close();
                return true;
            }

            //File not found or opened
            return false;
        }

        inline void addItems(datafile& n)
        {
            std::string name, data;
            std::cout<<"Enter the name of the new node, or an existing node.\n";
            std::cin>>name;
            std::cout<<"Enter the string data to add to node.\n";
            std::cin>>data;

            n[name].SetString(data);
        }

    private:

        std::vector<std::string> m_vContent;

        std::vector<std::pair<std::string, datafile>>  m_vecObjects;
        std::unordered_map<std::string, size_t> m_mapObjects;

    protected:
        //Used to identify if a property is a comment or not
        bool m_bIsComment = false;
    };
}

#endif // SERIALIZATION_H_INCLUDED
