#ifndef TABLE_H_INCLUDED
#define TABLE_H_INCLUDED

#include <iostream>
#include <vector>
#include <string>

using namespace std;

string s_Line(const int length, const char c_line)
    {
        string s_line;
        for(int c=0; c < length; ++c)
            s_line+=c_line;

        return s_line;
    }

void drawTable(string title, const vector<string>& data, int rows, int cols)
{
    if(data.size()!= rows * cols)
    {
        cout<<"\nError! Could not draw table!\n(Data size does not match the specified dimensions)\n\n";
        return;
    }

    //Generate table memory
    vector<vector<string>> table(rows, vector<string> (cols));

    //Populate table with given data
    int dataIndex = 0;
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            table[i][j] = data[dataIndex++];
        }
    }

    //Display the table in console
    cout << title << "\n";
    cout<<s_Line(20, '-');
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            cout << table[i][j] << " ";
        }
        cout << "\n";
    }
}





#endif // TABLE_H_INCLUDED
