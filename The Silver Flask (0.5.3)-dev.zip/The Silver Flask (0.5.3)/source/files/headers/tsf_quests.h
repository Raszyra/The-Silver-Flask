#pragma once

#ifndef TSF_QUESTS_H_INCLUDED
#define TSF_QUESTS_H_INCLUDED

#include "tsf_classes.h"
#include "tsf_functions.h"

using namespace std;

/*
<=====================>
|  IMPORTANT NOTE:    |
<=====================>

-----> The LAST STEP in each quest is the recursive one!!
-----> Subtract ONE for NPC dialogue because "info" starts at 0!!
-----> So for EXAMPLE:

        qlog[x]={"example quest", 0, 5, 10, 10, x}

        The LAST STEP in this example is nlist[x].info[4]

*/

void define_quests()
{
    //lvl, end, xpr, gpr, itr, id;

	qlog[0]={"Arana's Firewood", 0, 4, 10, 10, 0, 1, false, false};
	qlog[0].req[3]=49;
	qlog[0].desc[1]="-Talk to Arana in your Village\n";
	qlog[0].desc[2]="-Talk to Arana in your Village\n";
	qlog[0].desc[3]="-Bring 1 wood to Arana in your Village\n";

	qlog[1]={"Lending a Farm Hand", 0, 7, 15, 20, 0, 2, false, false};
	qlog[1].req[2]=36;
	qlog[1].req[4]=99;
	qlog[1].req[6]=99;
	qlog[1].desc[1]="-Talk to Farmer at the Windmill\n";
	qlog[1].desc[2]="-Shear the flock north of the Windmill\n";
	qlog[1].desc[3]="-Talk to the Farmer\n";
	qlog[1].desc[4]="-Kill a wolf to scare off the pack\n";
	qlog[1].desc[5]="-Talk to the Farmer\n";
	qlog[1].desc[6]="-Sow the seeds on the western Farmland, then\ntalk to the Farmer\n";

	qlog[2]={"The Healer's Dilemma", 0, 3, 15, 10, 0, 3, false, false};
	qlog[2].req[1]=getItemID("none", "medicinal herb");
	qlog[2].desc[1]="-Find a medicinal herb in the forest\n";
	qlog[2].desc[2]=qlog[2].desc[1];

	qlog[3]={"Naked and A-freezing", 0, 5, 15, 20, 0, 4, false, false};
	qlog[3].req[2]=1;
	qlog[3].req[3]=1;
	qlog[3].req[4]=1;
	qlog[3].desc[1]="-Use a needle & thread and wool to sew 3 tunics.\n";
	qlog[3].desc[2]=qlog[2].desc[1];
	qlog[3].desc[3]=qlog[2].desc[1];
	qlog[3].desc[4]=qlog[2].desc[1];

	qlog[4]={"The Sound of Music", 0, 2, 5, 10, 0, 5, false, false};
	qlog[4].req[1]=294;
	qlog[4].desc[1]="-Raise your carving level enough to fix a flute.\n";

	qlog[5]={"Over Troubled Waters", 0, 8, 40, 25, 0, 6, false, false};
	int y;
	for(int x=3;x<8;x++)
	{
		qlog[5].req[x]=66;
	};
	for(y=3;y<8;y++)
	{
		qlog[5].desc[y]="-Bring another stone block to Mason the mason.\n";
	};

	qlog[6]={"Yours, Mine, & Hours", 0, 9, 40, 50, 0, 7, false, false};
	qlog[6].req[3]=48;
	qlog[6].req[4]=45;
	qlog[6].req[5]=54;
	qlog[6].req[6]=55;
	qlog[6].req[7]=46;
	qlog[6].req[8]=47;
	qlog[6].desc[3]="-Mine some iron for D'tuum the dwarf.\n";
	qlog[6].desc[4]="-Mine some coal for D'tuum the dwarf.\n";
	qlog[6].desc[5]="-Mine some silver for D'tuum the dwarf.\n";
	qlog[6].desc[6]="-Mine some gold for D'tuum the dwarf.\n";
	qlog[6].desc[7]="-Mine some crystal for D'tuum the dwarf.\n";
	qlog[6].desc[8]="-Mine some diamond for D'tuum the dwarf.\n";

	qlog[7]={"Droppin' the Bucket", 0, 2, 10, 10, 0, 7, false, false};
	qlog[7].req[1]=getItemID("wooden", "bucket");
	qlog[7].desc[1]="-Find a wooden bucket for the Ferryman.\n";

	qlog[8]={"Shaman's Intuition", 0, 4, 10, 50, 0, 8, false, false};
	qlog[8].req[3]=294;//Token of Unobtaining
	qlog[8].desc[1]="-see what the Goblin Shaman needs from you\n";
	qlog[8].desc[2]="-see what the Goblin Shaman needs from you\n";
	qlog[8].desc[3]="-use the foul torch to burn out the Vampsect nest\n";
	qlog[8].desc[4]="-return to the Shaman to report your success\n";

	qlog[9]={"Hammer & Sick Leave", 0, 5, 25, 75, 0, 9};
	qlog[9].req[2]=getItemID("iron", "dagger");
	qlog[9].req[3]=getItemID("steel", "bar");
	qlog[9].req[4]=getItemID("steel", "chainmail");
	qlog[9].desc[2]="-Smith an iron dagger for John the Smith\n";
	qlog[9].desc[3]="-Smith a steel bar for John the Smith\n";
	qlog[9].desc[4]="-Smith a set of steel chainmail for John the Smith\n";


	qlog[10]={"Piercing the Darkness", 0, 7, 20, 100, 0, 9, false, false};
	qlog[10].req[1]=294;//token of unobtaining
	qlog[10].desc[1]="-Kill 10 Dark Knights or Dark Paladins for Knight Commander Gareth\n";
	for(int x=2;x<7;x++){qlog[9].desc[x]="-Finish the Litany of the Paladin to join the Guild.\n";}

	qlog[11]={"The Cursed Chalice", 0, 5, 50, 30, 0, 11, false, false};
	qlog[11].req[1]=295;//paladin crest
	qlog[11].req[4]=297;//cursed chalice
	qlog[11].desc[1]="-Talk to Knight Commander Gareth about joining the Paladins\n";
	qlog[11].desc[3]="-Retrieve the Cursed Chalice from the Dark Knights'\nkeep in the northeast.\n";

	qlog[12]={"Person of Interest", 0, 2, 20, 100, 0, 12};
	qlog[12].req[1]=294;//token of unobtaining
	qlog[12].desc[1]="-Poison Knight Commander Gareth for Valencia. He can be found in the Grand Hall.\n";

	qlog[13]={"Strictly Business", 0, 3, 20, 250, 0, 13};
	qlog[13].req[1]=210;//slayer coin
	qlog[13].req[2]=294;//token of unobtaining
	qlog[13].desc[1]="-Talk to Valencia about joining the Assassins' Guild\n";
	qlog[13].desc[2]="-Kill 10 bandits and return to Hakon\n";

	qlog[14]={"A Ritual Most Profane", 0, 7, 100, 75, 0, 14};
    qlog[14].req[2]=70;//feather
    qlog[14].req[3]=3;//iron dagger
    qlog[14].req[4]=52;//ruby
    qlog[14].req[5]=75;//molten core
    qlog[14].desc[2]="-see what the Goblin Shaman needs from you\n";
	qlog[14].desc[3]="-see what the Goblin Shaman needs from you\n";
	qlog[14].desc[4]="-use the foul torch to burn out the Vampsect nest\n";
	qlog[14].desc[5]="-return to the Shaman to report your success\n";

	qlog[15]={"Silencing the Source", 0, 3, 15, 75, 0, 15};
	qlog[15].req[1] = getItemID("brass", "Token of Unobtaining");
	qlog[15].desc[1]="-Hunt down a Crazed Arcanist for Azelfoff the wizard.\n";

	qlog[16]={"Cleansing Light", 0, 2, 15, 75, 0, 16};
	qlog[16].req[1]=294;//Token of Unobtaining
	qlog[16].desc[1]="-Help the people of Samlund for Brother Viri\n";

	qlog[17]={"Beacon of Hope", 0, 3, 15, 75, 0, 17};
	qlog[17].req[1]=209;//smooth stone
	qlog[17].req[2]=294;//token of unobtaining
	qlog[17].desc[1]="-Talk to Priestess Suni about what you can do for the temple\n";
	qlog[17].desc[2]="-Use the Sacred Torch to light the beacon in the cave to the northeast\n";
	qlog[17].desc[3]="-Return to the Priestess to report the deed is done\n";

	qlog[18]={"Teeth o' the Deep", 0, 3, 10, 50, 0, 18};
	qlog[18].desc[1]="-Venture out onto the lake and kill a Lake Serpent to protect the\n Fisherman's livelihood\n";

	qlog[19]={"Winter Festival", 0, 6, 15, 75, 0, 19};
	qlog[19].req[2]=getItemID("wooden", "dagger");
    qlog[19].req[3]=getItemID("redberry", "pie");
    qlog[19].req[4]=getItemID("cloth", "tunic");
	qlog[19].desc[1]="-Help the Mayor of Winterhold save the Winter Festival\n";
	qlog[19].desc[2]="-Bring the Mayor of Winterhold a wooden club\n";
    qlog[19].desc[3]="-Bring the Mayor of Winterhold a redberry pie\n";
    qlog[19].desc[4]="-Bring the Mayor of Winterhold a cloth tunic\n";

	qlog[20]={"Herbal Remedy", 0, 5, 15, 75, 0, 20}; //Luz
	qlog[20].req[2]=getItemID("none", "medicinal herb");
    qlog[20].req[3]=getItemID("none", "snowflower");
    qlog[20].req[4]=getItemID("none", "torchweed");
	qlog[20].desc[2]="-Bring Luz a medicinal herb\n";
	qlog[20].desc[3]="-Bring Luz a snowflower\n";
    qlog[20].desc[4]="-Bring Luz a torchweed stalk\n";

	qlog[21]={"Primal: Part One\n", 0, 3, 0, 75, 0, 21}; //Grognak
	qlog[21].req[2]=getItemID("brass", "Token of Unobtaining"); //Kill or hunt 5 frillnecks
	qlog[21].desc[2] = "Kill 5 frillnecks for Grognak the Barbarian\n";

	qlog[22]={"A Little Knowledge\n", 0, 5, 15, 75, 0, 22}; //Frost
	qlog[22].req[2]=getItemID("skill", "book");
    qlog[22].req[3]=getItemID("spell", "book");
    qlog[22].req[4]=getItemID("paper", "scroll");
	qlog[22].desc[2]="-Find any skill book for Frost the wizard\n";
	qlog[22].desc[3]="-Bring Frost a spellbook\n";
    qlog[22].desc[4]="-Bring Frost a spell scroll\n";

	qlog[23]={"The Very Best\n", 0, 2, 15, 75, 0, 23}; //Aldo
	qlog[23].req[2]=getItemID("brass", "Token of Unobtaining");
	qlog[23].desc[2]="-Play a song that reminds Aldo of Spring\n";

	qlog[24]={"\n", 0, 2, 15, 75, 0, 24};

	qlog[25]={"Dream Engine\n", 0, 2, 15, 75, 0, 25};
}

void defineMainQuests()
{
    //Name, starting point, ending point, XP reward, GP reward, item reward, quest ID
    main_q[0] = {"Delivery\n", 0, 2, 10, 10, 0, 101};
    main_q[0].req[3] = getItemID("brass", "Token of Unobtaining");

    for (int i = 0; i < 3; i++) main_q[0].desc[i] = "-Deliver the silver flask to the librarian\n in the City Center\n";
}

#endif // TSF_QUESTS_H_INCLUDED
