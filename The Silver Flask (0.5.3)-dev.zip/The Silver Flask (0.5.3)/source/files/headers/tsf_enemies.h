#pragma once

#ifndef TSF_ENEMIES_H_INCLUDED
#define TSF_ENEMIES_H_INCLUDED

#include <iostream>

using namespace std;

void define_enemies()
{
	//name, hp, mp, atk, def, lvl, s/d/i/l, xp, gp, alive, idling text, element, weakness,

	//NULL enemy
	null_enem = {"NULL", "null", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, false, "null", "null", "null"};
        null_enem.ab = splist[0]; null_enem.id = 0;
        null_enem.itdr[0] = 0; null_enem.itdr[1] = 0; null_enem.itdr[2] = 0;

	for (int i = 0; i < 50; i++) { elist[i].agg_lvl = "peaceful"; elist[i].agg_lock = false; }

	cout << "Debug: set all agg_lvl to 'peaceful'\n";

	elist[0]={"Slime", "amorphous", 10, 10, 3, 0, 1, 0, 1, 0, 1, 3, 5, false, "bouncing", "water", "electric"};
	elist[0].ab=splist[6]; elist[0].id=0;
        elist[0].itdr[0]=102; elist[0].itdr[1]=102; elist[0].itdr[2]=73;
    cout << "Debug: loaded data for 'Slime'\n";

	elist[1]={"Goblin", "beast", 11, 0, 3, 1, 1, 0, 1, 0, 1, 3, 5, false, "picking its nose", "earth",  "fire", splist[0], 1};
        elist[1].itdr[0]=63; elist[1].itdr[1]=63; elist[1].itdr[2]=62;
    cout << "Debug: loaded data for 'Goblin'\n";

	elist[2]={"Viper", "amorphous", 8, 6, 4, 0, 1, 0, 3, 0, 1, 4, 5, false, "slitherin'", "poison", "fire", splist[5], 2};
        elist[2].itdr[0]=62; elist[2].itdr[1]=0; elist[2].itdr[2]=0;

    cout << "\nDebug: loaded 'viper' data\n";

	elist[3]={"Rabid Wolf", "beast", 15, 0, 5, 2, 1, 0, 2, 0, 1, 6, 5, false, "snarling and frothing", "earth", "fire", splist[5], 3};
        elist[3].itdr[0]=42; elist[3].itdr[1]=35; elist[3].itdr[2]=36;
        elist[3].agg_lvl = "aggressive";

	elist[4]={"Bandit", "warrior", 13, 15, 5, 1, 1, 0, 3, 0, 1, 7, 15, false, "chuckling evilly", "poison", "sword", splist[5], 4};
        elist[4].itdr[0]=17; elist[4].itdr[1]=3; elist[4].itdr[2]=10;

	elist[5]={"Crazed Arcanist", "electric", 15, 20, 7, 1, 1, 0, 0, 3, 1, 10, 20, false, "ionizing the plant life", "electric", "earth", splist[3], 5};
        elist[5].itdr[0]=33; elist[5].itdr[1]=21; elist[5].itdr[2]=53;

	elist[6]={"Water Spirit", "amorphous", 20, 20, 5, 1, 1, 1, 4, 2, 1, 10, 15, false, "singing a heart-rending melody", "water", "electric", splist[12], 6};
        elist[6].itdr[0]=64; elist[6].itdr[1]=46; elist[6].itdr[2]=51;

	elist[7]={"Dark Knight", "warrior", 25, 15, 10, 10, 1, 3, 0, 0, 0, 15, 100, false, "standing stoically", "physical", "light", splist[14], 7};
        elist[7].itdr[0]=24; elist[7].itdr[1]=14; elist[7].itdr[2]=27;

	elist[8]={"Flame Sprite", "fire", 15, 15, 7, 3, 1, 0, 5, 0, 1, 7, 15, false, "leaping from perch to perch excitedly", "fire", "water", splist[0], 8};
        elist[8].itdr[0]=74; elist[8].itdr[1]=45; elist[8].itdr[2]=52;
        elist[8].agg_lvl = "aggressive";

	elist[9]={"Frozen Soul", "ice", 13, 12, 8, 4, 1, 0, 0, 0, 0, 12, 15, false, "howling mournfully", "ice", "fire", splist[1], 9};
        elist[9].itdr[0]=103; elist[9].itdr[1]=0; elist[9].itdr[2]=47;
        elist[9].agg_lvl = "aggressive";

	elist[10]={"Goblin Chieftan", "boss", 20, 10, 8, 7, 2, 2, 0, 0, 0, 10, 50, false, "breathing heavily", "earth", "poison", splist[8], 10};
        elist[10].itdr[0]=284; elist[10].itdr[1]=284; elist[10].itdr[2]=284;
    cout << "Debug: loaded data for the first 10 enemies\n";
	elist[11]={"Forest Spirit", "plant", 25, 20, 7, 5, 1, 1, 2, 2, 1, 20, 40, false, "hovering verdantly", "earth", "fire", splist[18], 11};
        elist[11].itdr[0]=62; elist[11].itdr[1]=0; elist[11].itdr[2]=50;

	elist[12]={"Dark Paladin", "warrior", 25, 15, 10, 10, 1, 5, 0, 0, 0, 30, 150, false, "standing impassively", "physical", "light", splist[14], 12};
        elist[12].itdr[0]=11; elist[12].itdr[1]=28; elist[12].itdr[2]=31;
    cout << "Debug: loaded data for 'Dark Paladin'\n";
	elist[13]={"Dryad", "amorphous", 20, 20, 6, 4, 1, 0, 1, 1, 1, 10, 15, false, "blooming", "poison", "fire", splist[28], 13};
        elist[13].itdr[0]=49; elist[13].itdr[1]=62; elist[13].itdr[2]=83;

	elist[14]={"Forest Guardian", "boss", 100, 20, 10, 15, 1, 3, 0, 0, 2, 50, 100, false, "looming", "earth", "fire", splist[28], 14};
        elist[14].itdr[0]=0; elist[14].itdr[1]=0; elist[14].itdr[2]=76;

	elist[15]={"Vampsect", "insect", 25, 40, 10, 3, 1, 2, 5, 3, 5, 20, 10, false, "buzzing", "dark", "fire", splist[36], 15};
        elist[15].itdr[0]=0; elist[15].itdr[1]=0; elist[15].itdr[2]=0;
        elist[15].agg_lvl = "aggressive";
    cout << "Debug: loaded data for first 15 enemies\n";
	elist[16]={"Broodmother", "boss", 100, 60, 19, 5, 1, 3, 4, 5, 7, 10, 100, false, "excreting larva", "dark", "sword", splist[36], 16};
        elist[16].itdr[0]=0; elist[16].itdr[1]=0; elist[16].itdr[2]=0;
        elist[16].agg_lvl = "aggressive";

	elist[17]={"Ice Golem", "boss", 150, 60, 11, 7, 1, 2, 1, 2, 2, 30, 0, false, "glistening", "ice", "fire", splist[24], 17};
        elist[17].itdr[0]=47; elist[17].itdr[1]=47; elist[17].itdr[2]=99;

	elist[18]={"Lava Golem", "fire", 40, 60, 6, 2, 1, 3, 3, 3, 0, 30, 50, false, "burning", "fire", "water", splist[11], 18};
        elist[18].itdr[0]=104; elist[18].itdr[1]=52; elist[18].itdr[2]=75;
	elist[19]={"Dark General", "boss", 200, 45, 25, 15, 1, 8, 2, 2, 4, 200, 200, false, "brooding on the ebony throne", "dark", "poison", splist[14], 19};
        elist[19].itdr[0]=297; elist[19].itdr[1]=297; elist[19].itdr[2]=297;
    cout << "Debug: loaded data for 'Dark General'\n";
	elist[20]={"Pixie Soldier", "warrior", 50, 30, 10, 4, 1, 3, 3, 1, 1, 25, 10, false, "hovering", "wind", "ice", splist[5], 20};
        elist[20].itdr[0]=102; elist[20].itdr[1]=102; elist[20].itdr[2]=102;

        cout << "Debug: Loaded data for first 20 enemies\n";

	elist[21]={"Rampaging Demon", "boss", 50, 100, 10, 4, 5, 0, 0, 0, 1, 150, 100, false, "tearing apart an Arcanum adept", "fire", "holy", splist[11], 21};
        elist[21].itdr[0]=75; elist[21].itdr[1]=100; elist[21].itdr[2]=297;

	elist[22]={"Underworld Empress", "boss", 1000, 300, 30, 20, 1, 12, 20, 23, 9, 500, 500, false, "grinning wickedly amidst a nimbus of red light", "dark", "holy", splist[37], 22};
        elist[22].itdr[0]=102; elist[22].itdr[1]=102; elist[22].itdr[2]=102;

	elist[23]={"Ascendant Queen", "boss", 700, 300, 15, 15, 1, 9, 20, 20, 7, 100, 150, false, "laughing madly,\nwreathed in cerulean sparks", "electric", "earth", splist[2], 23};
        elist[23].itdr[0]=102; elist[23].itdr[1]=102; elist[23].itdr[2]=102;

	elist[24]={"Luci, Pixie Sorceress", "magic", 100, 20, 10, 15, 1, 3, 0, 0, 2, 50, 100, false, "gasping painfully", "wind", "ice", splist[26], 24};
        elist[24].itdr[0]=102; elist[24].itdr[1]=102; elist[24].itdr[2]=102;

	elist[25]={"Ancient Dragon", "boss", 1500, 200, 50, 30, 1, 19, 12, 4, 8, 250, 300, false, "riding thermal updrafts on massive, leathery wings", "fire", "ice", splist[11], 25};
        elist[25].itdr[0]=211; elist[25].itdr[1]=211; elist[25].itdr[2]=201;

	elist[26]={"Mud Golem", "amorphous", 30, 15, 3, 3, 1, 1, 0, 0, 0, 15, 20, false, "squelching", "earth", "water", splist[8], 26};
        elist[26].itdr[0]=26; elist[2].itdr[1]=39; elist[2].itdr[2]=50;

	elist[27]={"Frost Troll", "beast", 45, 10, 3, 1, 1, 2, 1, 0, 0, 20, 20, false, "digging in the snow", "ice", "fire", splist[6], 27};
        elist[27].itdr[0]=103; elist[27].itdr[1]=36; elist[27].itdr[2]=42;
        elist[27].agg_lvl = "aggressive";

	elist[28]={"Spineling", "beast", 30, 10, 6, 2, 1, 1, 2, 1, 3, 25, 20, false, "rattling its quills", "dark", "electric", splist[5], 28};
        elist[28].itdr[0]=3; elist[28].itdr[1]=59; elist[2].itdr[28]=60;
        elist[28].agg_lvl = "aggressive";

	elist[29]={"Sylvan", "archer", 35, 25, 5, 0, 1, 1, 5, 3, 2, 40, 40, false, "plucking its bowstring", "earth", "fire", splist[9], 29};
        elist[29].itdr[0]=56; elist[29].itdr[1]=57; elist[29].itdr[2]=81;
        elist[29].agg_lvl = "aggressive";

	elist[30]={"Spectral Warrior", "warrior", 60, 10, 4, 1, 1, 3, 1, 1, 2, 30, 20, false, "flickering", "wind", "earth", splist[14], 30};
        elist[30].itdr[0]=10; elist[30].itdr[1]=14; elist[30].itdr[2]=46;
        elist[30].agg_lvl = "aggressive";

	elist[31]={"Slamander", "amorphous", 70, 80, 8, 0, 1, 2, 0, 2, 0, 50, 50, false, "smoldering", "fire", "ice", splist[0], 31};
        elist[31].itdr[0]=74; elist[31].itdr[1]=104; elist[31].itdr[2]=43;

	elist[32]={"Arc Sprite", "electric", 40, 100, 5, 0, 1, 0, 7, 7, 7, 100, 0, false, "crackling", "electric", "earth", splist[3], 32};
        elist[32].itdr[0]=0; elist[32].itdr[1]=53; elist[32].itdr[2]=0;
        elist[32].agg_lvl = "aggressive";

	elist[33]={"Naiad", "beast", 35, 60, 3, 1, 1, 0, 5, 6, 3, 50, 60, false, "treading water gracefully", "water", "electric", splist[25], 33};
        elist[33].itdr[0]=95; elist[33].itdr[1]=51; elist[33].itdr[2]=97;

	elist[34]={"Lake Serpent", "serpent", 65, 10, 6, 3, 1, 6, 3, 0, 0, 100, 0, false, "circling sinuously", "water", "electric", splist[8], 34};
        elist[34].itdr[0]=39; elist[34].itdr[1]=39; elist[34].itdr[2]=39;
        elist[34].agg_lvl = "aggressive";

	elist[35]={"Buhorn", "enemy", 100, 0, 10, 6, 1, 3, 0, 0, 2, 100, 30, false, "grazing", "earth", "ice", splist[0], 35};
        elist[35].itdr[0]=58; elist[35].itdr[1]=42; elist[35].itdr[2]=35;

	elist[36]={"Screecher", "amorphous", 25, 25, 4, 0, 1, 0, 6, 3, 1, 20, 0, false, "flapping and shrieking", "dark", "fire", splist[36], 36};
        elist[36].itdr[0]=0; elist[36].itdr[1]=35; elist[36].itdr[2]=0;
        elist[36].agg_lvl = "aggressive";

	elist[37]={"Boulderbiter", "enemy", 20, 10, 10, 4, 1, 3, 0, 0, 0, 40, 20, false, "crunching gravel", "earth", "light", splist[8], 37};
        elist[37].itdr[0]=42; elist[37].itdr[1]=66; elist[37].itdr[2]=48;
        elist[37].agg_lvl = "aggressive";

	elist[38]={"Flitwing", "enemy", 25, 100, 2, 0, 1, 0, 12, 3, 9, 120, 35, false, "fluttering", "wind", "earth", splist[3], 38};
        elist[38].itdr[0]=70; elist[38].itdr[1]=70; elist[38].itdr[2]=70;

	elist[39]={"Stone Golem", "enemy", 120, 30, 5, 6, 1, 2, 0, 0, 0, 50, 90, false, "trudging in circles", "earth", "earth", splist[4], 39};
        elist[39].itdr[0]=48; elist[39].itdr[1]=55; elist[39].itdr[2]=44;

    cout << "Debug: filled first 40 enemies\n";

    //Town/city enemies
    elist[40]={"Paladin", "NPC_warrior", 80, 20, 5, 5, 1, 2, 0, 1, 1, 50, 90, false, "patrolling", "physical", "poison", splist[5], 40};
        elist[40].itdr[0]=getItemID("steel", "kiteshield"); elist[40].itdr[1]=getItemID("steel", "longsword"); elist[40].itdr[2]=getItemID("steel", "plate armor");
        elist[40].agg_lock = true;
    elist[41]={"Knight", "NPC_warrior", 60, 20, 3, 3, 1, 2, 0, 1, 1, 60, 40, false, "patrolling", "physical", "dark", splist[19], 41};
        elist[41].itdr[0]=getItemID("iron", "longsword"); elist[41].itdr[1]=getItemID("iron", "chainmail"); elist[41].itdr[2]=getItemID("steel", "spear");
        elist[41].agg_lock = true;
    elist[42]={"Town Guard", "NPC_warrior", 25, 5, 2, 3, 1, 0, 0, 1, 1, 10, 15, false, "patrolling", "physical", "poison", splist[19], 42};
        elist[42].itdr[0]=getItemID("wooden", "broadshield"); elist[42].itdr[1]=getItemID("wooden", "spear"); elist[42].itdr[2]=getItemID("iron", "spear");
        elist[42].agg_lock = true;
    elist[43]={"Villager", "NPC", 10, 0, 1, 1, 1, 0, 0, 0, 0, 20, 0, false, "working", "physical", "physical", splist[7], 43};
        elist[43].itdr[0]=getItemID("wooden", "bucket"); elist[43].itdr[1]=getItemID("none", "bread"); elist[43].itdr[2]=getItemID("none", "wool");
        elist[43].agg_lock = true;

    //Hidden Jungle
    elist[44]={"frillneck", "beast", 40, 3, 2, 1, 1, 3, 1, 5, 5, 0, 20, false, "stalking through the ferns", "physical", "fire", splist[71], 44};
        elist[44].itdr[0]=getItemID("raw", "meat"); elist[44].itdr[1]=getItemID("sturdy", "bone"); elist[44].itdr[2]=getItemID("none", "feather");
        elist[44].agg_lock = false;

    elist[45]={"knifetooth", "beast", 25, 7, 1, 1, 3, 0, 0, 0, 0, 0, 30, false, "scenting for prey", "physical", "poison", splist[5], 45};
        elist[45].itdr[0]=getItemID("raw", "meat"); elist[45].itdr[1]=getItemID("raw", "meat"); elist[45].itdr[2]=getItemID("none", "leather");
        elist[45].agg_lock = true;

    elist[46]={"longneck", "beast", 100, 1, 1, 1, 0, 0, 0, 0, 0, 0, 45, false, "munching placidly on a leafy treetop", "physical", "physical", splist[8], 46};
        elist[46].itdr[0]=getItemID("raw", "meat"); elist[46].itdr[1]=getItemID("raw", "meat"); elist[46].itdr[2]=getItemID("sturdy", "bone");
        elist[46].agg_lock = true;

    elist[47]={"rooster", "beast", 5, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, false, "eying you haughtily", "physical", "physical", splist[8], 46};
        elist[47].itdr[0]=getItemID("raw", "fowl"); elist[47].itdr[1]=getItemID("none", "feather"); elist[47].itdr[2]=getItemID("none", "feather");
        elist[47].agg_lock = false;

    cout << "Debug: filled data for town and jungle enemies\n";
    for (int i = 0; i < 50; i++) elist[i].hpmax = elist[i].hp;
    cout << "Debug: set max HP for all enemies\n";
}

#endif // TSF_ENEMIES_H_INCLUDED
