#ifndef TSF_AREAS_H_INCLUDED
#define TSF_AREAS_H_INCLUDED

#include "tsf_classes.h"
#include "tsf_settings.h"

using namespace std;

void define_areas()
{
	//name, desc, e. chance, water, wood, mine, smithy, armory, tool shop, potion shop, n/s/e/w, x/y, id

	//bottom row:

	loc[1][10]={"Village", "The homely village of your youth.\nMany fond memories are woven into\nits simple houses, dirt paths,\nand smiling townsfolk.\n",
	10, false, false, false, false,
	true, true, 0,
	true, false, true, false, 1, 10, 1, "[V_]", 136, 136};
	loc[1][10].enemies[0] = 43;
	loc[1][10].enemies[1] = 42;
	loc[1][10].enemies[2] = 43;
	loc[1][10].npcs[0]=nlist[1];
	loc[1][10].npcs[1]=mq_npc[0];
	loc[1][10].signs.push_back(red);
	loc[1][10].signs[0]={"wooden", "To move around, type in the command 'move' and then the direction you want to go."};
	loc[1][10].signs.push_back(blue);
	loc[1][10].signs[1]={"painted", "To talk to someone nearby, enter the 'talk' command,\nthen the person's name."};

	loc[2][10]={"Forest",
	"A dense maze of trees and ferns.\nBirdcalls of every kind fill the air;\na pair of deer skip lightly through the undergrowth.\nThe air smells refreshingly of pine needles and loam.\n",
	10, false, true, false, false,
	false, false, false,
	true, false, true, true, 2, 10, 2, "[F_]", 34, 34};
	loc[2][10].enemies[2]=0;

	loc[3][10]={"Sparse Forest",
	"The undergrowth is thin and \nbetween a scattering of evergreens you can see\nthe edge of the forest and grassland beyond.\n",
	20, false, true, false, false,
	false, false, false,
	true, false, true, true, 3, 10, 3, "[f_]", 34, 102};
	loc[3][10].enemies[0]=0;
	loc[3][10].enemies[1]=1;

	loc[4][10]={"Grassland",
	"A plain of tall grasses rippling in the breeze.\n",
	15, false, false, false, false,
	false, false, false,
	true, false, true, true, 4, 10, 4, "[G_]", 102, 102};
	loc[4][10].enemies[0]=2;
	loc[4][10].enemies[1]=1;

	loc[5][10]={"Healer's Hut",
	"A wide open field of long grass swaying\nin the breeze. There is a simply built wooden\nhut, with an accompanying garden that looks\nlike it has seen better days.\n",
	15, false, false, false, false,
	false, false, false,
	true, false, true, true, 5, 10, 5, "[HH]", 102, 84};
	loc[5][10].enemies[0]=2;
	loc[5][10].enemies[1]=1;
	loc[5][10].npcs[0]=nlist[3];

	loc[6][10]={"Grassland",
	"A plain of tall grasses rippling in the breeze.\n",
	15, false, false, false, false,
	false, false, false,
	true, false, true, true, 6, 10, 6, "[G_]", 102, 102};
	loc[6][10].enemies[0]=2;
	loc[6][10].enemies[1]=1;

	loc[7][10]={"Grassland Caravan",
	"A plain of tall grasses rippling in the breeze.\nA wide river flows along the east. A group of\ncovered wagons painted with intricate,\ncolorful designs have stopped here to rest.\nA group of players are tuning instruments, dancing,\nsinging or tumbling. Large oxen flick their\ntails lazily and a few colorful children chase each\nother around the camp.\n",
	0, false, false, false, false,
	false, false, false,
	true, false, false, true, 7, 10, 7, "[CV]", 102, 238};
	loc[7][10].enemies[0]=0;
	loc[7][10].enemies[1]=1;
	loc[7][10].npcs[0]=nlist[5];
	loc[7][10].npcs[1]=nlist[4];

	loc[8][10]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 8, 10, 8, "[~~]",  153, 153};
	loc[8][10].enemies[0]=0;

	loc[9][10]={"Sylvan Forest",
	"A thick grove of leafy, green trees with a clearing at the\ncenter. In the clearing there is a small meadow dotted\nwith wildflowers, and a pond, where silvery fish \ncan be seen in the shallows. \n",
	10,
	1, 1, false, false,
	false, false, false,
	true, false, true, false, 9, 10, 9, "[Sf]", 34, 34};
	loc[9][10].npcs[0]=comp_npc[0];
	loc[9][10].enemies[0]=6;
	loc[9][10].enemies[1]=13;
	loc[9][10].enemies[2]=29;

	loc[10][10]={"Mithril Mountain",
	"The stony slopes of this steep, jagged mountain are\nstreaked with vibrant blue ore. As you climb,\nthe mountain looms overhead, casting the\npath into gloomy shadow.\nA group of dwarves have set up a mining camp\nnear a narrow cave.\n",
	5,
	0, 0, 1, 0,
	0, 0, 0,
	1, 0, 0, 1,
	10, 10, 10, "[Mm]", 136, 51};
	loc[10][10].enemies[0]=37;
	loc[10][10].enemies[1]=39;
	loc[10][10].enemies[2]=29;

	//2nd row up

	loc[1][9]={"Forest",
	"A dense maze of trees and ferns.\nBirdcalls of every kind fill the air;\na pair of deer skip lightly through the undergrowth.\nThe air smells refreshingly of pine needles and loam.\n",
	15, false, true, false, false,
	false, false, false,
	true, true, true, false, 1, 9, 11, "[F_]", 34, 34};
	loc[1][9].enemies[0]=0;

	loc[2][9]={"Forest Path",
	"Winding its way between sparse ferns\nand pines is a well-trodden path, curving\namidst the forest to lead north and east.\n",
	10, false, true, false, false,
	false, false, false,
	true, true, true, true, 2, 9, 12, "[fp]", 34, 34};
	loc[2][9].enemies[0]=0;
	loc[2][9].enemies[1]=1;

	loc[3][9]={"Grassland Path",
	"Rolling plains cut down the middle by a \nnarrow dirt path running east-west.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, true, true, 3, 9, 13, "[G-]", 102, 102};
	loc[3][9].enemies[0]=0;
	loc[3][9].enemies[1]=1;

	loc[4][9]={"Grassland Path",
	"Rolling plains cut down the middle by a \nnarrow dirt path running east-west.\n",
	10, false, false, false, false,
	false, false, false,
	false, true, true, true, 4, 9, 14, "[G-]", 102, 102};
	loc[4][9].enemies[0]=1;
	loc[4][9].enemies[1]=2;

	loc[5][9]={"Grassland Path",
	"The path curves between tall grasses to lead north\nacross a bridge, or west into the fields.\n",
	10, false, false, false, false,
	false, false, false,
	false, true, true, true, 5, 9, 15, "[G/]", 102, 102};
	loc[5][9].enemies[0]=1;
	loc[5][9].enemies[1]=2;
	loc[5][9].npcs[0]=nlist[8];

	loc[6][9]={"Grassland",
	"A plain of tall grasses rippling in the breeze.\n",
	15, false, false, false, false,
	false, false, false,
	false, true, true, true, 6, 9, 16, "[G_]", 102, 102};
	loc[6][9].enemies[0]=1;
	loc[6][9].enemies[1]=2;

	loc[7][9]={"Riverbank",
	"The grassland slopes gently down to meet a wide\nriver flowing along the northern and eastern\nhorizon. Bullfrogs croak noisily from the\nreedy shallows.\n",
	15, true, false, false, false,
	false, false, false,
	false, true, false, true, 7, 9, 17, "[G~]", 102, 153};
	loc[6][9].enemies[0]=6;
	loc[6][9].enemies[1]=26;

	loc[8][9]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 8, 9, 18, "[~~]",  153, 153};
	loc[8][9].enemies[0]=0;

	loc[9][9]={"Elven Village",
	"A tree-lined path winds through loose clusters of simple,\nwooden buildings adorned at the eaves with\nrunic charms clattering in the wind.\nSharp-eared Sylvan Elves walk along the\narboreal lane, serenely attending business\nat the market, or other such errand s.\n",
	0, false, true, false, false,
	1, 0, 1,
	true, true, true, 0, 9, 9, 19, "[EV]", 170, 170};
	loc[9][9].enemies[0]=0;
	loc[9][9].enemies[1]=1;

	loc[10][9]={"Elven Workshop",
	"Long shelves of books occupy half of this large\nstone building, the other half dominated by\nmyriad complex machines, all gears and\nlevers and glowing, floating crystals.\nIn between the two sides is a large table\nlittered with notes, charts, and equipment of all kinds.\n",
	1, false, false, false, 1,
	0, 0, 0,
	0, true, 0, 1, 10, 9, 20, "[EW]", 119, 119};
	loc[10][9].enemies[0]=33;
	loc[10][9].enemies[1]=33;
	loc[10][9].enemies[2]=33;

	//3rd row up

	loc[1][8]={"Sparse Forest",
	"The undergrowth is thin and \nbetween a scattering of evergreens you can see\nthe edge of the forest and grassland beyond.\n",
	20, false, true, false, false,
	false, false, false,
	true, true, true, false, 1, 8, 21, "[f_]", 34, 102};
	loc[1][8].enemies[0]=0;
	loc[1][8].enemies[1]=1;

	loc[2][8]={"Grassland Path",
	"Rolling plains cut down the middle by a \nnarrow dirt path running north-south.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, true, true, 2, 8, 22, "[G|]", 102, 102};
	loc[2][8].enemies[0]=1;
	loc[2][8].enemies[1]=2;

	loc[3][8]={"Wetlands",
	"Fields of pale grass flooded by a river flowing through the northeast.\nBullfrogs minding their tadpoles in the shallows\ngreedily eye shifting swarms of insects flitting about the reeds.\n\n",
	10, true, false, false, false,
	false, false, false,
	false, true, false, true, 3, 8, 23, "[G~]", 102, 153};
	loc[3][8].enemies[0]=26;
	loc[3][8].enemies[1]=2;

	loc[4][8]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 4, 8, 24, "[~~]",  153, 153};
	loc[4][8].enemies[0]=0;

	loc[5][8]={"Bridge",
	"A wide cobblestone bridge stretches over the river.\nStanding on the sun-warmed flagstones you can see\nthe main gate of a high-walled city to the north.\nShadowy fish nose among the reeds growing under\nthe bridge.\n",
	10, true, false, false, false,
	false, false, false,
	true, true, false, false, 5, 8, 25, "[||]", 136, 136};
	loc[5][8].enemies[0]=6;
	loc[5][8].enemies[1]=4;
	loc[5][8].enemies[2]=43;

	loc[6][8]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 6, 8, 26, "[~~]",  153, 153};
	loc[6][8].enemies[0]=0;

	loc[7][8]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 7, 8, 27, "[~~]",  153, 153};
	loc[7][8].enemies[0]=0;

	loc[8][8]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 8, 8, 28, "[~~]",  153, 153};
	loc[8][8].enemies[0]=0;

	loc[9][8]={"Tree Bridge",
	"You are crossing a sturdy log bridge high over the\nrushing river. At each end of the bridge is an\nimmense tree, its roots intertwining with the\nlogs and holding them in place.\n",
	10,
	0, 0, 0, 0,
	0, 0, 0,
	1, 1, 0, 0,
	9, 8, 29, "[||]", 34, 102};
	loc[9][8].enemies[0]=33;
	loc[9][8].enemies[1]=13;
	loc[9][8].enemies[2]=29;

	loc[10][8]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 10, 8, 30, "[~~]",  153, 153};
	loc[10][8].enemies[0]=0;

	//4th row from bottom

	loc[1][7]={"Grassland",
	"A plain of tall grasses, rippling in the breeze.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, true, false, 1, 7, 31, "[G_]", 102, 102};
	loc[1][7].enemies[0]=1;
	loc[1][7].enemies[1]=2;


	loc[2][7]={"Farmland",
	"Neat rows of crops grow in parallel lines\nup to the edge of the river to the east.\nBirds hop about looking for loose corn,\nunperturbed by a tatty old scarecrow.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, false, true, 2, 7, 32, "[FL]", 238, 102};
	loc[2][7].enemies[0]=3;
	loc[2][7].enemies[1]=2;
	loc[2][7].npcs[0]=nlist[0];

	loc[3][7]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 3, 7, 33, "[~~]",  153, 153};
	loc[3][7].enemies[0]=0;

	loc[4][7]={"The Arcanum",
	"Shadowed by buildings that press against it from all\nsides, the ancient Arcanum looms spectrally, sharp ebony spires thrust into the sky.\nThe interior echoes with hushed arcane murmurs and footsteps on black marble.\n",
	0, false, true, false, false,
	false, false, false,
	0, 0, 1, 0, 4, 7, 34, "[AM]", 17, 17};
	loc[4][7].enemies[0]=0;
	loc[4][7].enemies[1]=1;
	loc[4][7].npcs[0]=nlist[14];
	loc[4][7].npcs[1]=nlist[15];

	extra[0]={"Arcanum Interior",
	"Your footsteps echo eerily as you enter the cavernous main hall.\nEvery surface is carved and fitted polished black marble.\nAn immense and intricately detailed summoning\ncircle dominates the center of the glossy black floor.\nHuddled groups of hooded mystics discuss\narcane sciences in hushed tones.\n",
	0, 0, 0, 0, 0,
	0, 0, 0,
	0, 0, 1, 0, 0, 0, 1, "[AI]"};


	loc[5][7]={"City Gate South",
	"\nAs you pass through an immense stone arch, your senses\nare overwhelmed by the bustling crowds. Vendors holler\ntheir prices, horse-drawn wagons rattle to and fro,\nand more people than you can count\ntraverse the wide cobblestone thoroughfare.\nA path leading west vanishes behind a dark archway.\nWhite marble steps lead up to a pillared temple in the east.\n",
	1, false, false, false, false,
	false, true, false,
	true, true, 1, 1, 5, 7, 35, "[CS]", 136, 136};
	loc[5][7].enemies[0]=42;
	loc[5][7].enemies[1]=43;
	loc[5][7].enemies[2]=43;

	loc[6][7]={"Temple of Light",
	"An unseen choir of monks echoes throughout the white marble temple.\nShallow alcoves line the walls, alternating window ledge seats and planters filled with\nblooms of every color. In the central chamber is\na simple fountain, sparkling in a gentle ray of sunlight\nshining through a delicately wrought skylight.\n",
	0, false, false, false, false,
	false, false, false,
	0, 0, 0, 1, 6, 7, 36, "[TL]", 238, 238};
	loc[6][7].enemies[0]=0;
	loc[6][7].npcs[0]=nlist[16];
	loc[6][7].npcs[1]=nlist[17];

	loc[7][7]={"Grassland",
	"A plain of tall grasses, rippling in the breeze,\nagainst high city walls in the west.\nA wide river borders the land to the south.\n",
	10, false, false, false, false,
	false, false, false,
	true, false, true, false, 7, 7, 37, "[G_]", 102, 102};
	loc[7][7].enemies[0]=7;
	loc[7][7].enemies[1]=4;
	loc[7][7].enemies[2]=35;

	loc[8][7]={"Grassland Path",
	"A plain of tall grass, cut down the middle by a\npath running from north to east.\nA wide river borders the land to the south.\n",
	10, false, false, false, false,
	false, false, false,
	true, false, true, true, 8, 7, 38, "[G-]", 102, 102};
	loc[8][7].enemies[0]=5;
	loc[8][7].enemies[1]=4;
	loc[8][7].enemies[1]=7;

	loc[9][7]={"Forest Path",
	"Winding its way between sparse ferns\nand pines is a well-trodden path, curving\namidst the forest to lead west or south.\n",
	10, false, true, false, false,
	false, false, false,
	false, true, true, true, 9, 7, 39, "[fp]", 34, 34};
	loc[9][7].enemies[0]=13;
	loc[9][7].enemies[1]=29;
	loc[9][7].enemies[2]=29;

	loc[10][7]={"Ancient Forest",
	"Huge, moss-covered trees grow close togther, surrounded\nby waist-high ferns and rotting logs. Dust\nmotes drift in scattered rays of sunlight\nfiltering down through the dense canopy.\nThe whole forest is blanketed in eerie silence.\n",
	10, false, true, false, false,
	false, false, false,
	false, true, false, true, 10, 7, 40, "[F_]", 34, 34};
	loc[10][7].enemies[0]=13;
	loc[10][7].enemies[1]=11;
	loc[10][7].enemies[2]=29;

	//5th row

	loc[1][6]={"Farmland",
	"The fields are filled with row after row\nof sprouting crops, right up to the base\nof a mountain to the north.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, true, false, 1, 6, 41, "[FL]", 102, 238};
	loc[1][6].enemies[0]=3;
	loc[1][6].enemies[1]=3;

	loc[2][6]={"Windmill",
	"At the center of the farmland is a tall windmill,\narms turning slowly in the breeze. Next to the mill\nis a quaint, simple farmhouse, and a short \ndistance away, a bright red barn and grain silo. To the \neast is a ferry moored on the river.\n",
	0, false, false, false, false,
	false, false, false,
	true, true, false, true, 2, 6, 42, "[WM]", 136, 136};
	loc[2][6].enemies[0]=0;
	loc[2][6].npcs[0]=nlist[2];
	loc[2][6].npcs[1]=nlist[6];

	loc[3][6]={"River Ferry",
	"You are crossing the wide river on a simply built ferry.\nThe ferryman largely ignores you, not impolitely, focused\non his task of guiding the vessel across. The eddying\nwaters sparkle in the sun, and occasionally a fish breaks\nthe surface in a glittering leap.\n",
	10, true, false, false, false,
	false, false, false,
	false, false, true, true, 3, 6, 43, "[~F]", 17, 153};
	loc[3][6].enemies[0]=6;
	loc[3][6].enemies[1]=6;
	loc[3][6].enemies[2]=33;

	loc[4][6]={"City Gate West",
	"Inside the city's wide western gateway you find\nyourself lost in a crowded maze of market stalls and\nfishermen, all competing to sell their catch from the\n river to the west. The main road runs east-west\nthrough this district.\n",
	10, false, false, false, false,
	false, false, false,
	false, false, true, true, 4, 6, 44, "[CW]", 136, 136};
	loc[4][6].enemies[0]=42;
	loc[4][6].enemies[1]=43;
	loc[4][6].enemies[2]=43;

	loc[5][6]={"City Center",
	"The main square is dominated by a large fountain at its center,\na marble statue of the hero Samavarius locked in combat with a mighty dragon,\nwater pouring from their mouths.\nThe crowds are thinner here; many folk are leisurely strolling,\nchatting, or admiring the fountain.\n",
	20, false, false, false, false,
	false, false, false,
	true, true, true, true, 5, 6, 45, "[CC]", 136, 136};
	loc[5][6].enemies[0]=42;
	loc[5][6].enemies[1]=43;
	loc[5][6].enemies[2]=41;

	loc[6][6]={"City Gate East",
	"The East District is dark and quiet; tightly packed houses and crooked streets give the area a\nslightly claustrophobic feel. A narrow, shadowed back-alley leads north into the maze.\n",
	10, false, false, false, false,
	false, false, true,
	1, false, true, true, 6, 6, 46, "[CE]", 136, 136};
	loc[6][6].enemies[0]=43;
	loc[6][6].enemies[1]=4;
	loc[6][6].enemies[2]=4;

	loc[7][6]={"Grassland Path",
	"A worn conblestone road leads north across the plain.\nA narrow dirt path disappears into the grass to the east.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, true, true, 7, 6, 47, "[G-]", 102, 102};
	loc[7][6].enemies[0]=5;
	loc[7][6].enemies[1]=7;
	loc[7][6].enemies[1]=35;

	loc[8][6]={"Grassland Path",
	"Grassy fields thick with bushes and flowers.\nA curved dirt path nearly hidden in the leaves leads west or south.\n",
	10, false, false, false, false,
	false, false, false,
	true, true, true, true, 8, 6, 48, "[G|]", 102, 102};
	loc[8][6].enemies[0]=35;
	loc[8][6].enemies[1]=4;
	loc[8][6].enemies[2]=7;

	loc[9][6]={"Ancient Forest",
	"Huge, moss-covered trees grow close together, surrounded by waist-high ferns and rotting logs.\nDust motes drift in scattered rays of sunlight filtering down through the dense canopy.\nThe whole forest is blanketed in eerie silence.\n",
	10, false, true, false, false,
	false, false, false,
	true, false, 0, true, 9, 6, 49, "[F_]", 34, 34};
	loc[9][6].enemies[0]=13;
	loc[9][6].enemies[1]=11;
	loc[9][6].enemies[2]=29;

	loc[10][6]={"Sacred Forest Grove",
	"Several tall trees stand in a ring around a misty glade.\nDozens of luminescent butterflies hover over the grass, giving the area a spectral glow.\nAt the very center of the clearing is an immense, gnarled tree, rising up and out of sight.\n",
	10, false, true, false, false,
	false, false, false,
	false, true, false, true, 10, 6, 12, "[SG]", 34, 170};
	loc[10][6].enemies[0]=13;
	loc[10][6].enemies[1]=11;
	loc[10][6].enemies[2]=14;

	//6th row

	loc[1][5]={"Hills",
	"You are walking through miles of low, stony hills.\nTo the north, the hills grow steeper and rockier.\n",
	15, false, false, false, false,
	false, false, false,
	true, true, true, false, 1, 5, 51, "[m_]", 136, 102};
	loc[1][5].enemies[0]=1;
	loc[1][5].enemies[1]=3;

	loc[2][5]={"Pasture",
	"Herds of placid sheep and cattle graze lazily on a\nwide, verdant field. A rickety wooden fence\nsurrounds the field; it is low enough to\ncross easily but the various livestock seem\ncontent where they are.\n",
	10, false, false, false, false, //Enemy chance, water, wood, mine, smithy
	false, false, false,
	false, true, false, true, 2, 5, 52, "[PA]", 102, 170};
	loc[2][5].sheep=true;
	loc[2][5].enemies[0]=1;
	loc[2][5].enemies[1]=3;
	loc[2][5].enemies[2]=1;

	loc[3][5]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 3, 5, 53, "[~~]",  153, 153};
	loc[3][5].enemies[0]=0;

	loc[4][5]={"Grand Hall",
	"The city's famed Grand Hall is simply built of sturdy\ntimber and stone, though its soaring eaves\nfly rich banners of red, white, and gold. \nRunning nearly the full length of the hall is a\nwell-worn trestle table flanked by low benches. Knights\nand Paladins in varying dress sit along the table, eating,\ndrinking, or conversing with one another.\n",
	20, false, false, false, false,
	false, false, false,
	0, 0, 1, 0, 4, 5, 54, "[GH]", 204, 204};
	loc[4][5].enemies[0]=41;
	loc[4][5].enemies[1]=40;
	loc[4][5].enemies[2]=40;
	loc[4][5].npcs[0]=nlist[11];
	loc[4][5].npcs[1]=nlist[10];

	loc[5][5]={"City Gate North",
	"\nAs you pass into the city craftsmen's quarter, your ears are greeted by the ringing of hammers and workmen shouting.\nArtificers and tradesmen of all kinds line the stone-paved road, hard at work as thick smoke billows from a dozen ovens and chimneys.\nA road lined with red and white banners leads west.\n",
	15, false, false, false, true,
	true, false, false,
	true, true, false, 1, 5, 5, 55, "[CN]", 136, 136};
	loc[5][5].enemies[0] = 43;
	loc[5][5].enemies[1] = 41;
	loc[5][5].enemies[2] = 40;
	loc[5][5].npcs[0] = nlist[18];

	loc[6][5]={"Serpents' Den",
	"You find an old, abandoned warehouse down a crooked alleyway. By the light filtering\nthrough boarded windows you can just make out perhaps a dozen grim-faced,\nheavily armed strangers, eyeing you carefully, seated on broken crates and old mattresses.\nA few are drinking at a lamplit bar made of crates and planks.\n",
	5, false, false, false, false,
	false, true, false,
	0, true, false, false, 6, 5, 56, "[AW]", 170, 170};
	loc[6][5].enemies[0]=4;
	loc[6][5].enemies[1]=5;
	loc[6][5].enemies[2]=4;
	loc[6][5].npcs[0]=nlist[12];
	loc[6][5].npcs[1]=nlist[13];

	loc[7][5]={"Grassland Path",
	"A plain of tall grasses rippling in the breeze,\ncut down the middle by a cobblestone road\nrunning north-south.\n",
	15, false, false, false, false,
	false, false, false,
	1, 1, 1, 0, 7, 5, 57, "[G|]", 102, 102};
	loc[7][5].enemies[0]=4;
	loc[7][5].enemies[1]=5;
	loc[7][5].enemies[2]=7;


	loc[8][5]={"Grassland",
	"A plain of tall grasses rippling in the breeze.\n",
	15, false, false, false, false,
	false, false, false,
	false, true, false, true, 8, 5, 58, "[G_]", 102, 102};
	loc[8][5].enemies[0]=4;
	loc[8][5].enemies[1]=35;
	loc[8][5].enemies[2]=7;

	loc[9][5]={"Ancient Forest",
	"Huge, moss-covered trees grow close togther, surrounded\nby waist-high ferns and rotting logs. Dust\nmotes drift in scattered rays of sunlight\nfiltering down through the dense canopy.\nThe whole forest is blanketed in eerie silence.\n",
	10, false, true, false, false,
	false, false, false,
	0, 1, 1, 0, 9, 5, 59, "[F_]", 34, 34};
	loc[9][5].enemies[0]=13;
	loc[9][5].enemies[1]=11;
	loc[9][5].enemies[2]=29;

	loc[10][5]={"Ancient Forest",
	"Huge, moss-covered trees grow close togther, surrounded\nby waist-high ferns and rotting logs. Dust\nmotes drift in scattered rays of sunlight\nfiltering down through the dense canopy.\nThe whole forest is blanketed in eerie silence.\n",
	20, false, true, false, false,
	false, false, false,
	0, 1, 0, 1, 10, 5, 60, "[F_]", 34, 34};
	loc[10][6].enemies[0]=13;
	loc[10][6].enemies[1]=29;
	loc[10][6].enemies[2]=11;

	//7th row from bottom

	loc[1][4]={"Dwarven Mine",
	"A steep mountain towers above you, criss-crossed with\nperilous paths and dotted with caves. A handful of\nindustrious Dwarves are busily swinging their picks\n at the rock or carting away ores and rubble.\nMassive stone doors set in the mountain to the east\nlead underground, but the heavily armed Dwarven guards seem\nwary of outsiders.\n",
	15, false, false, true, false, //Water, wood, mine, smithy
	false, false, false, //Toolshop, potshop, armory
	false, true, false, false, 1, 4, 61, "[DM]", 136, 136};
	loc[1][4].enemies[0]=1;
	loc[1][4].enemies[1]=3;
	loc[1][4].enemies[2]=39;
	loc[1][4].npcs[0]=nlist[7];

	loc[2][4]={"Underground City",
	"Entering through a series of immense stone arches,\nyou emerge into the top tier of a sprawling underground city.\n\nSeveral descending levels of chiseled stone buildings and byways lead ultimately to a\nbreathtaking palace carved into the rock far below.\n\nInnumerable dwarves throng the open spaces, working, playing and conversing.\n",
	0, false, false, false, true,
	true, false, false,
	false, false, false, true, 2, 4, 62, "[UC]", COL_BLOCK_GREY, COL_BLOCK_ORANGE};
	//N, S, E, W
	loc[2][4].enemies[0]=1;
	loc[2][4].enemies[1]=3;

	loc[3][4]={"River",
	"Rushing waters uncrossable on foot.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 0, 3, 4, 63, "[~~]",  153, 153};
	loc[3][4].enemies[0]=0;

	loc[4][4]={"Riverbank",
	"Tall grasses turn to reeds and water lilies\nas the plains meet a river to the west.\n",
	10, false, false, false, false,
	false, false, false,
	1, 0, 1, 0, 4, 4, 64, "[~G]", 153, 102};
	loc[4][4].enemies[0]=3;
	loc[4][4].enemies[1]=0;
	loc[4][4].enemies[2]=26;

	loc[5][4]={"Grassland Road",
	"A wide, grassy plain divided by a worn cobblestone road.\nThe road leads south into the city, or east across the plain.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 0, 5, 4, 65, "[G/]", 102, 102};
	loc[5][4].enemies[0]=5;
	loc[5][4].enemies[1]=7;
	loc[5][4].enemies[2]=35;

	loc[6][4]={"Grassland Road",
	"A wide, grassy plain divided by a worn cobblestone road.\nThe road travels east-west across the plain.\n",
	10, false, false, false, false,
	false, false, false,
	1, 0, 1, 1, 6, 4, 66, "[G-]", 102, 102};
	loc[6][4].enemies[0]=5;
	loc[6][4].enemies[1]=7;
	loc[6][4].enemies[2]=4;

	loc[7][4]={"Grassland Road",
	"A wide, grassy plain divided by a worn cobblestone road.\nThe road meets in a three-way intersection, with a\npennant-lined path leading east to a walled stone castle,\nand less decorated paths heading west or\nsouth across the plains.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 1, 7, 4, 67, "[GT]", 102, 102};
	loc[7][4].enemies[0]=5;
	loc[7][4].enemies[1]=7;
	loc[7][4].enemies[2]=4;

	loc[8][4]={"Castle Courtyard",
	"Passing through a wide main gate, you enter a bustling\ncourtyard. Groups of soldiers are training on the\nparade ground, marching and practicing\ncombat maneuvers. The stable is crowded\nwith servants and whinnying horses,\nand you can see the smoke and hear\nthe hammers of at least one smithy.\n",
	13, false, false, false, true,
	false, false, false,
	0, 0, 1, 1, 8, 4, 68, "[C1]", 102, 136};
	loc[8][4].enemies[0]=7;
	loc[8][4].enemies[1]=7;
	loc[8][4].enemies[2]=12;

	loc[9][4]={"Main Hall",
	"The castle's ornate foyer opens east into a wide\ndining hall, with two long tables end-to-end\non either side of a  blue carpet\nrunning the length of the hall. A stone archway\nat the east end of the hall leads to\nthe throne room, and an elegant\nstairway exits the north side of the foyer. \n",
	15, false, false, false, false,
	false, false, false,
	1, 0, 1, 1, 9, 4, 69, "[C2]", 136, 136};
	loc[9][4].enemies[0]=7;
	loc[9][4].enemies[1]=7;
	loc[9][4].enemies[2]=12;

	loc[10][4]={"Throne Room",
	"A long blue carpet ends at the foot of a grandiose\nand imposing ebony throne. Twin stone\nbalconies run the length of the room,\nsupported by evenly spaced stone\npillars. Set  back in the shadows on\nthe north wall is an iron-bound oak\ndoor, nearly hidden behind the pillars.\n",
	18, false, false, false, false,
	false, false, false,
	1, 0, 1, 1, 10, 4, 70, "[C3]", 136, 221};
	loc[10][4].enemies[0]=12;
	loc[10][4].enemies[1]=7;
	loc[10][4].enemies[2]=19;

    //3rd row from top

	loc[1][3]={"Swamp",
	"Mud squelches at your heels as you wade distastefully\nin the shadow of gnarled, bone-white trees.\n",
	10, false, false, false, false,
	false, false, false,
	1, 0, 1, 0, 1, 3, 71, "[S~]", 102, 102};
	loc[1][3].enemies[0]=15;
	loc[1][3].enemies[1]=26;
	loc[1][3].enemies[2]=36;

	loc[2][3]={"Swamp",
	"Mud squelches at your heels as you wade distastefully\nin the shadow of gnarled, bone-white trees.\nA crude palisade prevents travel north.\nThe swamps thin out to a rocky beach in the east.\n",
	10, false, false, false, false,
	false, false, false,
	//N S E W
	false, false, true, true, 2, 3, 72, "[S~]", 102, 102};
	loc[2][3].enemies[0]=15;
	loc[2][3].enemies[1]=26;
	loc[2][3].enemies[2]=36;

	loc[3][3]={"Lake Lomond, South",
	"Rowing heavily to cross the lake's choppy waters, you\nwipe the sweat from your eyes and pause for a moment, taking in\nthe heavy grey skies, dark waters, and stony beaches on\neither side, before throwing your weight against the oars once more.\n",
	10, false, false, false, false,
	false, false, false,
	1, 0, 1, 1, 3, 3, 73, "[Ls]", 17, 17};
	loc[3][3].enemies[0]=6;
	loc[3][3].enemies[1]=33;
	loc[3][3].enemies[2]=34;

	loc[4][3]={"Lakeside Tundra",
	"The frigid landscape slopes down gradually to the west,\nrocks and silt poking up through the permafrost, abruptly\nmeeting the edge of a tumultuous lake with a dilapidated jetty\nand a single rowboat that looks like it's seen better days.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 1, 4, 3, 74, "[~T]", 17, 255};
	loc[4][3].enemies[0]=9;
	loc[4][3].enemies[1]=26;
	loc[4][3].enemies[2]=27;

	loc[5][3]={"Tundra, Path's End",
	"Fields of grass and bushes to the south give way to a wintry tundra,\nthick snow smothering all but the hardiest of pines.\nThe path slowly peters out, forking to the west and north before\nbeing lost in the snow.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 1, 5, 3, 75, "[T-]", 102, 255};
	loc[5][3].enemies[0]=9;
	loc[5][3].enemies[1]=9;
	loc[5][3].enemies[2]=27;

	loc[6][3]={"Tundra",
	"The snow is shin-deep in some places, snowcapped rocks\nand evergreens dotting the otherwise dazzlingly white\nlandscape.\n",
	10, false, false, false, false,
	false, false, false,
	1, 0, 1, 1, 6, 3, 76, "[T_]", 119, 119};
	loc[6][3].enemies[0]=9;
	loc[6][3].enemies[1]=9;
	loc[6][3].enemies[2]=27;

	loc[7][3]={"Grassland",
	"Pale green blades sway in the wind. A foreboding cave mouth\nlooms in the natural stone wall to the east.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 1, 7, 3, 77, "[G_]", 102, 102};
	loc[7][3].enemies[0]=4;
	loc[7][3].enemies[1]=5;
	loc[7][3].enemies[2]=7;

	loc[8][3]={"Dark Cave",
	"Stumbling a few feet from the cave mouth, you discover that\nthe whole cave is nearly pitch-black. After a lengthy\nexploration, you learn the only exit is to the north,\nor back the way you came.\n",
	18, false, false, false, false,
	false, false, false,
	1, 0, 0, 1, 8, 3, 78, "[DC]", 0, 136};
	loc[8][3].enemies[0]=37;
	loc[8][3].enemies[1]=36;
	loc[8][3].enemies[2]=28;

    loc[9][3]={"Castle Ballroom",
	"Crystal chandeliers hang from a high, domed ceiling, illuminating a pristine\nmarble ballroom ringed by classical marble pillars. There is a raised stage for an\norchestra along one wall of the massive circular hall.\n",
	5, false, false, false, false,
	false, false, false,
	0, 1, 0, 0, 9, 3, 79, "[C4]", 136, 136};
	loc[9][3].enemies[0]=7;
	loc[9][3].enemies[1]=7;
	loc[9][3].enemies[2]=12;

    loc[10][3]={"Castle Dungeons",
	"A damp, moss-and-lichen coated stairwell descends deep under the castle.\nIt opens into a long, long-forgotten corridor lined with\nrusty iron bars and moldering piles of straw.\n",
	15, false, false, false, false,
	false, false, false,
	0, 1, 0, 0, 10, 3, 80, "[C5]", 136, 136};
	loc[10][3].enemies[0]=7;
	loc[10][3].enemies[1]=7;
	loc[10][3].enemies[2]=12;

    //2nd row from top

	loc[1][2]={"Swamp",
	"Mud squelches at your heels as you wade distastefully\nin the shadow of gnarled, bone-white trees.\nThere is a gap in the palisade wall to the east.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 0, 1, 2, 81, "[S~]", 102, 102};
	loc[1][2].enemies[0]=15;
	loc[1][2].enemies[1]=26;
	loc[1][2].enemies[2]=36;

    loc[2][2]={"Goblin Village",
	"Contained within a crude, splintering palisade wall, the Goblins'\nonly real settlement is about what one would expect. Rough mud huts,\nstill damp, provide the only shelter, though most of its denizens are clustered around\nscattered cookfires.\nLounging at the large central fire is an enormous armored goblin.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 0, 1, 2, 2, 82, "[GV]", 238, 238};
	loc[2][2].enemies[0]=1;
	loc[2][2].enemies[1]=1;
	loc[2][2].enemies[2]=10;
    loc[2][2].npcs[0]=nlist[9];

    loc[3][2]={"Lake Lomond, North",
	"You're maneuvering a single-sailed fishing vessel over Lake Lomond.\n\nThe water here is a little less turbulent than it is to the south.\nSnowflakes drift gently into the waves from steel-grey skies overhead.\nThe coastline and docks are faintly visible to the north.\n",
	12, false, false, false, false,
	false, false, false,
	1, 1, 0, 0, 3, 2, 83, "[Ln]", 51, 51};
	loc[3][2].enemies[0]=6;
	loc[3][2].enemies[1]=34;
	loc[3][2].enemies[2]=34;

    loc[4][2]={"Ice Fields",
	"Powdery snow in the east gives way to smooth, hard ice, a\nblinding expanse of it, ending in a sheer glacial cliff to the west,\noverlooking the chilly waters of Lake Lomond.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 0, 1, 4, 2, 84, "[I_]", 187, 187};
	loc[4][2].enemies[0]=9;
	loc[4][2].enemies[1]=9;
	loc[4][2].enemies[2]=27;

    loc[5][2]={"Tundra",
	"The snow is shin-deep in some places, snowcapped rocks\nand evergreens dotting the otherwise dazzlingly white\nlandscape.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 1, 5, 2, 85, "[T_]", 119, 119};
	loc[5][2].enemies[0]=9;
	loc[5][2].enemies[1]=9;
	loc[5][2].enemies[2]=27;

    loc[6][2]={"Tundra",
	"The snow is shin-deep in some places, snowcapped rocks\nand evergreens dotting the otherwise dazzlingly white\nlandscape.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 1, 1, 6, 2, 86, "[T_]", 119, 119};
	loc[6][2].enemies[0]=9;
	loc[6][2].enemies[1]=9;
	loc[6][2].enemies[2]=27;

	loc[7][2]={"Grassland",
	"A plain of tall grasses, rippling in the breeze.\n",
	10, false, false, false, false,
	false, false, false,
	1, 1, 0, 1, 7, 2, 87, "[G_]", 102, 102};
	loc[7][2].enemies[0]=4;
	loc[7][2].enemies[1]=35;
	loc[7][2].enemies[2]=7;

	loc[8][2]={"Nightmare Maze",
	"It's easy to imagine being lost forever in this pitch-black maze of caves and tunnels...\n",
	10, false, false, false, false,
	false, false, false,
	0, 1, 1, 0, 8, 2, 88, "[NM]", 136, 0};
	loc[8][2].enemies[0]=28;
	loc[8][2].enemies[1]=36;
	loc[8][2].enemies[2]=30;

	loc[9][2]={"Lava Plain",
	"Every breath sears your lungs. Sweat drips from your nose and sizzles on the scorching stone.\nA sulphuric haze clouds the air, flakes of ash drifting past you like snow.\n",
	10, //enemy chance
	false, false, false, false, //water, wood, mine, smithy
	false, false, false, //armory, merchant, potion shop
	1, 0, 1, 1, //north, south, east, west
	9, 2, 89, "[L_]", 67, 67};
	loc[9][2].enemies[0]=31;
	loc[9][2].enemies[1]=8;
	loc[9][2].enemies[2]=18;

	loc[10][2]={"Lava Plain",
	"Every breath sears your lungs. Sweat drips from your nose and sizzles on the scorching stone.\nA sulphuric haze clouds the air, flakes of ash drifting past you like snow.\nA monstrous shadow looms to the north, constant rumblings punctuated by flashes\nof crimson light at the mountain's heights.\n",
	10, false, false, false, false,
	false, false, false,
	1, 0, 0, 1, 10, 2, 90, "[L_]", 67, 67};
	loc[10][2].enemies[0]=31;
	loc[10][2].enemies[1]=8;
	loc[10][2].enemies[2]=18;

	//Top row

	loc[1][1]={"Vampsect Lair",
	"The muggy air vibrates with the incessant buzzing of hundreds\nof insects. Swallowing bile, you survey the dozens of large cocoons and piles\nof squidgy eggs with disgust.\nThere is a pile of oil-soaked wood in the center of the nest, surrounded by bleached bones.\n",
	10, false, false, false, false,
	false, false, false,
	0, 1, 1, 0, 1, 1, 91, "[VL]", 67, 102};
	loc[1][1].enemies[0]=15;
	loc[1][1].enemies[1]=15;
	loc[1][1].enemies[2]=16;

	loc[2][1]={"Swamp",
	"Mud squelches at your heels as you wade distastefully\nin the shadow of gnarled, bone-white trees.\nA crude palisade wall prevents travel southward.\n",
	10, false, false, false, false,
	false, false, false,
	0, 0, 1, 1, 2, 1, 92, "[S~]", 102, 102};
	loc[2][1].enemies[0]=15;
	loc[2][1].enemies[1]=26;
	loc[2][1].enemies[2]=36;

	loc[3][1]={"Winterhold",
	"The fetid swamps recede into a snow-laden countryside, evergreens clustering around the simple log buildings\nof Winterhold village.\nSnow-brushed cobblestone streets mute the chatter of townsfolk bundled in coats and scarves.\nA handful of fishing vessels approach the chilly docks from the south, single sails visible on the lake horizon.\n",
	0, 1, 1, false, false,
	false, false, false,
	0, 1, 0, 1, 3, 1, 93, "[WH]", 255, 255};
	loc[3][1].enemies[0]=15;
	loc[3][1].enemies[1]=26;
	loc[3][1].enemies[2]=36;
	loc[3][1].npcs[0]=nlist[19];
	loc[3][1].npcs[1]=nlist[20];

	loc[4][1]={"Mountain",
	"Steep, stony cliffs gather into a jagged, snowladen peak miles above.\n",
	10, false, 0, 1, false,
	false, false, false,
	0, 1, 0, 0, 4, 1, 94, "[M_]", 136, 136};
	loc[4][1].west = true;
	loc[4][1].enemies[0]=37;
	loc[4][1].enemies[1]=39;
	loc[4][1].enemies[2]=27;

	loc[5][1]={"Glacial Palace",
	"Deep silence muffles the wailing winds outside.\nSoft light filters through the ice far above, reflecting ephemerally\nfrom frozen staircases, pillars, delicate stone murals, and ancient halls,\narrayed around what seems to have once been a vast court, now barely visible in deep snowdrifts and pristine ice.\n",
	20, 0, 0, 0, 0,
	false, false, false,
	0, 1, 0, 0, 5, 1, 95, "[GP]", 187, 187};
	loc[5][1].enemies[0]=17;
	loc[5][1].enemies[1]=17;
	loc[5][1].enemies[2]=17;

	loc[6][1]={"Tundra",
	"The snow is shin-deep in some places, snowcapped rocks\nand evergreens dotting the otherwise dazzlingly white landscape.\n",
	10, false, false, false, false,
	false, false, false,
	0, 1, 1, 0, 6, 1, 96, "[T_]", 119, 119};
	loc[6][1].enemies[0]=9;
	loc[6][1].enemies[1]=9;
	loc[6][1].enemies[2]=27;

	loc[7][1]={"Frost's Eyrie",
	"Steep, stony cliffs gather into a jagged, snowladen peak miles above.\nAn ancient-looking stone tower is perched at the pinnacle.\n",
	10, 0, 0, 1, 0,
	false, false, false,
	0, 1, 0, 1, 7, 1, 97, "[M_]", 119, 136};
	loc[7][1].enemies[0]=37;
	loc[7][1].enemies[1]=39;
	loc[7][1].enemies[2]=27;

	loc[8][1]={"Hidden Jungle",
	"This dense forest has truly escaped the ravages of time, a vestige of ages primordial.\nUnfamiliar beast calls reverberate through ancient, vine-wreathed trunks.\n",
	15, 0, 1, 0, 0,
	false, false, false,
	0, 0, 1, 0, 8, 1, 98, "[J_]", 170, 102};
	loc[8][1].npcs[0] = comp_npc[1];
	loc[8][1].enemies[0]=44;
	loc[8][1].enemies[1]=45;
	loc[8][1].enemies[2]=46;

	loc[9][1]={"Lava Plain",
	"Every breath sears your lungs. Sweat drips from your nose and sizzles on the scorching stone.\nA sulphuric haze clouds the air, flakes of ash drifting past you like snow.\nTo the east, a the glowing crown of a steep volcano is visible through the miasma.\n",
	10, false, false, false, false,
	false, false, false,
	0, 1, 1, 1, 9, 1, 99, "[L_]", 68, 68};
	loc[9][1].enemies[0]=31;
	loc[9][1].enemies[1]=8;
	loc[9][1].enemies[2]=18;

	loc[10][1]={"Mountain of Doom",
	"Broken, smoldering crags zigzag between blazing rivers of molten stone.\nStanding at the precipice of the rumbling volcano, awash in shimmering heat waves, the world is spread out beneath you,\ndistant clouded peaks like fluffs of cotton in a patchwork quilt of verdant forests, glittering rivers, and golden plains.\n",
	10, false, false, false, false,
	false, false, false,
	0, 1, 0, 1, 10, 1, 100, "[V_]", 68, 204};
	loc[10][1].enemies[0]=18;
	loc[10][1].enemies[1]=8;
	loc[10][1].enemies[2]=25;

	for(int x=1;x<11;x++)
	{
		for(int y=1;y<11;y++)
		{
		    //populate blank data fields

			loc[x][y].loot=eq[0];
			loc[x][y].fire=false;
			if(loc[x][y].key=="")
				loc[x][y].key="[__]";
            loc[x][y].loc_shop=shops[0];

            loc[x][y].setIsOutside();

            loc[x][y].world = "Overworld";
            loc[x][y].loc_bldg=null_bldg;
            loc[x][y].loc_flora = plant[0];
            loc[x][y].loc_fauna = anim[0];

            if (loc[x][y].name=="City Center")
            {
                loc[x][y].loc_shop=shops[1];
            }
            if(loc[x][y].name=="Village")
            {
                loc[x][y].loc_shop=shops[2];
            }
            if (loc[x][y].name=="Underground City")
            {
                loc[x][y].loc_shop=shops[7];
                loc[x][y].local_shops.push_back( shops[8] );
            }
            if(loc[x][y].name=="City Gate North")
            {
                loc[x][y].loc_shop=shops[3];
            }

            if(loc[x][y].name=="Hidden Jungle")
            {
                loc[x][y].fauna_types.push_back(anim[23]);//frillneck
                loc[x][y].flora_types.push_back(plant[17]);//giant fern
            }

            if (loc[x][y].name == "City Gate North" || loc[x][y].name == "City Center" || loc[x][y].name == "City Gate East" || loc[x][y].name ==  "City Gate West" || loc[x][y].name == "City Gate South"){
                loc[x][y].fauna_types.push_back(anim[21]);
                loc[x][y].fauna_types.push_back(anim[22]);
            }

			if(loc[x][y].wood && loc[x][y].name != "Hidden Jungle")
			{
				loc[x][y].flora_types.push_back(plant[1]);//medicinal herb
				loc[x][y].flora_types.push_back(plant[4]);//mushroom
				loc[x][y].flora_types.push_back(plant[7]);//apple
				loc[x][y].flora_types.push_back(plant[12]);//toadstool

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
				loc[x][y].fauna_types.push_back(anim[11]);//fox
				loc[x][y].fauna_types.push_back(anim[12]);//fairy
				loc[x][y].fauna_types.push_back(anim[16]);//bee
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
				loc[x][y].fauna_types.push_back(anim[19]);//crow
				loc[x][y].fauna_types.push_back(anim[18]);//wolf
			}
			if(loc[x][y].water)
            {
                loc[x][y].fauna_types.push_back(anim[13]);//bullfrog
				loc[x][y].fauna_types.push_back(anim[14]);//heron
				loc[x][y].fauna_types.push_back(anim[15]);//dragonfly
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
            }
			if(loc[x][y].name=="Sparse Forest"||loc[x][y].name=="Forest Path")
			{
				loc[x][y].fauna_types.push_back(anim[10]);//turkey
			}
			if(loc[x][y].name=="Tundra")
			{
				loc[x][y].flora_types.push_back(plant[2]);//snowflower

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[11]);//fox
			}
			if(loc[x][y].name=="Lava Plain")
			{
				loc[x][y].flora_types.push_back(plant[3]);//torchweed
				loc[x][y].fauna_types.push_back(anim[0]); //initialize fauna types
			}
			if(loc[x][y].name=="Grassland"||loc[x][y].name=="Grassland Path")
			{
				loc[x][y].flora_types.push_back(plant[5]);//redberry bush
				loc[x][y].flora_types.push_back(plant[6]);//green berry bush
				loc[x][y].flora_types.push_back(plant[9]);//lilies
				loc[x][y].flora_types.push_back(plant[11]);//dandelion

				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[6]);//hawk
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
				loc[x][y].fauna_types.push_back(anim[16]);//bee
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
				loc[x][y].fauna_types.push_back(anim[19]);//crow
				loc[x][y].fauna_types.push_back(anim[18]);//wolf
			}
			if(loc[x][y].mine)
			{
				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[4]);
				loc[x][y].fauna_types.push_back(anim[5]);
				loc[x][y].fauna_types.push_back(anim[6]);
			}
			if(loc[x][y].name=="Dark Cave"||loc[x][y].name=="Night Maze")
            {
                loc[x][y].fauna_types.push_back(anim[20]);
            }
		}
	}
}

#endif // TSF_AREAS_H_INCLUDED
