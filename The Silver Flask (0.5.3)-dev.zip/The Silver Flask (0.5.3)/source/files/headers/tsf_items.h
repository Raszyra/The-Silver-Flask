#pragma once

#ifndef TSF_ITEMS_H_INCLUDED
#define TSF_ITEMS_H_INCLUDED

#include "tsf_classes.h"

using namespace std;

void define_equipment()
{
	/*

	name, mat, type, ench, desc;
	matb, enchb; atkb; defb, s/d/i/l, wt; price, held; worn; id;

	*/

	eq[0]={
		"empty", "none", "none", "none",
		"none",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, false, false, 0};

	eq[1]={
		"tunic", "cloth", "armor", "none",
		"The simple clothing of your village.\nOffers no extra protection but\nkeeps you warm.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 5, false, false, 1};

	eq[2]={
		"club", "wooden", "weapon", "none",
		"A crude wooden cudgel carved from a knotted tree limb.\n",
		0, 0, 1, 0, 0, 0, 0, 0, 1, 5, false, false, 2};

	eq[3]={
		"dagger", "iron", "weapon", "none",
		"A short blade with a sharp point.\n",
		1, 0, 1, 0, 0, 0, 0, 0, 1, 10, false, false, 3};

	eq[4]={
		"dagger", "steel", "weapon", "none",
		"A razor sharp stiletto, perfect for stabbing.\n",
		2, 0, 1, 0, 0, 0, 0, 0, 1, 10, false, false, 4};
	eq[5]={
		"dagger", "mithril", "weapon", "none",
		"A short, leaf-shaped blade with a sharp point.\n",
		3, 0, 1, 0, 0, 0, 0, 0, 1, 10, false, false, 5};
	eq[6]={
		"shortsword", "wooden", "weapon", "none",
		"A short, straight-edged training sword.\n",
		0, 0, 1, 1, 0, 0, 0, 0, 1, 10, false, false, 6};
	eq[7]={
		"shortsword", "iron", "weapon", "none",
		"A short, straight-edged sword with a simple crossguard.\n",
		1, 0, 1, 1, 0, 0, 0, 0, 1, 20, false, false, 7};
	eq[8]={
		"shortsword", "steel", "weapon", "none",
		"A short, straight-edged sword, highly polished.\nThis one bears the imperial seal on its single-handed hilt;\nit must have belonged to a soldier.\n",
		2, 0, 1, 1, 0, 0, 0, 0, 1, 20, false, false, 8};
	eq[9]={
		"shortsword", "mithril", "weapon", "none",
		"A short, straight-edged sword.\nIts leaf-like shape and delicate scrollwork hint at the design's Elven origin.\n",
		3, 0, 1, 1, 0, 0, 0, 0, 1, 20, false, false, 9};
	eq[10]={
		"chainmail", "iron", "armor", "none",
		"Armor made of interlocked metal rings.\n",
		1, 0, 0, 1, 0, 0, 0, 0, 1, 20, false, false, 10};
	eq[11]={
		"chainmail", "steel", "armor", "none",
		"Armor made of interlocked metal rings.\n",
		2, 0, 0, 1, 0, 0, 0, 0, 1, 15, false, false, 11};
	eq[12]={
		"chainmail", "mithril", "armor", "none",
		"Armor made of interlocked metal rings.\n",
		3, 0, 0, 1, 0, 0, 0, 0, 1, 15, false, false, 12};

	eq[13]={
		"longsword", "wooden", "weapon", "none",
		"A two-handed training sword with a rough crosstree nailed above the hilt.\n",
		0, 0, 2, 1, 0, 0, 0, 0, 2, 10, false, false, 13};

	eq[14]={
		"longsword", "iron", "weapon", "none",
		"A long blade ideal for both offense and defense.\nA heavy iron pommel helps to offset its weight.\n",
		1, 0, 2, 1, 0, 0, 0, 0, 3, 20, false, false, 14};

	eq[15]={
		"longsword", "steel", "weapon", "none",
		"A long steel blade with a blue wire-wrapped hilt.\nA narrow channel down the spine makes it easier to wield.\n",
		2, 0, 2, 1, 0, 0, 0, 0, 3, 15, false, false, 15};

	eq[16]={
		"longsword", "mithril", "weapon", "none",
		"This skillfully forged blade hums quietly with ancient secrets.\n",
		3, 0, 2, 1, 0, 0, 0, 0, 3, 15, false, false, 16};

	eq[17]={
		"tunic", "leather", "armor", "none",
		"Rough leather armor that defends against light blows.\n",
		1, 0, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 17};

	eq[18]={
		"staff", "wooden", "weapon", "none",
		"A sturdy length of wood, useful for striking or spellcasting.\n",
		0, 0, 1, 0, 0, 0, 1, 0, 2, 10, false, false, 18};

	eq[19]={
		"staff", "crystal", "weapon", "none",
		"The gnarled limb of an old oak mounted with a polished crystal.\n",
		0, 1, 1, 1, 0, 0, 3, 0, 2, 45, false, false, 19};

	eq[20]={
		"staff", "diamond", "weapon", "none",
		"An ornately carved wooden staff.\nThe diamond at its tip glows with inner light.\n",
		0, 2, 2, 0, 0, 0, 4, 0, 2, 90, false, false, 20};

	eq[21]={
		"mage robes", "cloth", "armor", "none",
		"Robes woven with enchanted thread that give\nthe wearer a slight magical boost.\n",
		0, 1, 1, 0, 0, 0, 1, 0, 1, 20, false, false, 21};

	eq[22]={
		"charm", "wooden", "accessory", "none",
		"A simple wooden token said to bring its wearer good fortune.\n",
		0, 0, 0, 0, 0, 0, 0, 1, 1, 20, false, false, 22};

	eq[23]={
		"small shield", "wooden", "accessory", "none",
		"This extremely basic shield is just one large section of sturdy tree bark.\n",
		0, 0, 0, 1, 0, 0, 0, 0, 1, 15, false, false, 23};

	eq[24]={
		"small shield", "iron", "accessory", "none",
		"An extremely basic shield worn strapped to the forearm.\n",
		1, 0, 0, 1, 0, 0, 0, 0, 2, 25, false, false, 24};

	eq[25]={
		"small shield", "steel", "accessory", "none",
		"An extremely basic shield, well-oiled and embossed with the royal seal.\n",
		2, 0, 0, 1, 0, 0, 0, 0, 2, 20, false, false, 25};

	eq[26]={
		"small shield", "mithril", "accessory", "none",
		"An extremely basic shield.\nIt's lighter than it looks.\n",
		3, 1, 0, 1, 0, 0, 0, 0, 2, 20, false, false, 26};

	eq[27]={
		"kite shield", "iron", "accessory", "none",
		"A wide, kite-shaped shield bearing the heraldry of a local lord.\nIt defends well but is slightly cumbersome.\n",
		1, 0, 0, 2, 0, -1, 0, 0, 3, 35, false, false, 27};

	eq[28]={
		"kite shield", "steel", "accessory", "none",
		"A kite-shaped shield with a thick, embellished metal frame.\nA snarling metal lion on the front makes for excellent bashing.\n",
		2, 0, 0, 2, 0, -1, 0, 0, 4, 35, false, false, 28};

	eq[29]={
		"kite shield", "mithril", "accessory", "none",
		"A heavy, shining shield of ancient mithril, forged for a knight of great renown.\nA mind-bending pattern covers its surface.\n",
		3, 0, 0, 2, 0, -1, 0, 0, 4, 35, false, false, 29};

	eq[30]={
		"plate armor", "iron", "armor", "none",
		"Heavy armor made of fitted metal plates.\nFearsome-looking, it offers excellent defense,\nbut slows the wearer significantly.\n",
		1, 0, 0, 3, 0, -2, 0, 0, 5, 35, false, false, 30};

	eq[31]={
		"plate armor", "steel", "armor", "none",
		"Heavy armor made of fitted metal plates.\nThis particular set is of fine quality, likely for a knight or captain.\n",
		2, 0, 0, 3, 0, -2, 0, 0, 5, 35, false, false, 31};

	eq[32]={
		"plate armor", "mithril", "armor", "none",
		"Heavy armor made of fitted metal plates.\nWinged tips at the corners of the visor give the wearer a stately, streamlined look.\n",
		3, 0, 0, 3, 0, -2, 0, 0, 5, 35, false, false, 32};

	eq[33]={
		"wizard hat", "cloth", "accessory", "none",
		"A tall, pointed hat embellished with stars and planets.\nImbued with some magical potential, yet you\ncan't help but feel a bit silly wearing it.\n",
		0, 0, 0, 0, 0, 0, 2, 0, 1, 25, false, false, 33};

	eq[34]={
		"mage hood", "cloth", "accessory", "none",
		"This dark hood makes its wearer both mighty in\nmagic, and mighty mysterious.\n",
		0, 1, 0, 1, 0, 0, 2, 0, 1, 25, false, false, 34};

	eq[35]={
		"leather", "none", "cloth", "none",
		"Durable animal hide. Can be made into armor.\n",
		1, 0, 0, 0, 0, 0, 0, 0, 1, 15, false, false, 35};

	eq[36]={
		"wool", "none", "cloth", "none",
		"A knotted coil of spun wool, useful for making all kinds of clothing.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 36};

	eq[37]={
		"bar", "steel", "ore", "none",
		"An ingot of refined iron.\n",
		2, 0, 0, 0, 0, 0, 0, 0, 1, 15, false, false, 37};

	eq[38]={
		"burned fish", "none", "junk", "none",
		"Basically just bones and ash...\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 38};
eq[39]={
		"fish", "raw", "food", "none",
		"Just caught and oh so fresh!\n",
		0, 3, 0, 0, 0, 0, 0, 0, 1, 5, false, false, 39};
eq[40]={
		"cooked fish", "none", "food", "none",
		"The aroma is so mouthwatering you almost don't\nmind the bones.\n",
		0, 7, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 40};

	eq[41]={
		"burned meat", "none", "junk", "none",
		"It's mostly charcoal, but you'd hate to see it go to waste...\n",
		0, 1, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 41};
	eq[42]={
		"meat", "raw", "food", "none",
		"A slab of pure muscle, marbled with fat.\n",
		0, 5, 0, 0, 0, 0, 0, 0, 1, 5, false, false, 42};
	eq[43]={
		"cooked meat", "none", "food", "none",
		"A hunk of roasted meat, seasoned with woodland herbs.\n",
		0, 10, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 43};
	eq[44]={
		"ore", "mithril", "ore", "none",
		"Bluish metal that appears to glow faintly.\n",
		3, 1, 0, 0, 0, 0, 0, 0, 2, 10, false, false, 44};
	eq[45]={
		"coal", "none", "material", "none",
		"A terrible Yuletide present.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 5, false, false, 45};
	eq[46]={
		"crystal", "none", "gem", "none",
		"A translucent stone that catches the light.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 20, false, false, 46};
	eq[47]={
		"diamond", "none", "gem", "none",
		"This uncut clear gem sparkles brilliantly.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 40, false, false, 47};
	eq[48]={
		"ore", "iron", "ore", "none",
		"A lump of raw iron.\n",
		1, 0, 0, 0, 0, 0, 0, 0, 3, 10, false, false, 48};

	eq[49]={
		"wood", "none", "material", "none",
		"A piece of wood hewn from a tree.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 2, 5, false, false, 49};
	eq[50]={
		"emerald", "none", "gem", "none",
		"This uncut green gem sparkles brilliantly.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 50};

	eq[51]={
		"sapphire", "none", "gem", "none",
		"This uncut blue gem sparkles brilliantly.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 51};

	eq[52]={
		"ruby", "none", "gem", "none",
		"This uncut red gem sparkles brilliantly.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 52};

	eq[53]={
		"amethyst", "none", "gem", "none",
		"This uncut purple gem sparkles brilliantly.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 53};

	eq[54]={
		"ore", "silver", "ore", "none",
		"A colorless, reflective metal used for making jewelry.\n",
		1, 1, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 54};

	eq[55]={
		"ore", "golden", "ore", "none",
		"Highly valued, lustrous yellowish metal used for jewelry;\nif only you had the molds to make imperial gold pieces...\n",
		2, 2, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 55};

	eq[56]={
		"shortbow", "wooden", "weapon", "none",
		"A sturdy, recurved bow used for hunting\nor mid-range combat.\n",
		0, 0, 2, 0, 0, 0, 0, 0, 3, 35, false, false, 56};

	eq[57]={
		"longbow", "wooden", "weapon", "none",
		"Almost as tall as you are, this slim bow\nexcels in long-ranged combat.\n",
		0, 0, 4, 0, 0, 0, 0, 0, 3, 70, false, false, 57};

	eq[58]={
		"smallshield", "leather", "accessory", "none",
		"An extremely basic shield, made of cured hide stretched over a wooden frame.\n",
		0, 0, 0, 1, 0, 0, 0, 0, 1, 15, false, false, 58};

	eq[59]={
		"bladed gauntlet", "iron", "accessory", "none",
		"Lethal-looking arm guard with a razor-sharp blade\nalong the outer edge.Perfect for those\nwho prefer hand-to-hand combat.\n",
		1, 0, 2, 1, 0, 0, 0, 0, 2, 60, false, false, 59};

	eq[60]={
		"bladed gauntlet", "steel", "accessory", "none",
		"Lethal-looking arm guard with a razor-sharp blade\nalong the outer edge.Perfect for those\nwho prefer hand-to-hand combat.\n",
		2, 0, 2, 1, 0, 0, 0, 0, 2, 60, false, false, 60};

	eq[61]={
		"bladed gauntlet", "mithril", "accessory", "none",
		"Lethal-looking arm guard with a razor-sharp blade\nalong the outer edge.Perfect for those\nwho prefer hand-to-hand combat.\n",
		3, 0, 2, 1, 0, 0, 0, 0, 2, 60, false, false, 61};

	eq[62]={
		"medicinal herb", "none", "herb", "none",
		"A wad of bright green, sweet-smelling leaves.\nThe taste is bitter, but it's said to cure all ailments.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 10, false, false, 62};

	eq[63]={
		"bucket", "wooden", "container", "none",
		"A wooden bucket strengthened with iron bands.\nUseful for carrying things.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 2, 10, false, false, 63};

	eq[64]={
		"bottle", "glass", "container", "none",
		"A rounded glass bottle with a wooden stopper.\nUsed for storing liquids.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 64};

	eq[65]={
		"vial", "wooden", "container", "none",
		"A small vial carved from oak.\nIt's waterproofed, for carrying liquids.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 65};

	eq[66]={
		"block", "stone", "material", "none",
        "A hefty chunk of cut grey stone.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 5, 1, false, false, 66};

	eq[67]={
		"scroll", "paper", "scroll", "none",
"A crisp roll of parchment, tied neatly with a black ribbon.\n",
		0, 2, 0, 0, 0, 0, 0, 0, 0, 100, false, false, 67};

	eq[68]={
		"book", "spell", "book", "none",
"A thick, precise encyclopedic guide to using a certain ability.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 100, false, false, 68};

	eq[69]={
		"book", "skill", "book", "none",
"A detailed handwritten book, comprised of\nnotes written by many masters over many years.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 50, false, false, 69};

	eq[70]={
		"feather", "none", "material", "none",
"A straight, undamaged feather plucked from a dead bird.\nUseful for fletching or writing.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 1, false, false, 70};

eq[71]={
		"", "", "", "none",
		".\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 1, false, false, 71};
eq[72]={
		"horsebreaker sword", "iron", "weapon", "none",
		"An immense single-edged blade measuring a meter and a half long.\nIt is forged of solid iron and nearly impossible to lift;\nthey say one stroke could cleave through man and horse and earth alike.\n",
		1, 0, 10, 3, -2, -2, 0, 0, 11, 100, false, false, 72};

eq[73]={
		"apple", "tsir", "food", "none",
		"A crunchy, sweet fruit with blood-red skin and a woody core.\n",
		0, 5, 0, 0, 0, 0, 0, 0, 1, 3, false, false, 73};
eq[74]={
		"ash", "grey", "flower", " none",
		"The crumbling remains of something that has burned.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 1, false, false, 74};
eq[75]={
		"core", "molten", "accessory", "fire",
		"This craggy, pulsating object dropped from the heart of a living lava flow.\n You're not sure what it does, but you can feel immense heat within it.\n",
		0, 2, 0, 0, 0, 0, 0, 0, 1, 25, false, false, 75};

eq[76]={
		"feathersong", "none", "weapon", "wind",
		"An ornately carved bow. Its polished whitewood whorls remind one of drifting clouds and pacific skies.\n",
		2, 1, 4, 0, 0, 1, 0, 1, 1, 300, false, false, 76};

eq[77]={
		"broad-axe", "steel", "weapon", "none",
		"A broad-bladed war axe fashioned in the style of the Dwarves.\n",
		2, 0, 3, 0, 1, 0, 0, 0, 5, 30, false, false, 77};

eq[78]={
		"mail", "dwarven", "armor", "none",
		"This chainmail hauberk is crafted with Dwarven expertise;\nits interlocked ringlets are an eye-catching alloy\nof steel and gold.\n",
		2, 0, 0, 3, 1, 0, 0, 2, 5, 35, false, false, 78};

eq[79]={
		"helm", "dwarven", "accessory", "none",
		"A steel full-helm decorated with gold crest and trim.\nIt bears the insignia of Dwarven nobility embossed in gold\non each side.\n",
		2, 0, 0, 1, 1, 0, 0, 0, 3, 35, false, false, 79};

eq[80]={
		"cloak", "woolen", "accessory", "none",
		"A heavy grey cloak that can be worn over armor.\nCan protect against very light blows.\n",
		0, 0, 0, 1, 0, 0, 0, 0, 1, 15, false, false, 80};

eq[81]={
		"cloak", "elven", "accessory", "none",
		"An airy, forest green cloak that can be worn over armor.\nThe material is light but extremely strong, and seems\ndappled with subtly moving shadows, as though caught\nin sunlight filtered through leafy treetops.\n",
		2, 0, 0, 1, 0, 1, 0, 0, 1, 50, false, false, 81};
eq[82]={
		"flute", "wooden", "instrument", "none",
		"An inexpertly carved wooden flute. Its pure sound belies the rough edges.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 82};
eq[83]={
		"berry", "red", "food", "none",
		"These small round berries are tart, but sweet.\n",
		0, 5, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 83};
eq[84]={
		"berry", "green", "food", "none",
		"Hard to chew and unbelievably sour, but nonetheless invigorating.\n",
		0, 4, 3, 0, 0, 0, 0, 0, 0, 20, false, false, 84};
eq[85]={
		"wheat", "none", "misc", "none",
		"A bushel of golden stalks and grains, tied around the middle.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 10, false, false, 85};
eq[86]={
		"flour", "none", "misc", "none",
		"A sack of finely ground whole-wheat flour.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 86};
eq[87]={
		"pie", "redberry", "food", "none",
		"Golden, flaky crust, thick fruit filling, and a mouthwatering aroma. Reminds you of home.\n",
		0, 20, 0, 0, 0, 0, 0, 0, 0, 30, false, false, 87};
eq[88]={
		"pie", "greenberry", "food", "none",
		"Golden, flaky crust, thick fruit filling, and a mouthwatering aroma.\nReminds you of home.\n",
		0, 10, 10, 0, 0, 0, 0, 0, 0, 35, false, false, 88};
eq[89]={
		"pie", "burnt", "misc", "none",
		"It's a crumbling mess...what a shame.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, false, false, 89};
eq[90]={
		"bread", "none", "food", "none",
		"A warm loaf of perfectly baked bread.\n",
		0, 10, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 90};
eq[91]={
		"bread", "burnt", "misc", "none",
		"Could have been delicious.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, false, false, 91};
eq[92]={
		"amulet", "silver", "accessory", "none",
		"A simply wrought silver pendant, set with a small gemstone.\n",
		1, 0, 0, 0, 0, 0, 0, 0, 0, 40, false, false, 92};
eq[93]={
		"amulet", "golden", "accessory", "none",
		"An elegant golden medallion, set with a large gemstone.\n",
		2, 0, 0, 0, 0, 0, 0, 0, 0, 60, false, false, 93};
eq[94]={
		"egg", "none", "food", "none",
		"An ovoid delicacy. You could eat it raw, but you'd rather not.\n",
		0, 5, 0, 0, 0, 0, 0, 0, 0, 2, false, false, 94};

eq[95]={
		"rapier", "iron", "weapon", "none",
		"A long, thin blade meant for piercing. It is oddly flexible.\n",
		1, 0, 1, 0, 0, 1, 0, 0, 1, 40, false, false, 95};

eq[96]={
		"rapier", "steel", "weapon", "none",
		"A long, thin blade meant for piercing.\nA simple basket hilt protects the wielder's hand.\n",
		2, 0, 1, 0, 1, 1, 0, 0, 1, 30, false, false, 96};

eq[97]={
		"rapier", "mithril", "weapon", "none",
		"A long, thin blade meant for piercing.\nIts silver-blue blade and ornate basket hilt\nare inscribed with graven runes.\n",
		3, 0, 1, 0, 1, 1, 0, 0, 1, 40, false, false, 97};

eq[98]={
		"rapier", "gilded", "weapon", "none",
		"A long, thin blade meant for piercing.\nThis is a display piece, inlaid with gold and hardly dangerous,\nthough highly valued by collectors.\n",
		1, 2, 0, 0, 0, 1, 0, 0, 1, 80, false, false, 98};

eq[99]={
		"Echo", "Rime", "weapon", "ice",
		"The legendary rapier of a blademaster from the north.\nIts tapered blade is crusted with ice.\n",
		2, 2, 7, 0, 0, 0, 0, 0, 0, 150, false, false, 99};

eq[100]={
		"Grimault", "none", "weapon", "dark",
		"An absurdly heavy two-handed sword.\n",
        1, 2, 5, 5, 0, 0, 0, 0, 0, 145, false, false, 100};

eq[101]={
		"Cloak", "Whisperwind", "accessory", "wind",
		"A gossamer cloak embroidered with glittering patterns.\nThis unexpectedly hardy garment once belonged to an elusive hero.\n",
        0, 2, 0, 2, 0, 3, 1, 0, 0, 900, false, false, 101};

eq[102]={
		"slime", "none", "food", "none",
		"A viscous glob of green slime. Probably not safe for consumption.\n",
        0, -5, 0, 0, 0, 0, 0, 0, 0, 1, false, false, 102};

eq[103]={
		"snowflower", "none", "food", "none",
		"A cluster of small blue flowers with elegant, tapered petals.\nThey seem to shimmer faintly.\n",
        0, 0, 10, 0, 0, 0, 0, 0, 0, 20, false, false, 103};

eq[104]={
		"torchweed", "none", "food", "none",
		"A hardy orange bloom on a long, reedy stalk. It smells faintly of sulfur.\n",
        0, 8, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 104};

eq[105]={
		"mushroom", "none", "food", "none",
		"A fragrant forest mushroom, edible by itself but really shines in stew or stir-fry.\n",
        0, 4, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 105};

eq[106]={
		"pot", "iron", "container", "none",
		"A sturdy metal pot for cooking.\n",
        1, 0, 0, 1, 0, 0, 0, 0, 5, 20, false, false, 106};

eq[107]={
		"potato", "burnt", "misc", "none",
		"A charred lump.\n",
        0, 0, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 107};

eq[108]={
		"potato", "raw", "food", "none",
		"A dense, fibrous vegetable. Makes a good stew.\n",
        0, 2, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 108};

eq[109]={
		"potato", "baked", "food", "none",
		"A steaming, soft potato, perfectly cooked and seasoned with woodland herbs.\n",
        0, 8, 0, 0, 0, 0, 0, 0, 0, 10, false, false, 109};

eq[110]={
		"carrot", "none", "food", "none",
		"A crunchy, sweet orange vegetable.\n",
        0, 4, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 110};

eq[111]={
		"burnt corn", "none", "junk", "none",
		"Someone attempted to roast this ear of corn,\nbut only succeeded in destroying it.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 111};

eq[112]={
		"corn", "raw", "food", "none",
		"An ear of sweet corn, fresh from the field.\n",
		0, 3, 0, 0, 0, 0, 0, 0, 1, 5, false, false, 112};

eq[113]={
		"corn", "roast", "food", "none",
		"An ear of farm-fresh corn, roasted over a fire and slathered with salt and butter.\n",
		0, 7, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 113};

eq[114]={
		"katana", "iron", "weapon", "none",
		"A curved, single-edged longsword.\n",
		1, 0, 2, 1, 0, 0, 0, 0, 3, 30, false, false, 114};

eq[115]={
		"hat", "straw", "accessory", "none",
		"A simple straw hat to keep the rain off. It's from a foreign land.\n",
		0, 0, 0, 1, 0, 0, 0, 0, 1, 12, false, false, 115};

eq[116]={
		"obi", "cloth", "accessory", "none",
		"A simple sash intended to close one's robe.\nYou can stash a weapon in it.\n",
		0, 7, 0, 0, 0, 0, 0, 0, 1, 20, false, false, 116};

eq[117]={
		"rose", "red", "flower", "none",
		"An elegant, spiraling flower with velvety red petals and a uniquely full-bodied fragrance.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 117};

eq[118]={
		"lilac", "pink", "flower", "none",
		"A vibrant pink flower with six radial petals and a fresh, honeyed scent.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 118};

eq[119]={
		"iris", "purple", "flower", "none",
		"A demure, soft-petaled flower of deep, mysterious purple.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 119};

eq[120]={
		"lobelia", "blue", "flower", "none",
		"A bundle of small, light blue flowers, charming and highly toxic.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 120};

eq[121]={
		"dandelion", "yellow", "flower", "none",
		"A small, yellow flower with dozens of tiny petals and a sweet, slightly sour, cut-grass scent.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 121};

eq[122]={
		"pie", "apple", "food", "none",
		"A perfectly baked pastry with a golden crust and sweet apple filling.\n",
		0, 25, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 122};

eq[123]={
		"pie", "meat", "food", "none",
		"A savory pie with a flaky, golden crust and delicious meat and gravy filling.\n",
		0, 35, 0,  0, 0, 0, 0, 0, 0, 15, false, false, 123};

eq[124]={
		"cake", "none", "food", "whole",
		"A fluffy, moist, layered cake, sprinkled with sugar and decorated with flower petals. \n",
		0, 25, 0, 0, 0, 0, 0, 0, 0, 40, false, false, 124};

eq[125]={
		"gorse", "yellow", "flower", "none",
		"A small but fragrant yellow flower.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 125};

eq[126]={
		"recipe", "none", "none", "none",
		"A weathered bit of parchment with a proprietary mix listed on it.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 1, false, false, 126};

eq[127]={
		"roe", "fish", "food", "none",
		"A clutch of fish eggs, a delicacy in some parts of the world.\n",
		0, 4, 0, 0, 0, 0, 0, 0, 0, 35, false, false, 127};

eq[128]={
		"bun", "sweet", "food", "none",
		"A small, fluffy pastry covered in a sweet glaze.\nMade using a delicious secret recipe.\n",
		0, 4, 0, 0, 0, 0, 0, 0, 1, 20, false, false, 128};

eq[129]={
		"sunflower", "yellow", "flower", "none",
		"A tall, radiant flower with a large,\ndark center and a faint but unique scent.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 5, false, false, 129};

eq[130]={
		"lute", "wooden", "instrument", "none",
		"This six-stringed instrument is strummed with one hand\nwhile the other holds the strings, producing a\nclear, flexible melody.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 25, false, false, 130};

eq[131]={
		"harp", "wooden", "instrument", "none",
		"A simple stringed instrument.\nRun your fingers lightly across the strings to\nproduce an ethereal melody.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 20, false, false, 131};

eq[132]={
		"spear", "iron", "weapon", "none",
		"The world's most ubiquitous weapon.\nConsists of a sharp point and a long shaft for maximum reach.\n",
		1, 0, 1, 0, 0, 0, 0, 0, 0, 25, false, false, 132};

eq[133]={
		"spear", "steel", "weapon", "none",
		"The world's most ubiquitous weapon.\nThis one has a stylish tassel hanging from the point\nfor soaking up the blood of your enemies.\n",
		2, 0, 1, 0, 0, 0, 0, 0, 0, 30, false, false, 133};

eq[134]={
		"spear", "mithril", "weapon", "none",
		"The world's most ubiquitous weapon.\nA stylized, inscripted point of sheerest metal belies its strength.\n",
		2, 1, 1, 0, 0, 0, 0, 0, 0, 30, false, false, 134};

eq[135]={
		"ore", "iridium", "ore", "none",
		"A greyish lump of metal that reflects a rainbow of colors in bright light.\n",
		1, 2, 0, 0, 0, 0, 0, 0, 0, 30, false, false, 135};

eq[136]={
		"broad-shield", "wooden", "accessory", "none",
		"A simple, wide shield made of joined planks.\nIt offers a versatile defense, especially against light projectiles.\n",
		0, 0, 0, 2, 0, 0, 0, 0, 0, 30, false, false, 136};

eq[137]={
		"spear", "wooden", "weapon", "none",
		"The world's most ubiquitous weapon.\nSturdy but hastily made, this simple weapon is little more than a sharpened pole.\n",
		0, 0, 1, 0, 0, 0, 0, 0, 0, 5, false, false, 137};

eq[138]={
		"spearhead", "iron", "misc", "none",
		"A socketed, leaf-shaped blade with a sharp point.\nCan be attached to a pole to craft a deadly spear.\n",
		1, 0, 0, 0, 0, 0, 0, 0, 0, 15, false, false, 138};

eq[139]={
		"onion", "sweet", "food", "none",
		"This crunchy, layered vegetable is often used to demonstrate complexity in metaphor.\nIt comes in a papery skin, and the sweet flavor is edged with sharp bitterness.\n",
		0, 4, 1, 0, 0, 0, 0, 0, 1, 15, false, false, 139};

eq[140]={
		"armor", "leather", "armor", "none",
		"A protective garment made from hard-boiled leather.\nAdjustable straps make it comfortable and easy to wear.\n",
		0, 0, 0, 2, 0, 0, 0, 0, 0, 30, false, false, 140};

eq[141]={
		"cattail", "none", "plant", "none",
		"A tall, spike-tipped reed that grows near lakes and ponds.\nA thick cylinder of densely packed seed fluff near the top\ngives it the appearance of a cat's tail, swaying in the wind.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 30, false, false, 141};

eq[142]={
		"bone", "sturdy", "material", "none",
		"An extraordinarily strong bone taken from the corpse of a primordial beast.\n",
		1, 0, 0, 0, 0, 0, 0, 0, 1, 120, false, false, 142};

eq[143]={
		"wakizashi", "iron", "weapon", "none",
		"A slightly curved, single-edged shortsword with a sharp, angular point for stabbing.\nIn the land of its origin, it is often used as companion to a longer blade.\n",
		1, 0, 1, 0, 0, 0, 0, 0, 2, 20, false, false, 143};

eq[144]={
		"wakizashi", "steel", "weapon", "none",
		"A slightly curved, single-edged shortsword with a sharp, angular point for stabbing.\nThis finely crafted companion blade bears the seal of a noble house.\n",
		2, 0, 1, 0, 0, 0, 0, 0, 3, 25, false, false, 144};

eq[145]={
		"wakizashi", "mithril", "weapon", "none",
		"This is a masterwork replica of a foreign style; delicate tooling\nalong the spine catches the light in whorling patterns.\nA serene silk tassel hangs from the single-handed hilt.\n",
		3, 0, 2, 0, 0, 0, 0, 0, 2, 40, false, false, 145};

eq[146]={
		"splintmail", "iron", "armor", "none",
		"Armor made of metal plates affixed to a leather doublet.\n",
		1, 0, 0, 2, 0, 0, 0, 0, 3, 45, false, false, 146};

eq[147]={
		"splintmail", "steel", "armor", "none",
		"Armor made of polished metal plates affixed to a leather doublet.\nAn insignia on the chest denotes the wearer a member of the\n'Crossed Swords Mercenary Company.'\n",
		2, 0, 0, 2, 0, 0, 0, 0, 3, 45, false, false, 147};

eq[148]={
		"mace", "iron", "weapon", "none",
		"This crude weapon is basically just a spiked iron ball on the end of a club.\Hard to think of a more effective bashing instrument.\n",
		1, 0, 2, -1, 0, 0, 0, 0, 2, 30, false, false, 148};

eq[149]={
		"mace", "steel", "weapon", "none",
		"A steel mace with a stylized flanged head.\n",
		2, 0, 3, -1, 0, 0, 0, 0, 3, 45, false, false, 149};

eq[150]={
		"mace", "mithril", "weapon", "none",
		"A battle-scarred mace with subtle beauty. Gouges in the metal\nbreak the careful patterns etched into its blued flanges.\nA torn strip of banner hangs from the hilt, testament to a heroic past.\n",
		3, 0, 3, -1, 0, 0, 0, 0, 2, 60, false, false, 150};

eq[151]={
		"fowl", "burnt", "junk", "none",
		"It's just scraps of charcoal wrapped around\na blackened drumstick. What a waste.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 1, false, false, 151};

eq[152]={
		"fowl", "raw", "food", "none",
		"A raw leg of some kind of bird.\n",
		0, 3, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 152};

eq[153]={
		"fowl", "cooked", "food", "none",
		"A leg of some kind of bird, roasted to perfection -\ncrispy skin releases savory juices and a mouthwatering aroma.\n",
		0, 3, 0, 0, 0, 0, 0, 0, 1, 20, false, false, 153};

eq[154]={
		"scimitar", "iron", "weapon", "none",
		"A broad, curved blade from the warm southern sands.\n",
		1, 0, 2, 1, 0, 1, 0, 0, 1, 30, false, false, 154};

eq[155]={
		"scimitar", "steel", "weapon", "none",
		"A curved one-handed blade with a stylish, s-shaped crossguard and red-silk-wrapped hilt.\n",
		2, 0, 2, 1, 0, 1, 0, 0, 1, 30, false, false, 155};

eq[156]={
		"scimitar", "mithril", "weapon", "none",
		".\n",
		3, 0, 2, 1, 0, 1, 0, 0, 1, 30, false, false, 156};


/*=======================================*/
/*#######################################*/
//=======================================
/*### QUEST ITEMS / UNAVAILABLE ITEMS ###*/
//=======================================
/*#######################################*/
/*=======================================*/



eq[201]={
		"lance", "dragonslayer", "weapon", "poison",
		"A hefty iron spear, in excellent condition despite its advanced age.\nYou retrieved it from the back of a dragon, and used it to finish the job.\n",
        10, 1, 2, 0, 0, 1, 1, 1, 1, 2000, false, false, 201};

    eq[202]={
		"blade", "moonbeam", "weapon", "starlight",
		"This glimmering steel blade is forged in the pattern of delicate wings,\nits hilt woven with metal leaves and flowers.\n",
		3, 5, 7, 3, 0, 3, 1, 3, 1, 1000, false, false, 202};

    eq[203]={
		"dust", "fairy", "misc", "none",
		"A seemingly simple pouch full of glittering powder.\nIt tinkles slightly when shaken.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 1000, false, false, 203};

    eq[204]={
		"wings", "gossamer", "accessory", "starlight",
		"These delicate, patterned membranes are alight with the swirling colors of the aurora.\nAbout the size of a pair of butterfly wings, they grow when worn.\nThey make you feel...lighter.\n",
		0, 0, 0, 0, 0, 10, 1, 7, 1, 1000, false, false, 204};

    eq[205]={
		"rope", "none", "misc", "none",
		"A length of braided material for securing or tying.\nIt's pretty tough.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 15, false, false, 205};

    eq[206]={
		"net", "none", "misc", "none",
		"A mesh of woven material, made for catching things.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 20, false, false, 206};

    eq[207]={
		"torch", "sacred", "accessory", "holy",
		"The handle of this lovingly carved ivory torch is well-worn,\nas though many hands have carried it over the years.\n",
		0, 4, 0, 0, 0, 0, 0, 0, 1, 120, false, false, 207};

    eq[208]={
		"torch", "foul", "accessory", "poison",
		"A crude-looking pine torch, its flame a sickly, sputtering green.\nRolls of oily black smoke waft from it.\n",
		0, 3, 0, 0, 0, 0, 0, 0, 1, 30, false, false, 208};

    eq[209]={
		"stone", "smooth", "accessory", "none",
		"A humble stone, worn smooth in a river.\nIf you listen very closely it seems to emit a clear, high tone.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 209};

    eq[210]={
		"coin", "slayer", "misc", "none",
		"A silver coin, stamped on each side with the emblem of a striking snake.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 210};

    eq[211]={
		"scale", "dragon", "ore", "none",
		"A thick plate of organic metal armor\nwith a structure similar to chitin.\nBetween jagged ridges and crags on the scale's surface,\na dull reflection can be seen of new metal underneath.\n",
		5, 1, 0, 0, 1, 0, 0, 0, 10, 50, false, false, 211};

    eq[272]={
		"coif", "blessed", "accessory", "light",
		"A chainmail coif that shines ethereally.\n",
		0, 2, 0, 2, 0, 0, 0, 2, 1, 120, false, false, 272};

	eq[273]={
		"magician's cowl", "dark", "accessory", "dark",
		"A tall, pointed cowl. It looks an awkward blend of imposing and impractical.\n",
		0, 2, 0, 0, 0, 0, 4, -1, 1, 120, false, false, 273};

	eq[274]={
		"iron bangle", "cold", "accessory", "light",
		"A crude iron bracelet, enchanted against fey magics. And priests.\n",
		0, 2, 0, 1, 0, 0, 3, -1, 2, 274, false, false, 274};

	eq[275]={
		"mace of blessed bashing", "spiked", "weapon", "holy",
		"This ancient, brutal looking weapon is crusted\nwith the dried blood of...'nonbelievers.'\n",
		2, 1, 4, 1, 1, 0, 1, 1, 10, 275, false, false, 275};

	eq[276]={
		"bangle", "golden", "accessory", "dark",
		"A simple bracelet of hammered gold, enchanted against dark magics.\n",
		0, 2, 0, 1, 0, 0, 0, 3, 2, 276, false, false, 276};

	eq[277]={
		"robes", "brilliant", "armor", "light",
		"A simple set of cloth robes, nearly blinding to look at.\nFrom the right angle they shimmer with brilliant color.\n",
		0, 5, 0, 3, 0, 0, 3, 5, 1, 200, false, false, 277};

	eq[278]={
		"tome of light", "weathered", "weapon", "holy",
		"A well-thumbed book of prayers. Holding it fills you with a sense of wonder, and divinity.\n",
		0, 2, 0, 3, 0, 0, 5, 5, 1, 150, false, false, 278};

	eq[279]={
		"cape", "crimson", "accesory", "none",
		"A flowing silken cape dyed a rich, vibrant red.\nConfers little benefit but can be used to deceive the enemy\n...plus, it completes the ensemble.\n",
		0, 0, 0, 0, 0, 3, 0, 1, 0, 70, false, false, 279};

	eq[280]={
		"longsword", "paladin", "weapon", "none",
		"Passed down through generations of holy knights. A long, perfectly straight,\nchanneled blade, with a wide golden crosstree. The pommel is set with a large ruby.\n",
		2, 0, 4, 3, 1, -1, 0, 1, 3, 75, false, false, 280};

	eq[281]={
		"heavy plate armor", "paladin", "armor", "none",
		"Ornately styled heavy plate armor, with\nwhite-enameled surfaces, immense pauldrons\nbearing red cross emblems, a red sash, and\ngold trim. A casque helm and chain coif\nconceal your face.\n",
		3, 0, 0, 5, 0, -3, 0, 0, 6, 100, false, false, 281};

	eq[282]={
		"kite shield", "paladin", "accessory", "none",
		"A thick and heavy kite-shaped shield embellished\nwith white lacquer, gold trim, and the\nPaladins' red cross emblem in the center.\n",
		2, 0, 0, 3, 0, -2, 0, 0, 4, 70, false, false, 282};

	eq[283]={
		"sword of angel's mercy", "silver", "weapon", "holy",
		"Forged to bring swift, merciful death upon the enemies of Light,\nthis gleaming silver broadsword has an intricate gold spiral inlay\ncurling up the blade.\n\nA faint vibration runs through this mythical weapon, causing it to 'sing' a chilling note with every slash.\n",
		2, 2, 4, 1, 1, 0, 0, 2, 0, 150, false, false, 283};

	eq[284]={
		"goblin cutlass", "iron", "weapon", "poison",
		"This wreck was their prized weapon?\nIts curved blade is notched and covered in rust.\nStill, that foul green liquid dripping from it looks pretty lethal...\n",
		1, 1, 1, 0, 0, 0, 0, 0, 1, 35, false, false, 284};

	eq[285]={
		"leather armor", "shadowed", "armor", "none",
		"Specially designed for ease of movement and\nutter silence, the entire ensemble is dyed black as\na moonless night. The Assassins' guild snake\ninsignia can be faintly seen on the breastplate\nand cuffs.\n",
		1, 0, 0, 3, 0, 3, 0, 1, 1, 100, false, false, 285};

	eq[286]={
		"hood", "ninja", "accessory", "none",
		"This black cloth mask covers the wearer's face\nand head, leaving a narrow slit for the eyes.\nOne cheek displays the Assassins' Guild snake insignia in silver thread.\n",
		0, 0, 0, 1, 0, 3, 0, 3, 0, 80, false, false, 286};

	eq[287]={
		"katana", "ebony", "weapon", "none",
		"A long, slightly curved sword with a single edge, ideal for quick, deadly attacks.\nThe blade is pure matte black and light as a feather,\nwith a silver snake insignia inlaid near the silk-wrapped hilt.\n",
		2, 0, 5, 0, 0, 2, 0, 5, 3, 100, false, false, 287};

	eq[288]={
		"poison", "assassin's", "misc", "none",
		"A pungent dark-green liquid inside a small glass vial.\nCan be used surreptitiously to kill any NPC.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, false, false, 288};

	eq[289]={
		"archon robes", "grand", "armor", "none",
		"These ancient blue, white, and silver robes\nare sewn with the insignia of the original\nCouncil of Magi: six colored spheres,\neach inscribed with a single rune, dominated by a seventh, silver sphere at their center.\n",
		0, 4, 0, 0, 0, 0, 7, 1, 1, 300, false, false, 289};

	eq[290]={
		"adept robes", "arcanum", "armor", "none",
		"A stylized black robe alchemically strengthened with iron.\nA black-and-red patterned stole is worn over the chest and shoulders.\n",
		1, 1, 0, 2, 0, 0, 5, -1, 1, 75, false, false, 290};

	eq[291]={
		"arcanum staff", "bladed", "weapon", "none",
		"A long, straight rod of black iron with a curved blade at the top, set\nwith a glowing ruby. Magical runes are carved in circles around the haft.\n",
		1, 1, 3, 0, 1, 0, 4, 0, 2, 100, false, false, 291};

	eq[292]={
		"flask", "silver", "quest", "???",
		"A teardrop-shaped flask of pure, brushed silver.\nHundreds of tiny elven runes are inscribed around the rim.\nThe top is sealed with a dark wooden cork.\nIf you listen closely, you can hear faint sounds from inside.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 10, false, false, 292};

	eq[293]={
		"slayer battleaxe", "silver", "weapon", "none",
        "A tall, double sided battleaxe forged of silver. The long haft is wrapped in black leather,\nand a wrought-iron skull howls from between the double blades.\n",
		1, 0, 10, -3, 0, -2, 0, 0, 8, 150, false, false, 293};

	eq[294]={
		"Token of Unobtaining", "brass", "misc", "hacks!",
"An item that was never meant to be held.\nIt is absurdly heavy for its size.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 10, 1, false, false, 294};

	eq[295]={
		"crest", "paladin", "quest", "none",
        "This thick golden medallion bears the mark of Samlund's white knights,\nthe Paladin's guild.\nIt can be used to access the Paladin guild shop in the Grand Hall.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 1, false, false, 295};

	eq[296]={
		"shard", "silverice", "quest", "none",
"A thick, sharp-edged pane of mystical ice from the\nfar north. Its surface appears silvery and\nopaque in the light, but in darkness becomes translucent.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 0, 1, false, false, 296};
eq[297]={
		"cursed chalice", "none", "quest", "none",
		"This eerie ebony goblet has a bizarre horned skull\nrelief on one side, and a hairline fracture\nrunning down the other. A drop\nof thick crimson liquid oozes from the crack,\nthough the chalice is empty.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 297};
eq[298]={
		"seed bag", "none", "quest", "none",
		"A small burlap sack brimming with seeds.\n",
		0, 0, 0, 0, 0, 0, 0, 0, 1, 0, false, false, 298};
	eq[299]={
		"elemental staff", "jeweled", "weapon", "none",
		"The intricately carved runes along the haft of\nthis mystic weapon bespeak great power,\nas does its crowning gem.\n",
		0, 0, 2, 0, 0, 0, 2, 0, 2, 100, false, false, 299};

	for(int item=0;item<300;item++)
	{
	    eq[item].subt="null";

	    //Set item subtype and other internal assignments
	    eq[item].setType();
	    eq[item].setActDesc();
		eq[item].setMaterialBonus();
		eq[item].setPrice();
	}
}


#endif // TSF_ITEMS_H_INCLUDED
