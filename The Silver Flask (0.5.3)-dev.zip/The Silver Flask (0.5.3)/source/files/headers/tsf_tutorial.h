#ifndef TSF_TUTORIAL_H_INCLUDED
#define TSF_TUTORIAL_H_INCLUDED

#include "tsf_classes.h"

using namespace std;


bool tutorial;
area tut[3][3];
npc tut_npc[13];
quest tut_q[12];

void tutorialExit()
{
    if(tutorial)
    {
        cout<<"\nReally exit the tutorial?\n(you will be teleported to the Village at (1, 10).)\n(1) Yes\n(2) No\n";
        cin>>pc.inp;
        if(pc.inp=="1"){tutorial=false; pc.area=loc[1][10];}
    }
    else cout<<"\nYou're not inside anything, and I don't recommend breaking the fourth wall.\n";
}

void define_tut_quests()
{
    tut_q[0]={"Welcome to the Game\n", 0, 2, 2, 0, 0, 221, false, false};
    tut_q[1]={"Potions Tutorial\n", 0, 2, 2, 0, 0, 222, false, false};
    tut_q[2]={"Woodland Tutorial\n", 0, 2, 0, 0, 0, 223, false, false};
    tut_q[3]={"Hunting, Fishing, and Cooking Tutorial\n", 0, 5, 0, 0, 0, 224, false, false};
    tut_q[4]={"Smithing and Mining Tutorial\n", 0, 4, 0, 0, 0, 225, false, false};
    tut_q[5]={"Construction Tutorial\n", 0, 4, 0, 0, 0, 226, false, false};
    tut_q[6]={"Combat, Equipment, and Stats Tutorial\n", 0, 4, 0, 0, 0, 227, false, false};
    tut_q[7]={"Spells and Elemental Effects\n", 0, 2, 0, 0, 0, 228, false, false};
    tut_q[8]={"Time, Weather and Seasons\n", 0, 2, 0, 0, 0, 229, false, false};
    tut_q[9]={"Enchanting Tutorial\n", 0, 2, 0, 0, 0, 230, false, false};
    tut_q[10]={"Farming and Baking\n", 0, 2, 0, 0, 0, 231, false, false};
    tut_q[11]={"Shops and Gold\n", 0, 2, 0, 0, 0, 232, false, false};
}

void define_tut_area()
{
    tut[0][0]={"null", "null.\n",
	0, 0, 0, 0, 0,
	0, 0, 0,
	0, 0, 0, 0, 0, 0, 101, "[V_]", 136, 136};
	tut[0][0].npcs[0]=nlist[0];

	tut[1][2]={"Tutorial Village",
	"A small, lively village full of helpful and industrious townsfolk.\n",
	0, 0, 0, 0, 0,
	0, 0, 0,
	1, 0, 1, 0, 1, 2, 102, "[TV]", 136, 136};
	tut[1][2].npcs[0]=tut_npc[1];
	tut[1][2].npcs[1]=tut_npc[11];
	tut[1][2].npcs[2]=tut_npc[12];
	sign wooden = {"wooden", "Congratulations on reading this sign!\n   Try interacting with everything you find. You never know."};
	tut[1][2].signs.push_back(wooden);


	tut[2][2]={"Tutorial Workshops",
	"An outlying industrial area full of craftsmen hard at work.\n",
	0, 0, 0, 0, 0,
	0, 0, 0,
	1, 0, 0, 1, 2, 2, 102, "[WS]", 136, 136};
	tut[2][2].npcs[0]=tut_npc[5];
	tut[2][2].npcs[1]=tut_npc[6];
	tut[2][2].npcs[2]=tut_npc[7];

	tut[1][1]={"Tutorial Forest",
	"A small wooded area on the edge of town.\nNestled in the woods are a small camp and an old hut.\n",
	0, 0, 0, 0, 0,
	0, 0, 0,
	0, 1, 1, 0, 1, 1, 103, "[TF]", 136, 136};
	tut[1][1].npcs[0]=tut_npc[2];
	tut[1][1].npcs[1]=tut_npc[3];
	tut[1][1].npcs[2]=tut_npc[4];

	tut[2][1]={"Tutorial Tower",
	"You enter a tall stone tower.\nAmong its many floors are a library, enchanting workshop, and observatory.\n",
	0, 0, 0, 0, 0,
	0, 0, 0,
	0, 1, 0, 1, 2, 1, 104, "[TT]", 136, 136};
	tut[2][1].npcs[0]=tut_npc[8];
	tut[2][1].npcs[1]=tut_npc[9];
	tut[2][1].npcs[2]=tut_npc[10];

	for(int x=0;x<3;x++)
	{
		for(int y=0;y<3;y++)
		{
		    //Initialize tutorial areas
		    if(tut[x][y].name=="")
            {
                tut[x][y].name="null";
                tut[x][y].desc="null";
            }

            tut[x][y].world = "Tutorial";
            tut[x][y].loc_flora=plant[0];
            tut[x][y].loc_fauna=anim[0];
            tut[x][y].loc_bldg=null_bldg;
            tut[x][y].loc_shop=shops[0];
            tut[x][y].loot=eq[0];
		}
	}
}

void define_tut_npcs()
{

    tut_npc[1]={
		"Guide",
		"calling out advice",
		"If it weren't for his aura of wisdom and distinctive question mark staff,\nyou would have mistaken this heavily bearded old man for a beggar.\nHe wears a simple blue robe and stands in the center of the village, calling out advice to passers-by.\n",
		"He greets you warmly as you approach.\n'Welcome, adventurer! How can I help?'\n",
		"The Guide shakes is head.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"'Happy adventuring, stranger. Remember, if you want to leave the tutorial, just type 'exit' at any time.'\n",
		"'You can enter '4' to hear this all again.'\n",
		221};
		tut_npc[1].q=tut_q[0];
		tut_npc[1].dopt[0]="(1) What is this place?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[1].info[0]="'Why, I'm the Guide, of course. I'm here to direct new adventurers towards the info they need.'\n";
		tut_npc[1].qline[1]="The Guide beams broadly.\n'Welcome to Tutorial Island, friend.\nThis is a place for young adventurers like yourself to learn\nall the skills needed for survival.'\n";
        tut_npc[1].dopt[1]="(1) Where should I start?\n(2) How did I get here? Can I get back?\n(3) Leave\n";
		tut_npc[1].info[1]="'You've been teleported by an effect of what's known as 'tutorial magic.'\nWhile you're here a lot of things you'll experience on the mainland are impossible,\nlike being attacked or harvesting materials.\nYou can leave at any time by entering 'exit' (outside of this conversation, of course.)'\n";
		tut_npc[1].qline[2]="'Well, there are tutors all over the island to teach you the skills you'll need.\nWhere you start is up to you.'\n";
		tut_npc[1].dopt[2]="(1) Thanks for the info.\n(2) Who can teach me what?\n(3) Leave\n";
		tut_npc[1].info[2]="'North - Forest\n   Witch - information about herbs, potions, and brewing\n   Woodsman - information about gathering and crafting wood\n   Hunter - hunting, fishing, and wilderness survival'\nEast - Workshops\n   Blacksmith - information about mining and smithing\n   Builder - information about buildings and construction\n   Fighter - information about equipment, combat, and player stats\nNortheast - Tower\n   Wizard - information about using spells and the elements\n   Astronomer - information about seasons and weather\n   Mystic - information about enchantments\nTutorial Village (here)\n   Guide - That's me! Come talk to me if you ever need to hear this again.\n   Farmer - information about farming, harvesting, and baking\n   Merchant - information about shops, transactions and gold\n";

		tut_npc[2]={
		"Witch",
		"stirring a cauldron",
		"This young witch defies stereotypes; her nose is completely straight, there's not a wart in sight, and she can't be more than 30.\nThere's a definitely creepy vibe about her, though.\n",
		"She looks up from her cauldron with a lopsided grin.\n'Here to learn about potions?'\n",
		"The witch shakes her head.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"'Remember, be careful what you eat and drink...\nIf you don't know what will poison you, you'll be sorry!'\n",
		"'You can enter '4' to hear this all again.'\n",
		222};
		tut_npc[2].q=tut_q[1];
		tut_npc[2].dopt[0]="(1) Can you teach me about herbs and potions?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[2].info[0]="She laughs shrilly. It sends shivers down your spine.\n'I'm a friend of the forest, friend. It whispers to me of secrets and secret mixtures...'\n";
		tut_npc[2].qline[1]="She looks at you sidelong, dropping another ingredient into the pot.\n'It's not whether I can teach you, it's whether you can learn.'\n";
		tut_npc[2].dopt[1]="(1) What herbs should I keep an eye out for?\n(2) How do I mix potions?\n(3) Leave\n";
		tut_npc[2].info[1]="'It's not too complicated. All you need are the following items:\n   Container of water - This can be any type of container.\n    If you use a glass bottle, you can throw it at an enemy.\n   Up to two herbs or flowers - use flowers to make dye.\n    For mixed colors, mix a flower into the dye you want to change.'\n";
		tut_npc[2].qline[2]="The witch sucks her teeth distractedly, thinking.\n'  In the forests - medicinal herb, the basis of most beneficial potions.\n    It will cure any affliction.\n   In the tundra - snowflower, an herb that restores energy.\n   In the volcanic badlands - torchweed, a bitter herb that restores vitality.\n   On the plains, in the woods - you can find flowers for mixing dyes.\n";
        tut_npc[2].dopt[2]="(1) Thanks for the info.\n(2) What kinds of potions can I make?\n(3) Leave\n";
		tut_npc[2].info[2]="'Oh, all kinds. You can enhance your abilities, poison your enemies, restore your health and energy,\ncure ailments, or mix dyes to change the color of your equipment...or your enemies.' She cackles loudly, startling you.\n";

        tut_npc[3]={
		"Woodsman",
		"felling a tree",
		"This burly, bearded lumberjack is an epitome of his class. He's swinging an axe with gusto,\nchecking his progress every so often. He seems pleased with each stroke.\n",
		"The woodsman leans his axe against a tree.\n'Need some learning in woodwork?'\n",
		"The lumberjack shrugs.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"'Always carry an axe, that's what I always say.'\n",
		"'You can enter '4' to hear this all again.'\n",
		223};
		tut_npc[3].q=tut_q[2];
		tut_npc[3].dopt[0]="(1) What can you tell me about woodcutting?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[3].info[0]="He shrugs his broad shoulders. 'Nobody, really. I spend most of my time either felling trees or carving equipment.'\n";
		tut_npc[3].qline[1]="'Well, the best place to start is with a Woodcutting Axe, you can buy those from a merchant.\nThen all you have to do is find a tree and type 'chop'.\nIt takes a while, especially if you're new at it, but eventually you'll get some wood.'\n";
		tut_npc[3].dopt[1]="(1) What can you tell me about woodworking?\n(2) What are some items I can make?\n(3) Leave\n";
		tut_npc[3].info[1]="'Anything you need wood for, really; you just need to reach the right skill level.\n 0-3: Wooden Dagger\n 3-6: wooden staff\n 6-9: wooden charm\n 10-12: shortbow\n 13-16: longbow\n 17-20: arrows\n 21-23: magic staff\n";
		tut_npc[3].qline[2]="'You'll need a Chisel.\nGet yourself a piece of wood, type 'carve', and select the item you'd like to make.\nYou may end up breaking the wood in your attempt, but if you're successful\nyou'll increase your woodworking skill a little.\n";
		tut_npc[3].dopt[2]="(1) Thanks for the info.\n(2) Any other tips?\n(3) Leave\n";
		tut_npc[3].info[2]="He thinks for a moment, scratching his beard.\n'Not a whole lot. Just, you're never out of luck if you carry a bit of wood with you.\nYou can craft yourself something on the fly, make a campfire, or lob it at a surprise enemy.'\n";

		tut_npc[4]={
		"Hunter",
		"roasting a squirrel",
		"The hooded hunter seems lost in thought, sat on a log amidst a small campsite.\nSeveral makeshift racks support hides, meat, and fish.\n",
		"The hunter glances at you.\n'Here to learn about survival?'\n",
		"The hunter shakes his head.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"'Remember, if you can make camp anywhere, you'll never be lost.'\n",
		"'You can enter '4' to hear this all again.'\n",
		224};
		tut_npc[4].q=tut_q[3];
		tut_npc[4].dopt[0]="(1) What's the first thing I should know about survival?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[4].info[0]="He lifts his hood slightly. 'I'm just a hunter; I spend a lot of time out here,\nmaking occasional trips to the market to sell hides, meat and fish.'\n";
		tut_npc[4].qline[1]="The hunter puts down his roasting stick.\n'You can find food anywhere in the wild. If you're lucky, you'll find things like mushrooms and wild berry bushes,\nbut you can always look around for an animal by typing 'hunt'.\n";
		tut_npc[4].dopt[1]="(1) Okay, say I find an animal - what then?\n(2) What sort of animals are in the wild?\n(3) Leave\n";
		tut_npc[4].info[1]="'All different kinds; you can hunt most anything.\nThe grasslands and forests will have the best prey for food and leather,\nbut you can find some kind of animal nearly anywhere.'\n";
		tut_npc[4].qline[2]="'You'll be given two options - to catch, or to hunt.\nCatching isn't important to survival; it's a skill used by those who want to keep an animal as a pet.\nIf you choose to hunt, you'll pit your speed and strength against the animal,\nand if you're successfull, you'll get as much meat and hide as you can from it.\n";
		tut_npc[4].dopt[2]="(1) What can you tell me about fishing?\n(2) What else should I know about hunting?\n(3) Leave\n";
		tut_npc[4].info[2]="'There are a few things.\n   If you have a bow equipped or a hunter with you, it'll be a lot easier to catch your prey.\n   Even animals of the same species can vary widely,\n being at different stages of growth and having different strengths.\n   The larger and stronger the animal, the more you'll get for killing it.\n";
		tut_npc[4].qline[3]="'Well, it's a little easier than hunting; however, you'll need both a Fishing Rod and an amount of Bait.\nYou'll want to find an area with water nearby, like a river or pond, and type 'fish' to cast your line.\nOne piece of bait is consumed by each fish you catch.\n";
		tut_npc[4].dopt[3]="(1) How do I cook the fish and meat I catch?\n(2) What else should I know about fishing?\n(3) Leave\n";
		tut_npc[4].info[3]="He thinks about it.\n'The weight of the fish you catch increases the amount it can heal.\n In addition, there's a fisherman in the city that'll buy fish from you based on weight;\nHe also sells rods, lures, and bait.'\n";
		tut_npc[4].qline[4]="'If you have wood and a Tinderbox, you can light a campfire by typing 'fire'.\nIt may take some time, but once you have a fire going, you can 'cook'\nraw meat and fish over the fire.\nIf you're not skilled in cooking yet you may burn whatever you try to cook.\n";
        tut_npc[4].dopt[4]="(1) What do I do with the other items I get from hunting?\n(2) What else should I know about cooking?\n(3) Leave\n";
		tut_npc[4].info[4]="'You can try to cook anything raw, including most vegetables.\n If you have a pot of water, you can make a restorative stew with two other ingredients.\nCooking an item always increases its healing capacity by a fair amount.'\n";
		tut_npc[4].qline[5]="'With leather, you can get a Needle and Thread, then type 'sew' to craft leather armor and shields.\nFeathers you can use with wood to 'carve' arrows.\n";
        tut_npc[4].dopt[5]="(1) Thanks for the info.\n(2) Any last-minute wisdom about woodland survival?\n(3) Leave\n";
		tut_npc[4].info[5]="He leans in close, dropping his tone.\n'Listen, bear, elk, and birds you can find most anywhere; but some places,\nyou may find rare, special creatures. Keep your eyes open.'\n";

        tut_npc[5]={
		"Blacksmith",
		"hammering away",
		"The hulking, kind-faced smith is hammering laboriously at a piece of metal.\nHis brow is furrowed with heat and concentration.\n",
		"The blacksmith looks up with a grin.\n'Here to learn the craft, eh?'\n",
		"He shakes his head at you.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"'Remember, the more you hammer against the steel, the more the steel shapes you.'\n",
		"'You can enter '4' to hear this all again.'\n",
		225};
		tut_npc[5].q=tut_q[4];
		tut_npc[5].dopt[0]="(1) What can you tell me about smithing?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[5].info[0]="'I'm the local blacksmith.\nI forge everything from nails and wagon wheels, to weapons and armor.'\n";
		tut_npc[5].qline[1]="He sets the hammer aside.\n'First, you'll need raw materials to work with.\nYou can buy some things, but it's often easier to get your own.\n";
		tut_npc[5].dopt[1]="(1) How do I do that, then?\n(2) What materials will I find in the wild?\n(3) Leave\n";
		tut_npc[5].info[1]="'In any rocky area you can find iron, stone, gold, silver, and gemstones.\nRumor has it there's a mountain in the Elves' territory that still has\nveins of the legendary Mithril.\n";
		tut_npc[5].qline[2]="'First thing you'll need is a Pickaxe.\nThen you can visit any rocky area and 'mine' for materials.\nYou're very likely to find iron and stone off the bat, but you'll need\na more practiced eye to find rarer materials.\n";
		tut_npc[5].dopt[2]="(1) How do I shape the raw materials?\n(2) Are there any other sources of ores?\n(3) Leave\n";
		tut_npc[5].info[2]="'If you're a strong enough fighter, Stone Golems will drop chunks of stone and iron.\nElemental creatures will, rarely, drop a gemstone.'\n";
		tut_npc[5].qline[3]="'Now we're talking.\nYou'll need to get a Hammer, and find yourself a Smithy;\nThen, with the materials in your possession, type 'smith' to begin crafting.\n";
		tut_npc[5].dopt[3]="(1) Is there anything else to know about smithing?\n(2) What sort of items can I make this way?\n(3) Leave\n";
		tut_npc[5].info[3]="'That depends on your skill level -\n   1-3: dagger\n   4-6: shortsword\n   7-9: chainmail armor\n   10-12: steel bar\n   13-15: longsword\n   16-18: plate armor\n   19-21: small shield\n   22-24: kite shield\n   25-27: bladed gauntlets\n";
		tut_npc[5].qline[4]="'Yes, there's one more thing: if you want to make items out of steel, you'll have to make a steel bar.\nYou can only do this if you have both iron and coal in your inventory.\n";
		tut_npc[5].dopt[4]="(1) Thanks for the info.\n(2) Are there any other smithing skills?\n(3) Leave\n";
		tut_npc[5].info[4]="'Absolutely. If you have an item you want to improve,\nyou can type 'temper' to reinforce the item.\nYou'll need a piece of the material the item is made of as well.'\n";

        tut_npc[6]={
		"Carpenter",
		"sawing logs",
		"The serious, stoic builder is measuring and cutting planks with a studious expression.\n",
		"He looks at you seriously as you approach.\n'Yes? Do you need information about building?'\n",
		"He shakes his head at you.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"He returns to his craft, saying, 'Take pride in what you do, stranger, and you'll never want in life.'\n",
		"'You can enter '4' to hear this all again.'\n",
		226};
		tut_npc[6].q=tut_q[5];
		tut_npc[6].dopt[0]="(1) What can you tell me about building?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[6].info[0]="'I'm carpenter. I help build structures for those here who need it.'\n";
		tut_npc[6].qline[1]="'Well, you can start a building as easily as anything.\nAll you need to get started is to type 'build', and you'll set up an area.\n";
		tut_npc[6].dopt[1]="(1) And after that?\n(2) Are there any restrictions?\n(3) Leave\n";
		tut_npc[6].info[1]="'Yes; it's important to note that any area is only large enough for one building, so build wisely!'\n";
		tut_npc[6].qline[2]="'The most important thing is, of course, building materials.\nBuildings take a lot of materials; for instance, you'll need 10 wood,\n3 iron, and 3 stone to build a house.\n";
        tut_npc[6].dopt[2]="(1) Once I have the materials?\n(2) How can I get these materials?\n(3) Leave\n";
		tut_npc[6].info[2]="'Well, if you have a Woodcutting Axe and a Pickaxe, you can respectively 'chop' and 'mine' for them.'\n";
		tut_npc[6].qline[3]="'You'll need a Hammer, of course;\nJust visit the building site and type 'build' again. You'll see how much of each material\nyou'll need to finish the building, and have the option to add materials to the unfinished structure.\n";
		tut_npc[6].dopt[3]="(1) What can I do inside a building?\n(2) Can I tear down a structure?\n(3) Leave\n";
		tut_npc[6].info[3]="'No, that's not allowed; otherwise we'd have hoodlums running around tearing down buildings all over!\n";
		tut_npc[6].qline[4]="'Loads of things! You can build chests to store items, you can rest,\nyou can build things like ovens and forges, and of course,\nyou can decorate the structure however you like.'\n";
		tut_npc[6].dopt[4]="(1) Thanks for the info.\n(2) What kinds of objects and decorations can I put inside?\n(3) Leave\n";
		tut_npc[6].info[4]="'As far as objects, you can build:\n  -chests\n  -tables\n  -chairs\n  -ovens\n  -forges\n  -enchanting obelisks\n  -planters\n\nIn terms of decorations, your only limit is your imagination; decorative\nobjects are just cosmetic and can't be interacted with.'\n";

        tut_npc[7]={
		"Fighter",
		"battering a straw-stuffed dummy",
		"The fighter, though young, has the look of an experienced mercenary;\nhe unleashes blows into the training dummy with strength and precision.\n",
		"He salutes you with his sword as you approach.\n'Need some combat training, eh?'\n",
		"He shakes his head at you.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"The fighter claps you on the shoulder.\n'Remember, your most important weapon is your mind.'\n",
		"'You can enter '4' to hear this all again.'\n",
		227};
		tut_npc[7].q=tut_q[6];
		tut_npc[7].dopt[0]="(1) What can you tell me about fighting?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[7].info[0]="He grins, giving the dummy a whack.\n'I'm a fighter; I help defend the town when they need me.\nFor the right price, of course!'\n";
		tut_npc[7].qline[1]="'First thing's first: never go into a fight empty-handed.\nYou can check your inventory with 'inv', and if you find a weapon there,\ntake up arms by typing 'equip'.\nYou can do this with armor and accessories as well.'\n";
		tut_npc[7].dopt[1]="(1) Once I've equipped some gear, what then?\n(2) What does equipping items do for me?\n(3) Leave\n";
		tut_npc[7].info[1]="'Well, weapons will raise your attack, or your combat damage, and your defense;\narmor and other equipment can raise your attack, defense, strength, dexterity, intellect, or luck.\nSome heavier items will offer large attack and defense bonuses while limiting your dexterity.'\n";
		tut_npc[7].qline[2]="'If there's an enemy nearby, you can type 'fight' to engage them in bloody combat;\nIt's also highly likely that you'll be ambushed in your travels.\nIf your dexterity is higher than that of your foe, you have a chance to escape, otherwise\nit's a fight to the death!\n";
        tut_npc[7].dopt[2]="(1) What should I do in combat?\n(2) What are my enemies capable of?\n(3) Leave\n";
		tut_npc[7].info[2]="'Theoretically, anything you are; your foes all have health, mana,\nattack, defense, strength, dexterity, intellect, and luck scaled to their level,\nwhich in turn is scaled to your own. Enemies are also able to cast spells and will sometimes\ndrop items when defeated.'\n";
		tut_npc[7].qline[3]="'Your best bet is to take the initiative! You can use your weapon with 'a', or 'attack'\nthough if you feel the tide turning against you, you can 'f' flee, or use a potion with 'hpot', 'mpot', or 'apot'.\n";
		tut_npc[7].dopt[3]="(1) What happens if I win? What if I lose?\n(2) Can enemies use weapons?\n(3) Leave\n";
		tut_npc[7].info[3]="'Some do, but it's unlikely for a wild creature to use a sword, no?'\n";
		tut_npc[7].qline[4]="'Defeating an enemy will always yield gold and experience, pushing you closer to the next level.\nIn rare cases the enemy will drop an item.\nSometimes killing certain enemies or a certain number of enemies will progress a quest.\n\nIf you lose, well, that's game over!\nBetter hope you saved your game with the 'save' command.\n\nWhat's a game? ...I don't know either.'\n";
		tut_npc[7].dopt[4]="(1) Thanks for the info.\n(2) What factors determine my success in combat?\n(3) Leave\n";
		tut_npc[7].info[4]="'Lots of things. Here's the overview:\n  -Attack: your basic damage\n  -Defense: blocks a portion of the opponent's attack\n  -Strength: adds damage to your basic attack and some skills\n  -Dexterity: your ability to dodge an attack or flee battle\n  -Intellect: affects magic damage and experience gain\n  -Luck: determines your chance of a critical hit; also increases gold gain'\n";

        tut_npc[8]={
		"Wizard",
		"poring over an old, vellum-bound grimoire",
		"This old wizard, clad in robes and pointed hat, looks foreboding at first take,\nthough it seems he's merely engrossed in his book.\n",
		"The old wizard looks at you inquiringly.\n'Have you come for deeper knowledge of magic?'\n",
		"He shakes his head at you.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"He returns to his book. As you leave he says,\n'Remember: power without purpose is worse than pointless.'\n",
		"'You can enter '4' to hear this all again.'\n",
		228};
		tut_npc[8].q=tut_q[7];
		tut_npc[8].dopt[0]="(1) What can you tell me about magic?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[8].info[0]="He sighs. 'In the old days, I was known as a terrible force, leveler of mountains, that sort of thing.\nNow I mostly just study the arcane with my fellows here.'\n";
		tut_npc[8].qline[1]="The wizard closes the ancient tome.\n'The first and most important rule of magic: you must, without fail,\nhave enough energy, or mana, to cast a spell.\nWithout this principle in mind, your casting will quickly become catastrophic.'\n";
		tut_npc[8].dopt[1]="(1) Enough mana, got it. What else?\n(2) What are the different schools of magic?\n(3) Leave\n";
		tut_npc[8].info[1]="'The 'schools,' as you put it, are really as varied as there are practicioners;\nhowever, there are a few main categories:\n  -Elemental: focused on dealing damage with the elements\n  -Healing: curing wounds and status afflictions\n  -Enhancement: increasing one's skills on the battlefield\n  -Druidic: attunement with one's natural environment. Effects are varied.\n  -Necromancy: tapping into the energies of life and death\n  -Musical: widely controversial, the Bard's art of influence\n  -Sword: warriors rarely recognize the sort of energy they expend for their skills\n   in battle, but it comes from the same pool.'\n";
		tut_npc[8].qline[2]="'In or out of battle, type 'cast', and then the specific name of the ability you'd like to use.\nThe name must be true or the spell will fail.\nThat's really all there is to it.'\n";
		tut_npc[8].dopt[2]="(1) Thanks for the info.\n(2) What are the elements? What do they do?\n(3) Leave\n";
		tut_npc[8].info[2]="'Again, these things aren't so simple, but here's an overview:\n  -Fire: the most basic element for dealing damage.\n   Generally strong against earth-based opponents.\n  -Water: has a chance to cause extra damage via choking.\n   Strongest against fire types.\n  -Earth: will penetrate a portion of the enemy's armor.\n   Will do the most damage against wind types.\n  -Wind: has a chance to stagger the opponent, buying time for another attack.\n   Does not typically have a direct counter.\n  -Lightning: has the capacity to paralyze an opponent.\n   Strongest against water-type enemies.\n  -Ice: will slow an opponent\n   Usually strongest against either fire or water.\n  -Light: potent against dark or demonic foes.\n  -Dark: does not have any special strength or weakness.'\n";

        tut_npc[9]={
		"Astronomer",
		"peering through the lens of an immense telescope",
		"The astronomer hasn't moved since you entered, glued to his telescope.\nWho knows what he's thinking about, staring into the cosmos?\n",
		"The astronomer turns around at last.\n'If you've come for the secrets of sun and moon, of the changing seasons, you're in the right place.'\n",
		"He shakes his head at you.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"He returns to his telescope. As you leave he says,\n'Remember: the boundless universe cares for you as for a grain of sand.\n...Is there any grain of sand where it's not meant to be?'\n",
		"'You can enter '4' to hear this all again.'\n",
		229};
		tut_npc[9].q=tut_q[8];
		tut_npc[9].dopt[0]="(1) What can you tell me about the skies?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[9].info[0]="He shakes his head, nearly dislodging a cap decorated with stars and planets.\n'Merely a mote of cosmic dust, watching from my corner of the universe\nthe passage of celestial bodies. I dare to ask my puny questions of the skies,\nand at times they deign to answer.'\n";
		tut_npc[9].qline[1]="'Much, young scholar, but I will tell you only as pertains to your journey.\n\nIn this world, time passes at a constant rate:\nevery action, save the most brief, will consume exactly one tenth of a day.\n\nAs the hours pass, so too do the sun and moon;\none only need look overhead to watch their journey across the skies.\n\nAnd as the days, pass, so too do the seasons: Spring, Summer, Winter and Fall,\neach bringing new and unique energies as this world leans to and fro.\n\nFinally, as the seasons pass, so too, the years will come and go as our home circles the sun.\n";
        tut_npc[9].dopt[1]="(1) What effects does the passage of time have?\n(2) What events correspond with day and night?\n(3) Leave\n";
		tut_npc[9].info[1]="'Many and varied, they are; one may at times find their way easier\nin darkness; or one may find that new light leads to new discoveries.\nMore, I cannot say.\n";
		tut_npc[9].qline[2]="'The passage of time...wounds may heal, and the body may rebuild its reserves of energy.\nCrops will flourish, flocks will regrow their woolly coats, and herds of cattle produce new milk each day.\n";
        tut_npc[9].dopt[2]="(1) Thanks for the info.\n(2) What significance is the changing of the seasons?\n(3) Leave\n";
		tut_npc[9].info[2]="'Each season changes the hum in the air, strengthening some and weakening others;\neach comes with its own expressions of the elements in the weather.\n  -Spring and Fall, as well as windy weather, increase the energies of the wind.\n  -Summer, and sunny days, will increase the power of fire.\n  -Rain and storms will increase the strength of water.\n  -Storms will empower one's lightning with their own.\n  -Winter, and snow, will strengthen any icy spell.\n  -Earthen energies, lastly, are bolstered by Spring, and clear weather.\n";

        tut_npc[10]={
		"Mystic",
		"hunched over an enchanting circle",
		"Barely discernable as a human shape, the mystic is deeply hooded and\nclad in many layers of feathered robes. She is deep in concentration, channeling arcane energies\nbetween gems and her desired items.\n",
		"She speaks to you without looking up.\n'Yes, I will tell you of enchantments and their means.'\n",
		"She shakes her head at you.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"She grunts dismissively. As you leave she says,\n'Remember the threads of your enchantments, lest ye become lost among them.'\n",
		"'You can enter '4' to hear this all again.'\n",
		230};
		tut_npc[10].q=tut_q[9];
		tut_npc[10].dopt[0]="(1) What can you tell me about enchanting?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[10].info[0]="'I'm just an old shaman, a purveyor of mysticism, and a lover of the arcane arts.'\n";
		tut_npc[10].qline[1]="She speaks softly, pouring energy into another item.\n'All spells, be they destructive or enchanting, require mana. Know this well.'\n";
		tut_npc[10].dopt[1]="(1) What else is needed for enchantment?\n(2) How much mana is needed for enchanting?\n(3) Leave\n";
		tut_npc[10].info[1]="'Very little; as you grow and produce stronger and stronger enchantments, so too will grow the cost.'\n";
		tut_npc[10].qline[2]="'The most essential: elemental energies are naturally contained within gemstones.\nYou'll need one for each enchantment.\n";
		tut_npc[10].dopt[2]="(1) Thanks for the info.\n(2) What are the different enchantments, and what do they do?\n(3) Leave\n";
		tut_npc[10].info[2]="'There are six different enchantments one may perform with gemstones:\n  -Fire (ruby): adds fire damage or defense, increases strength\n  -Wind (crystal): adds wind damage or defense, increases dexterity\n  -Earth (emerald): adds earth damage or defense, increases defense\n  -Water (sapphire): adds water damage or defense, increases intellect\n  -Ice (diamond): adds ice damage or defense, increases attack\n  -Lightning (amethyst): adds Lightning damage or defense, increases luck\n\nIn addition, each enchantment will decrease the energy cost of casting spells in its element.'\n";

		tut_npc[11]={
		"Farmer",
		"puffing on a corncob pipe",
		"This rustic fellow looks a little familiar.\n",
		"She speaks to you without looking up.\n'Ye wants t'know about farmin', eh?'\n",
		"He shakes his head.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"'Mmh,' he grunts. 'Remember, ye'll never plant potatoes and grow a squash instead.\n",
		"'You can enter '4' to hear this all again.'\n",
		231};
		tut_npc[11].q=tut_q[10];
		tut_npc[11].dopt[0]="(1) What can you tell me about farming?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[11].info[0]="'I tills the earth, I do, and spend many a long day at it.\nAn' when that's done, I grinds the wheat and bakes the bread.'\n";
		tut_npc[11].qline[1]="He taps out his pipe.\n'Not much to tell, stranger.\nIf you have a bag of seed, you can type 'sow' to plant crops on Farmland.\n";
		tut_npc[11].dopt[1]="(1) What then? Do I have to water the crops?\n(2) What else is there to farming?\n(3) Leave\n";
		tut_npc[11].info[1]="'Well, if you have Shears you can 'shear' a flock of sheep for some wool for sewing.\nIf you've a container, you can 'milk' cows once a day.\n";
		tut_npc[11].qline[2]="'No, just let nature take care of that. Just remember to leave them crops alone for 3 full days before you come back to 'harvest'.\nWheat you can take to the Windmill to grind into flour for bread, cakes and pies.\nVegetables you can cook by themselves or put in a stew.\n";
		tut_npc[11].dopt[2]="(1) Thanks for the info.\n(2) How long does everything take again?\n(3) Leave\n";
		tut_npc[11].info[2]="'  -Growing wheat/vegetables: 3 full days\n  -Regrowing wool: 3 full days\n  -Replenishing milk: 1 full day\n  -Grinding flour: immediate'\n";

        tut_npc[12]={
		"Merchant",
		"counting coin",
		"The old merchant has a placid smile on his face as he counts his earnings.\n",
		"He looks up with a smile as you approach.\n'Ah, come to learn a thing or two about trade, eh?'\n",
		"He shakes his head.\n'You've got to be more precise with your responses!\nTry typing in a '1', '2', '3', or '4'.'\n",
		"He gives you a nod and a wave.\n'Remember to keep your accounts, friend; you never know who else will do the same!'\n",
		"'You can enter '4' to hear this all again.'\n",
		232};
		tut_npc[12].q=tut_q[11];
		tut_npc[12].dopt[0]="(1) What can you tell me about trading?\n(2) Who are you?\n(3) Leave\n";
		tut_npc[12].info[0]="He gestures towards his wares.\n'I'm a traveling salesman, friend, though I do less of the traveling nowadays.'\n";
		tut_npc[12].qline[1]="He sits back, looking upward as he thinks.\n'Well, you'll find shops and merchants all over.\nI can tell you what to expect from each, I suppose, and how to get a good price for your items.'\n";
		tut_npc[12].dopt[1]="(1) How do I buy and sell items?\n(2) What kinds of shops are there?\n(3) Leave\n";
		tut_npc[12].info[1]="'Well, quite a few, but I'll key you in on a few main types:\n\n  -Armory: the best example of mercantilism in the land.\n   Here you can buy equipment suited to your level,\n   and sell excess goods from your inventory.\n\n  -Merchant: these traveling salesmen have every tool under the sun.\n   You can't sell to them, unfortunately.\n\n  -Potion shop: a few old witches put down roots and sell\n   all the most useful potions, and glass bottles as well.\n\nThere are many other kinds of shops; most you can access by typing 'shop',\nand if not, the word you'll need will be expressed.'\n";
		tut_npc[12].qline[2]="'You'll need to visit an Armory for that. Always good blokes running them.\nJust walk in and type 'buy' or 'sell' to do business.'\n";
		tut_npc[12].dopt[2]="(1) Thanks for the info.\n(2) What are some tips for making gold, and lots of it?\n(3) Leave\n";
		tut_npc[12].info[2]="'Nobody wants to gather their own resources; if you want money, then there it is.\nWood's infinite, and not difficult to 'carve' into something more valuable.'\n";
}

void define_tutorial_island()
{
    define_tut_quests();
    define_tut_npcs();
    define_tut_area();
}



#endif // TSF_TUTORIAL_H_INCLUDED
