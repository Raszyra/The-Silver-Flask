#ifndef TSF_SEASONAL_H_INCLUDED
#define TSF_SEASONAL_H_INCLUDED

#include "tsf_classes.h"

using namespace std;

void seasonal_changes(string curs_name)
{
    string csn=curs_name;

    cout<<"\nYou can feel a change in the air...the seasons are shifting at last.\n";

    if(csn=="Spring")
    {
        cout<<"Winter turns to Spring, ice and snow melting and giving\nway to emerald-green grass, the jubilant motion of animals, and colorful flowers.\n";
        if(!trophy_list[trophyGetID("pinecone")].unlock&&rollfor(1,100)) trophyGet("pinecone", 0);
    }
    if(csn=="Summer")
    {
        cout<<"Spring gives way to Summer; the weather turns hot,\nfields begin to dry, and the humming of cicadas fills the air.\n";
        if(!trophy_list[trophyGetID("rose")].unlock&&rollfor(1,100)) trophyGet("rose", 0);
    }
    if(csn=="Fall")
    {
        cout<<"Summer gives way to autumn. Leaves turn from green to warm golds and reds,\ndrifting in scattered shifts to cover the ground in a crisp carpet.\nThe woods smell of rotting logs and mushrooms.\n";
        if(!trophy_list[trophyGetID("gourd")].unlock&&rollfor(1,100)) trophyGet("gourd", 0);
    }
    if(csn=="Winter")
    {
        cout<<"Fall gives way to winter, bare trees now hung with icicles.\nYour breath fogs the air, and a deep chill grips the land.\nThe ground is blanketed in trackless snow; most wildlife will sleep through the season.\n";
    }

    //empty out flora and fauna lists for all 121 main map tiles
    for(int x=0; x<11; x++)
    {
        for(int y=0; y<11; y++)
        {
            for(int z=0;z<loc[x][y].flora_types.size(); z++)
            {
                loc[x][y].flora_types.pop_back();
            }

            for(int z=0;z<loc[x][y].fauna_types.size(); z++)
            {
                loc[x][y].fauna_types.pop_back();
            }

    //refill flora and fauna lists with seasonal changes
    if(csn=="Spring")
    {
        if(loc[x][y].name=="Hidden Jungle")
        {
            loc[x][y].fauna_types.push_back(anim[23]);//frillneck
            loc[x][y].flora_types.push_back(plant[17]);//giant fern
        }
        //Forests, woods, groves, ancient forests
        if(loc[x][y].wood && loc[x][y].name != "Hidden Jungle")
        {
				loc[x][y].flora_types.push_back(plant[1]);//medicinal herb
				loc[x][y].flora_types.push_back(plant[4]);//mushroom
				loc[x][y].flora_types.push_back(plant[7]);//apple
				loc[x][y].flora_types.push_back(plant[12]);//toadstool
				loc[x][y].flora_types.push_back(plant[11]);//dandelion
				loc[x][y].flora_types.push_back(plant[8]);//roses
				loc[x][y].flora_types.push_back(plant[18]);//bluebell

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
				loc[x][y].fauna_types.push_back(anim[11]);//fox
				loc[x][y].fauna_types.push_back(anim[12]);//fairy
				loc[x][y].fauna_types.push_back(anim[16]);//wolf
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
				loc[x][y].fauna_types.push_back(anim[18]);//crow
			}

			if(loc[x][y].name=="Sparse Forest"||loc[x][y].name=="Forest Path")
			{
				loc[x][y].fauna_types.push_back(anim[10]);//turkey
			}

        // rivers, riverbanks, lakes, ponds
			if(loc[x][y].water)
            {
                loc[x][y].fauna_types.push_back(anim[13]);//bullfrog
				loc[x][y].fauna_types.push_back(anim[14]);//heron
				loc[x][y].fauna_types.push_back(anim[15]);//dragonfly
            }

		// glaciers, ice fields, tundra, snow
			if(loc[x][y].name=="Tundra")
			{
				loc[x][y].flora_types.push_back(plant[2]);//snowflower

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[11]);//fox
			}

        // lava plains
			if(loc[x][y].name=="Lava Plain")
			{
				loc[x][y].flora_types.push_back(plant[3]);//torchweed
			}

        // plains, grassland, grassland path
			if(loc[x][y].name=="Grassland"||loc[x][y].name=="Grassland Path")
			{
				loc[x][y].flora_types.push_back(plant[5]);//redberry bush
				loc[x][y].flora_types.push_back(plant[6]);//greenberry bush
				loc[x][y].flora_types.push_back(plant[9]);//lilac
				loc[x][y].flora_types.push_back(plant[11]);//dandelion
				loc[x][y].flora_types.push_back(plant[13]);//iris
				loc[x][y].flora_types.push_back(plant[8]);//roses
				loc[x][y].flora_types.push_back(plant[14]);//lobelia
				loc[x][y].flora_types.push_back(plant[15]);//gorse

				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[6]);//hawk
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
				loc[x][y].fauna_types.push_back(anim[16]);//bee
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
				loc[x][y].fauna_types.push_back(anim[19]);//crow
			}

        //mountains, rocky hills
			if(loc[x][y].mine)
			{
				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[4]);//cougar
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[6]);//hawk
			}
    }// end spring

    if(csn=="Summer")
    {
        if(loc[x][y].name=="Hidden Jungle")
        {
            loc[x][y].fauna_types.push_back(anim[23]);//frillneck
            loc[x][y].flora_types.push_back(plant[17]);//giant fern
        }
        if(loc[x][y].wood && loc[x][y].name != "Hidden Jungle")
			{
				loc[x][y].flora_types.push_back(plant[1]);//medicinal herb
				loc[x][y].flora_types.push_back(plant[5]);//green berry bush
				loc[x][y].flora_types.push_back(plant[6]);//red berry bush
				loc[x][y].flora_types.push_back(plant[7]);//apple
				loc[x][y].flora_types.push_back(plant[12]);//toadstool

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
				loc[x][y].fauna_types.push_back(anim[11]);//fox
				loc[x][y].fauna_types.push_back(anim[12]);//fairy
				loc[x][y].fauna_types.push_back(anim[16]);//bee
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
				loc[x][y].fauna_types.push_back(anim[18]);//wolf
				loc[x][y].fauna_types.push_back(anim[19]);//crow
			}
			if(loc[x][y].water)
            {
                loc[x][y].fauna_types.push_back(anim[13]);//bullfrog
				loc[x][y].fauna_types.push_back(anim[14]);//heron
				loc[x][y].fauna_types.push_back(anim[15]);//dragonfly
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
            }
			if(loc[x][y].name=="Sparse Forest"||loc[x][y].name=="Forest Path")
			{
				loc[x][y].fauna_types.push_back(anim[10]);
			}
			if(loc[x][y].name=="Tundra")
			{
				loc[x][y].flora_types.push_back(plant[2]);

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[11]);//fox
			}
			if(loc[x][y].name=="Lava Plain" || loc[x][y].name == "Mountain of Doom")
			{
				loc[x][y].flora_types.push_back(plant[3]);
			}
			if(loc[x][y].name=="Grassland")
			{
				loc[x][y].flora_types.push_back(plant[5]);//red berry bush
				loc[x][y].flora_types.push_back(plant[6]);//green berry bush
				loc[x][y].flora_types.push_back(plant[9]);//lilac
				loc[x][y].flora_types.push_back(plant[11]);//dandelion
                loc[x][y].flora_types.push_back(plant[13]);//iris
				loc[x][y].flora_types.push_back(plant[8]);//roses
				loc[x][y].flora_types.push_back(plant[14]);//lobelia
				loc[x][y].flora_types.push_back(plant[15]);//gorse

				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[6]);//deer
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
                loc[x][y].fauna_types.push_back(anim[16]);//bee
				loc[x][y].fauna_types.push_back(anim[17]);//firefly
			}
			if(loc[x][y].mine)
			{
				loc[x][y].fauna_types.push_back(anim[2]);
				loc[x][y].fauna_types.push_back(anim[4]);
				loc[x][y].fauna_types.push_back(anim[5]);
				loc[x][y].fauna_types.push_back(anim[6]);
			}
    }//end summer

    if(csn=="Fall")
    {
        if(loc[x][y].name=="Hidden Jungle")
        {
            loc[x][y].fauna_types.push_back(anim[23]);//frillneck
            loc[x][y].flora_types.push_back(plant[17]);//giant fern
        }
        if(loc[x][y].wood && loc[x][y].name != "Hidden Jungle")
			{
				loc[x][y].flora_types.push_back(plant[1]);//medicinal herb
				loc[x][y].flora_types.push_back(plant[4]);//mushroom
				loc[x][y].flora_types.push_back(plant[10]);//fern
				loc[x][y].flora_types.push_back(plant[12]);//toadstool

				loc[x][y].fauna_types.push_back(anim[1]);//squirrel
				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[3]);//deer
				loc[x][y].fauna_types.push_back(anim[5]);//bear
				loc[x][y].fauna_types.push_back(anim[7]);//elk
				loc[x][y].fauna_types.push_back(anim[8]);//hare
				loc[x][y].fauna_types.push_back(anim[9]);//sparrow
				loc[x][y].fauna_types.push_back(anim[11]);//fox
				loc[x][y].fauna_types.push_back(anim[12]);//fairy
				loc[x][y].fauna_types.push_back(anim[19]);//crow
				loc[x][y].fauna_types.push_back(anim[18]);//wolf
			}
			if(loc[x][y].water)
            {
                loc[x][y].fauna_types.push_back(anim[13]);//bullfrog
				loc[x][y].fauna_types.push_back(anim[14]);//heron
            }
			if(loc[x][y].name=="Sparse Forest"||loc[x][y].name=="Forest Path")
			{

			}
			if(loc[x][y].name=="Tundra")
			{
				loc[x][y].flora_types.push_back(plant[2]);

				loc[x][y].fauna_types.push_back(anim[1]);
				loc[x][y].fauna_types.push_back(anim[3]);
				loc[x][y].fauna_types.push_back(anim[5]);
				loc[x][y].fauna_types.push_back(anim[7]);
				loc[x][y].fauna_types.push_back(anim[8]);
				loc[x][y].fauna_types.push_back(anim[11]);
			}
			if(loc[x][y].name=="Lava Plain" || loc[x][y].name == "Mountain of Doom")
			{
				loc[x][y].flora_types.push_back(plant[3]);
			}
			if(loc[x][y].name=="Grassland")
			{
				loc[x][y].flora_types.push_back(plant[4]); //mushroom

				loc[x][y].fauna_types.push_back(anim[2]);//badger
				loc[x][y].fauna_types.push_back(anim[6]);
				loc[x][y].fauna_types.push_back(anim[7]);
				loc[x][y].fauna_types.push_back(anim[8]);
				loc[x][y].fauna_types.push_back(anim[9]);
				loc[x][y].fauna_types.push_back(anim[17]);
			}
			if(loc[x][y].mine)
			{
				loc[x][y].fauna_types.push_back(anim[2]);
				loc[x][y].fauna_types.push_back(anim[4]);
				loc[x][y].fauna_types.push_back(anim[5]);
				loc[x][y].fauna_types.push_back(anim[6]);
			}
    }//end fall

    if(csn=="Winter")
    {
        //forests
            if(loc[x][y].wood && loc[x][y].name != "Hidden Jungle")
			{
				loc[x][y].flora_types.push_back(plant[1]);//medicinal herb
			}

			if(loc[x][y].name=="Sparse Forest"||loc[x][y].name=="Forest Path")
			{

			}

			if(loc[x][y].name=="Hidden Jungle")
            {
                loc[x][y].fauna_types.push_back(anim[23]);//frillneck
                loc[x][y].flora_types.push_back(plant[17]);//giant fern
            }
		//rivers, riverbanks, lakes and ponds
			if(loc[x][y].water)
            {

            }
		//tundra, snow, ice fields, glacier
			if(loc[x][y].name=="Tundra")
			{
				loc[x][y].flora_types.push_back(plant[2]);//snowflower
			}
        //
			if(loc[x][y].name=="Lava Plain" || loc[x][y].name == "Mountain of Doom")
			{
				loc[x][y].flora_types.push_back(plant[3]);//torchweed
			}
        // grassland, plains, grassland paths
			if(loc[x][y].name=="Grassland")
			{

			}
        //mountains
			if(loc[x][y].mine)
			{

			}
    }//end winter

    }//for y 0 to 11

    }//for x 0 to 11


}//end define seasonal changes

#endif // TSF_SEASONAL_H_INCLUDED
