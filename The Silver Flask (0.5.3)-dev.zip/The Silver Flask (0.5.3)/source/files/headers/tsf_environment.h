#pragma once

#ifndef TSF_ENVIRONMENT_H_INCLUDED
#define TSF_ENVIRONMENT_H_INCLUDED

#include "tsf_classes.h"

//wildlife
void define_wildlife()
{
    //string name; int dex, hp, drop, id, lvl; string idle, desc;

	//empty animal template
	anim[0]={"null",
            0, 0, 0, 0, 0,
            "null",
            "null"};

	anim[1]={"Squirrel",
            5, 1, 0, 1, 1,
            "shaking its tail and chittering",
            "small mammal"};
	anim[2]={"Badger",
            3, 5, 0, 2, 1,
            "trundling through the undergrowth",
            "small mammal"};
	anim[3]={"Deer",
            7, 5, 1, 3, 1,
            "striding gracefully between the trees",
            "mammal"};
	anim[4]={"Cougar",
            3, 8, 1, 4, 1,
            "prowling",
            "large mammal"};
	anim[5]={"Bear",
            1, 9, 2, 5, 1,
            "foraging",
            "large mammal"};
	anim[6]={"Hawk",
            9, 3, 0, 6, 1,
            "circling overhead",
            "bird"};
	anim[7]={"Elk",
            4, 7, 1, 7, 1,
            "grazing",
            "large mammal"};
	anim[8]={"Hare",
            4, 3, 0, 8, 1,
            "loping between clover patches",
            "small mammal"};
	anim[9]={"Sparrow",
            10, 2, 0, 9, 1,
            "perched on a branch",
            "bird"};
    anim[10]={"Turkey",
            1, 3, 0, 10, 1,
            "stepping gingerly towards you",
            "bird"};
    anim[11]={"Fox",
            5, 2, 0, 11, 1,
            "crouched in the underbrush",
            "small mammal"};

    anim[12]={"Faerie",
            12, 3, 0, 12, 1,
            "perched on a flower",
            "insect"};

    anim[13]={"Bullfrog",
            3, 1, 0, 13, 1,
            "croaking noisily",
            "amphibian"};

    anim[14]={"Heron",
            1, 3, 0, 14, 1,
            "stalking a fish in the shallows",
            "bird"};

    anim[15]={"Dragonfly",
            8, 1, 0, 15, 1,
            "hovering",
            "insect"};

    anim[16]={"Bee",
            8, 1, 0, 16, 1,
            "hovering",
            "insect"};

    anim[17]={"Firefly",
            7, 1, 0, 17, 1,
            "glimmering",
            "insect"};

    anim[18]={"Wolf",
            3, 4, 0, 18, 1,
            "howling",
            "mammal"};

    anim[19]={"Crow",
            3, 4, 0, 19, 1,
            "perched",
            "bird"};

    anim[20]={"Bat",
            4, 2, 0, 20, 1,
            "fluttering",
            "small mammal"};

    anim[21]={"Cat",
            3, 1, 0, 21, 1,
            "sitting",
            "small mammal"};

    anim[22]={"Dog",
            2, 2, 0, 22, 1,
            "digging in a rubbish heap",
            "mammal"};

    anim[23]={"Frillneck",
            2, 2, 0, 23, 1,
            "with its back to you",
            "reptile"};
}

//flora
void define_flora()
{
    //string name, idle, desc; int item, id;
    plant[0]={"null",
            "null",
            "null",
            0, 0,};
    plant[1]={"medicinal herb",
            "with broad green leaves",
            "null",
            0, 1,};
            plant[1].item=getItemID("none", "medicinal herb");
    plant[2]={"blue flower",
            "nestled in the snow",
            "null",
            0, 2,};
            plant[2].item=getItemID("none", "snowflower");
    plant[3]={"orange flower",
            "on a brittle, woody stalk",
            "null",
            0, 3,};
            plant[3].item=getItemID("none", "torchweed");
    plant[4]={"mushroom",
            "peeking out behind a rotten log",
            "null",
            0, 4,};
            plant[4].item=getItemID("none", "mushroom");
    plant[5]={"bush",
            "laden with fruit",
            "null",
            0, 5,};
            plant[5].item=getItemID("red", "berry");
    plant[6]={"bush",
            "covered in small, tart berries",
            "null",
            0, 6,};
            plant[6].item=getItemID("green", "berry");
    plant[7]={"apple",
            "hanging from a tree",
            "null",
            0, 7,};
            plant[7].item=73; //getItemID("tsir", "apple");
    plant[8]={"rose",
            "blooming amidst thorny branches",
            "null",
            0, 8,};
            plant[8].item=getItemID("red", "rose");
    plant[9]={"lilac bush",
            "blossoming vibrantly",
            "null",
            0, 9,};
            plant[9].item=getItemID("pink", "lilac");
    plant[10]={"fern",
            "growing",
            "null",
            0, 10,};
    plant[11]={"dandelion",
            "growing",
            "null",
            0, 11,};
            plant[11].item=getItemID("yellow", "dandelion");
    plant[12]={"toadstool",
            "growing",
            "null",
            0, 12,};
            plant[12].item=getItemID("none", "mushroom");
    plant[13]={"iris",
            "flowering",
            "null",
            0, 13,};
            plant[13].item=getItemID("purple", "iris");
    plant[14]={"lobelia patch",
            "growing",
            "null",
            0, 14,};
            plant[14].item=getItemID("blue", "lobelia");

    plant[15]={"gorse bush",
            "growing",
            "null",
            0, 15,};
            plant[15].item=getItemID("yellow", "gorse");

    plant[16]={"spiky cattail",
            "swaying in the breeze",
            "null",
            0, 16};
            plant[16].item=getItemID("none", "cattail");

    plant[17]={"giant fern",
            "growing",
            "null",
            0, 17};
            plant[17].item=getItemID("none", "cattail");

    plant[18]={"bluebell",
            "growing",
            "null",
            0, 18};
            plant[18].item=getItemID("blue", "bell");
}

//weather
void define_weather()
{
    cweath[0]={
        "Clear",
        "The winds are still, and the clouds favorable.", 2,
        "earth"};

    cweath[2]={
        "Windy",
        "Sweeping gusts of wind carry leaves and grass through the air.", 7,
        "wind"};

    cweath[3]={
        "Raining",
        "A steady patter of drops overhead turns to a downpour.", 3,
        "water"};

    cweath[4]={
        "Sunny",
        "The clouds escape to the horizon under a blazing sun.", 14,
        "fire"};

    cweath[5].name = "Stormy";
    cweath[5].desc = "Sheets of rain pour from dark clouds, interspersed by\nrolling thunder and sharp bolts of lightning.";
    cweath[5].color = 5;
    cweath[5].elem = "lightning";

    cweath[1]={
        "Snowing",
        "Fragile snowflakes drift thickly from grey skies until the ground is blanketed in white.", 15,
        "ice"};
}

//seasons
void define_seasons()
{
    seasons[0].id=0;
    seasons[0].name="Spring";
    seasons[0].elem1="earth";
    seasons[0].elem2="water";
    seasons[0].color=2;
    seasons[0].wopt[0]=cweath[0];
    seasons[0].wopt[1]=cweath[2];
    seasons[0].wopt[2]=cweath[3];

    seasons[1]={1, "Summer", 4};
    seasons[1].elem1="fire";
    seasons[1].elem2="lightning";
    seasons[1].wopt[0]=cweath[4];
    seasons[1].wopt[1]=cweath[0];
    seasons[1].wopt[2]=cweath[5];

    seasons[2]={2, "Fall", 6};
    seasons[2].elem1="wind";
    seasons[2].elem2="lightning";
    seasons[2].wopt[0]=cweath[2];
    seasons[2].wopt[1]=cweath[3];
    seasons[2].wopt[2]=cweath[5];

    seasons[3]={3, "Winter", 11};
    seasons[3].elem1="ice";
    seasons[3].elem2="water";
    seasons[3].wopt[0]=cweath[1];
    seasons[3].wopt[1]=cweath[2];
    seasons[3].wopt[2]=cweath[3];
    curs=seasons[0];
}


#endif

