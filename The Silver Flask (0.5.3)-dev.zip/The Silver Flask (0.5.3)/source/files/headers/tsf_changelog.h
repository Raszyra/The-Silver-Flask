#ifndef TSF_CHANGELOG_H_INCLUDED
#define TSF_CHANGELOG_H_INCLUDED

/* -->Changelog
+--------------------+
| Version 0.12 (windows)
| - started changelog
    Version 0.1.3 (windows)
    - Added sound effects
    Version 0.1.4 (windows)
    - Fleshed out sound system
    - Fixed a few bugs
    - Added companion mechanics
        - stats for Luz and Grognak
        - chats for Luz
        - stats for Frost, Aldo
        - idles for each
        - equipment, inventory, trading,
        - AI, combat
    Version 0.1.5 (Windows)
        -added shop class/function
        -framework for library, bakery
        -added visuals for the map, a la console text coloring
        -added color/text option for movement output
        -fixed a few bugs
    Version 0.1.6 (Windows)
        -enabled setting player color(s)
        -enabled saving player settings
        -added visuals for health, mana, xp bars
        -reformatted a few menus
        -enabled saving exploration progress
        -enabled saving player location
    Version 0.1.7 (Windows)
        -increased spell list from 38 to 68
        -Modified Bard to start as Wanderer
        -new abilities for
            -Druid
            -Fencer
            -Trickster (with a new mechanic)
            -Wanderer
            -Fighter
            -Scholar
            -Bard
            -Thief
            -Bandit
            -Guild Master Classes
        -added combat data for all 68 spells
        -fixed a few inconsistencies
        -fixed a few minor alignment/formatting bugs
    Version 0.1.8 (Windows)
        -made baking a separate process from cooking
        -fixed a couple menu bugs
        -added shops<shop> to area data
        -added new shop
        -adjusted spell-related functions to cover the whole list
        -tested baking, books
     Version 0.1.9
        -added flora and fauna
                -indexes
                -mechanics to implement (both are loaded on move)
        -added a new area unlocked by specific flora/fauna combo
		-hidden info, tips and allusions
		-possible shop?
		-new, unofficial side quest
		-three new items as rewards
		-an augmentation of an existing random encounter
     Version 0.2.0
        -added Luci as a companion character
        -wrote dialogue for:
            -Valencia
            -Hakon
            -Azelfoff
            -Archmage
        -set base data for all 25 side quests
        -added Assassins' and Mages' guild members to their respective areas
     Version 0.2.1
        -wrote dialogue for
            -Suni
            -Brother Viri
            -Fisherman
            -Mayor
            -Goblin Shaman
     Version 0.2.2
        -added fortuneteller
        -added liars' dice
        -started migrating system functions,
         declarations, and definitions to header files
     Version 0.2.3
        -added master resource file
        -reformatted and fully incorporated minigames
        -added title information
        -added a new song mechanic for Aria
    Version 0.2.4
        -Added function to show recent save files
        -finished excising chunks of definition to
        put in header files.
        -Added Luci's data to companions header
        -Frameworked effects for playing songs
        -Frameworked literacy and music as skills
        -fixed a number of bugs
        -streamlined menus
        -edited character creation menu to be more easily understood
    Version 0.2.5
        -Added the ability to eat and drink during combat
        -Added brewing (mixing)
                -red, blue, yellow, pink, purple, orange and green dyes
                -A few other derivative dyes like crimson and chartreuse
                -strength, intellect, and luck potions
                -health, mana and antidote potions
        -Wrote effects for all remaining spells in noncomcast()
        -Attributed text colors to the different seasons
        -Weather now has a 1/5 chance to change on each step
        -Added mechanic for throwing potions in combat
        -Formally added 'Academic' skills to list (music and literacy)
        -Changed 'carving' to 'woodworking'
        -Miscellaneous formatting, spelling, continuity, etc.
        -Some other minor tweaks and fixes
    Version 0.2.6
        -Added buildings, objects, and carpentry;
        the player can now build a static house
        and interact with it, including:
            -decorating with descriptive items
            -crafting chests to hold equipment
        -Added static and terrain objects
            -Area vectors and a local slot for each
    Version 0.2.7
        -Tutorial update
        -added "Tutorial Island", a new 4x4 location with 12 different guide NPCs
            -Main guide
            -Woodsman
            -Witch
            -Hunter
            -Wizard
            -Astronomer
            -Mystic
            -Carpenter
            -Blacksmith
            -Fighter
            -Merchant
            -Farmer
        -added function to reset NPCs and dialog after completion
        -as a byproduct, tentative framework for traveling to and from
        different maps
    Version 0.2.8
        -Fixed a few more spelling and spacing errors
        -Added recipes for potions and cooked food
        -Finally added dexterity potion
        -Made some revisions to the hunting mechanics
            -added bonus for having Luz in your party
            -added bonus for having a bow equipped
            -added levels and variable stats/rewards for
             environmental NPCs
        -Removed random switches for area.herbs; all plants
         now exist only as flora objects until "picked"
        -Revised a few spells
            -"Raven" became "Crow"
            -Bear, Crow, and Swarm now create environmental NPCs
            -"Grow" cast outside combat now rolls again for nearby flora
            -Added some more descriptions in noncomcast()
        -Tested and reviewed song effects
        -Fixed a bug with seasonal_changes()
        -fixed a cooking bug and adjusted some numbers for foods
    Version 0.2.9
        -Added the ability to revisit the sick and the needful if they're nearby
        -Added potions as drops from chests
        -Fixed questlog bug, log now displays all quests
        -Completed requirements and switches for
            -Azelfoff/Silencing the Source
            -Gareth/Piercing the Darkness
            -Emiria/The Cursed Chalice
            -Shaman/Shaman's Intuition
        -Added quest descriptions for all quest steps
        -Completed all four guilds
            -Guild shops
            -Guild quests
            -Master classes
            -Guild items/equipment
        -Added version number to "about" section of main menu
    Version 0.3.0
        -Added 'guildshops' to showarea()
            -conditional on class
        -Fixed a bug in showarea()
            -Interesting note: a string as an 'if' condition returns true (?)
        -Added date and time to save slots
        -Added 'showinv' to all the skill commands using items from inventory
        -Added capacity to sheath and unsheath weapons in and out of combat
            -Fixed a bug in the sheath mechanic
        -Added fish eggs, chance to catch with fish
    Version 0.3.1
        -Added trophies for various skills, kills, and actions
            -Trophy collection and score do not influence gameplay
            -Player attributes do not affect trophy collection
        -Fixed a baking bug



        <(_o_)> BUG: some skills crash the game when used in combat. may be only second skill used.
        <(_o_)> BUG: game crashes on entering Lava Plains, no leads
|
|
+--------------------+*/


#endif // TSF_CHANGELOG_H_INCLUDED
