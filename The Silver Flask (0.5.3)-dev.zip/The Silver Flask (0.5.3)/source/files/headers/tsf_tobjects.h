#ifndef TSF_TOBJECTS_H_INCLUDED
#define TSF_TOBJECTS_H_INCLUDED

#include "tsf_classes.h"

void define_objects()
{
    //name, desc, cap (maximum contents)
    null_object={
        "null",
        "null",
        0};
    static_object_list[0] = null_object;

    chest={
        "chest",
        "An old wooden chest banded by iron.\n",
        5};
    static_object_list[1] = chest;

    table={
        "table",
        "A wide wooden table.\n",
        3};
    static_object_list[2] = table;

    chair={
        "chair",
        "The world's best sitting device.\n",
        0};
    static_object_list[3] = chair;

    planter={
        "planter",
        "A plant-pot full of rich soil. It'll keep a plant alive.\n",
        1};

    bed={
        "bed",
        "A comfortable-looking bed. You could rest in it.\n",
        0};
    static_object_list[4] = bed;

    anvil={
        "anvil",
        "A sturdy anvil one might use to craft metal.\n",
        0};
    static_object_list[5] = anvil;

    oven={
        "oven",
        "A warm, rustic oven that can be used for cooking or baking.\n",
        0};
    static_object_list[6] = oven;

    obelisk={
        "enchanting obelisk",
        "A foreboding stone obelisk about a meter tall.\nGlowing runes run up and down each side.\n",
        0};
    static_object_list[7] = obelisk;
}

#endif // TSF_TOBJECTS_H_INCLUDED
