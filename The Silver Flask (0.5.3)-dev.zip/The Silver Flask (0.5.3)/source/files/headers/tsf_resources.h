#pragma once

#ifndef TSF_RESOURCES_H_INCLUDED
#define TSF_RESOURCES_H_INCLUDED

//standard libraries
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <ctime>
#include <limits>
#include <windows.h>
#include <Mmsystem.h>
#include <algorithm>
#include "serialization.h"
#include <filesystem>
#include <sstream>
#include <string>
#include <cstddef>

//game data
#include "tsf_functions.h"
#include "TSF_stats_window.h"
#include "tsf_areas.h"
#include "tsfresource.h"
#include "tsf_enemies.h"
#include "tsf_items.h"
#include "tsf_npcs.h"
#include "tsf_races.h"
#include "tsf_environment.h"
#include "tsf_party.h"
#include "tsf_spells.h"
#include "tsf_tobjects.h"
#include "tsf_buildings.h"
#include "tsf_tutorial.h"
#include "TSF_trophies.h"
#include "tsf_seasonal.h"
#include "tsf_save_load.h"
#include "tsf_settings.h"


//game icon
#include "../visual/icoresource.h"

//minigames
#include "tsf_liarsdice.h"
#include "tsf_dekara.h"

using namespace std;

vector <string> alpha_notes;

void load_alpha_notes()
{
    ifstream fin;
    string s_path = "config/alpha_notes.txt";
    fs::path path = s_path;
    int line = 0;
    string s_line = "";

    fin.open(s_path);
    f_checkO(fin, path);

    while(getline(fin, s_line) ){alpha_notes.push_back(s_line);}

    fin.close();
    f_checkC(fin, path);
}

void save_alpha_notes()
{
    ofstream fo;
    string s_path = "config/alpha_notes.txt";
    fs::path path = s_path;
    size_t doc_len = size(alpha_notes);

    fo.open(s_path);
    f_checkO(fo, path);

    //Save file length as metadata
    for(size_t i = 0; i < doc_len; i++) fo << alpha_notes[i] << endl;

    fo.close();
    f_checkC(fo, path);
}

void write_alpha_note(){
    string note = "";
    clear_cin();
    getline(cin, note);
    alpha_notes.push_back(note);
}

void read_alpha_notes(){for(size_t i = 0; i < size(alpha_notes); i++) prln(alpha_notes[i]);}

void show_recent_alpha(){
    prln(" -> Recent alpha notes:");
    size_t asize = size(alpha_notes);
    size_t start_index = (asize >= 5) ? asize - 5 : 0;
    for(size_t i = asize; i > start_index; i--) cout << " - " << alpha_notes[i-1] << "\n";
}

//define sound
string sdItem="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\item.wav";
string sdAtk="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\flare.wav";
string sdDing="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\find.wav";
string sdBell="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\bell.wav from 0 to 500";
string sdLvlup="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\lvlup.wav";
string sdPaper="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\paper1.mp3 from 0 to 500";
string sdBag="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\bag2.mp3 from 100 to 1000";
string sdCrit="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\swordchop.mp3 from 100 to 1000";
string sdCoins="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\coins.mp3";
string sdMystic="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\mystic.mp3";
string sdGlimmer="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\glimmer.mp3";
//weather
string sdRain="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\rain1. from 0 to 1500 mp3";
string sdStorm="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\storm from 0 to 1500.mp3";
string sdWind="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\wind.mp3 from 0 to 1500";
//seasonal ambiance
string sdSummer="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\summer.mp3 from 0 to 1500";
string sdSpring="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\spring.mp3 from 0 to 1500";
string sdWinter="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\winter.mp3 from 0 to 1500";
string sdFall="play C:\\Users\\vynew\\Desktop\\C++\\TheSilverFlask (beta)\\resources\\sound\\fall.mp3 from 0 to 1500";



#endif // TSF_RESOURCES_H_INCLUDED
