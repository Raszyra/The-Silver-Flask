#ifndef STATICWINDOW_H_INCLUDED
#define STATICWINDOW_H_INCLUDED

#include <Windows.h>

// Define the custom window class globally
const wchar_t* g_szClassName = L"MyCustomWindowClass";

// Function to create a new window
HWND CreateCustomWindow(HINSTANCE hInstance, int nCmdShow, LPCWSTR title, int width, int height) {
    // Step 1: Create the window
    HWND hwnd = CreateWindowEx(
        0,
        g_szClassName,            // Window class name
        title,                    // Window title
        WS_OVERLAPPEDWINDOW,      // Window style
        CW_USEDEFAULT,            // Initial X position
        CW_USEDEFAULT,            // Initial Y position
        width,                    // Initial width
        height,                   // Initial height
        NULL,                     // Parent window
        NULL,                     // Menu
        hInstance,                // Instance handle
        NULL                      // Additional application data
    );

    if (!hwnd) {
        MessageBox(NULL, L"Window Creation Failed!", L"Error", MB_ICONERROR | MB_OK);
        return NULL;
    }

    // Show and update the window
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    return hwnd;
}

// Message callback function
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}

// Main function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Step 1: Define the window class
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = g_szClassName;

    // Step 2: Register the window class
    if (!RegisterClass(&wc)) {
        MessageBox(NULL, L"Window Registration Failed!", L"Error", MB_ICONERROR | MB_OK);
        return 0;
    }

    // Step 3: Create windows on the fly
    HWND hwnd1 = CreateCustomWindow(hInstance, nCmdShow, L"Window 1", 400, 300);
    HWND hwnd2 = CreateCustomWindow(hInstance, nCmdShow, L"Window 2", 600, 400);

    // Step 4: Run the message loop
    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

#endif // STATICWINDOW_H_INCLUDED
