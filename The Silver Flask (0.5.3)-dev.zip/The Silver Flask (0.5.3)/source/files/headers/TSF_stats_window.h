#ifndef TSF_STATS_WINDOW_H_INCLUDED
#define TSF_STATS_WINDOW_H_INCLUDED

#include <windows.h>
#include <iostream>
#include <cstring>

using namespace std;

HWND CreateStatWindow(HINSTANCE hInstance, int nCmdShow, LPCSTR title, int width, int height)
{
    HWND hwnd = CreateWindowEx(0, "STATIC", title, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, width, height, NULL, NULL, hInstance, NULL);
    if (!hwnd)
    {
        MessageBox(NULL, "Window creation failed!", "Flagrant system error", MB_ICONERROR | MB_OK);
        return NULL;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    return hwnd;
}

LRESULT CALLBACK StatWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_DESTROY: {PostQuitMessage(0);}
            return 0;
        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd, &ps);

                HBRUSH hBrush = CreateSolidBrush(RGB(13, 22, 120));
                HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
                Rectangle(hdc, 50, 50, 200, 150);
                SelectObject(hdc, hOldBrush);
                DeleteObject(hBrush);

                SetTextColor(hdc, RGB(0, 0, 0));
                SetBkColor(hdc, RGB(255, 255, 255));

                EndPaint(hwnd, &ps);
            }
            return 0;
        case WM_LBUTTONDOWN:
            {

            }
            return 0;
        default: return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
}

int WINAPI StatWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    WNDCLASS wc = {0};
    wc.lpfnWndProc = StatWndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "STATIC";

    if(!RegisterClass(&wc))
    {
        MessageBox(NULL, "Could not register window class", "Flagrant system error", MB_ICONERROR | MB_OK);
        return 0;
    }

    HWND hwnd_statwin = CreateStatWindow(hInstance, nCmdShow, "Stats", 400, 400);

    MSG msg = {0};
    while(GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

#endif // TSF_STATS_WINDOW_H_INCLUDED
