#pragma once

#ifndef TSF_FUNCTIONS_H_INCLUDED
#define TSF_FUNCTIONS_H_INCLUDED

#include "tsf_settings.h"

using namespace std;

/*TSF Functions
    An empty placeholder linking TSF_settings to
    TSF_resources. Originally intended as a ubiquitous
    utility file.
*/





#endif // TSF_FUNCTIONS_H_INCLUDED
