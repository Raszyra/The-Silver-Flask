#ifndef TSF_SKILLS_H_INCLUDED
#define TSF_SKILLS_H_INCLUDED

#include <tsf_classes.h>
#include <vector>



/*	skill smskl[32]=
	{
	    "null",//1
		"dagger",//2
		"",//3
		"spearhead",//4
		"shortsword",//5
		"",//6
		"wakizashi",//7
		"chainmail",//10
		"splintmail",//11
		"steel bar",//12
		"mace",
		"smallshield",
		"falchion",
		"rapier",
		"longsword",
		"katana",
		"",
		"plate-armor",
		"",
		"",
		"kiteshield",
		"",
		"",
		"tower-shield",
		"",
		"greatsword",
		"",
		"battleaxe",
		"",
		"nodachi"};
*/

//int sm_item_id[32] = {0, 3, 0, 138, 7, 0, 0, 10, 8, 37, 0, 0, 24, 0, 95, 14, 114, 0, 30, 0, 0, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0};

//Name, lvl, item_id, mat1, mat2, s_mat1, s_mat2
vector<skill> sk_smskl ={
    {"dagger", 0, 0, 0, 0, "" ""},
    {"spearhead", 3, 138, 0, 0, "" ""},
    {"shortsword", 4, 0, 0, "" ""},
    {"wakizashi", 6, 138, 0, 0, "" ""},
    {"chainmail", 8, 10, 0, 0, "" ""},
    {"splintmail", 9, 146, 0, 0, "" ""},
    {"steel bar", 10, 37, 0, 0, "" ""},
    {"mace", 11, 148, 0, 0, "" ""},
    {"smallshield", 12, 1, 0, 0, "" ""},
}

#endif // TSF_SKILLS_H_INCLUDED
