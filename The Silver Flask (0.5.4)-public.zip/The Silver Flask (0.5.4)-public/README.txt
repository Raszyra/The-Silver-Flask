THE SILVER FLASK
Version 0.5.4-alpha ("Legendary Dragons")

Copyright (C) 2020-2025 Will Hooker

Explore a world of fantasy and magic, honing your skills to aid the people of Samlund and battle powerful enemies. 


ALPHA TESTERS: please listen carefully to the following -

1. As you find bugs, features you want to change, or posssible improvements,
add them to the game's official alpha notes using the 'writealpha' command.
2. Review your notes and past alpha comments with 'readalpha.'
3. IMPORTANT: before exiting the game, SAVE your alpha notes with 'savealpha'.
This will write to a file in "The Silver Flask (0.5.4)/config" called "alpha_notes.txt."
4. When you're finished testing or want to implement changes, rename "alpha_notes.txt" and include your name, username, or some kind of unique identifier  and email to:
	"faction7entertainment@gmail.com"
along with any comments or further explanation.

Thanks, good luck, and happy testing!

-> Command list can be accessed in-game by typing 'commands' or by typing 'help' to access commands, tutorial, and more

-> Custom commands can be set by entering 'setc' and then binding an existing command to a keyword or character


INSTALLATION

None. All files should be fine as-is. 

However, it is advisable to store this program somewhere besides the "Program Files" folder to avoid permissions issues when saving (or run the .exe file as an administrator.)

If you want to load a previous game:
- Open the "Saves" folder
- Create a new folder with the name of your save
- Copy/paste your "tsfsav" files into new folder

LICENSE

Licensed under the GNU General Public License v.03 
(More licensing information available in "LICENSE.txt")

