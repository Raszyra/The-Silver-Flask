source - README

Developer's note:

	This folder is intended to contain the source files for
	version (0.5.3-alpha) of The Silver Flask.

	If there are no files here, you have on your hands the commercial
	version of the game, just for playing; 

	if you're interested in the source code, whether to learn, contribute,
	or just for fun, please feel free to contact us at:

	faction7entertainment@gmail.com

	Otherwise, (developers) please consult the copy of the GNU General 
	Public License v.03 included with the game's .exe file before diving in.

	Thanks for playing with us!